#include "divers.h"
#include "ffss.h"
#include "utils.h"
//#include <stdarg.h>

FFSS_TCallbacks FFSS_CB;
#ifdef DEBUG
int N_DebugLevel = 6;
#else
int N_DebugLevel = 0;
#endif

void FFSS_PrintDebug(int Level,char *Txt, ...)
{
/*  va_list argptr;
  char Str[4096];

  if(Level <= N_DebugLevel)
  {
    va_start(argptr,Txt);
    _vsnprintf(Str,sizeof(Str),Txt,argptr);
    va_end(argptr);
    printf("FFSS(%d) : %s",Level,Str);
  }*/
}

/* Unpacks a string from a message, checking if the string really terminates (prevents DoS attacks) */
/*  Returns the string, or NULL if there is a problem */
char *FFSS_UnpackString(const char beginning[],const char buf[],int len,long int *new_pos)
{
  long int pos = buf - beginning;
  while(pos < len)
  {
    if(beginning[pos] == 0)
    {
      *new_pos = pos + 1;
      return (char *)buf;
    }
    pos++;
  }
  dprintf("String out of message... DoS attack ?\n");
  return NULL;
}

/* Unpacks a FFSS_Field from a message, checking if the FFSS_Field is fully in the message (prevents DoS attacks) */
/*  Returns the FFSS_Field, or 0 if there is a problem */
FFSS_Field FFSS_UnpackField(const char beginning[],const char buf[],int len,long int *new_pos)
{
  int pos = buf - beginning;
  if((pos+sizeof(FFSS_Field)) <= len)
  {
    *new_pos = pos + sizeof(FFSS_Field);
    return *(FFSS_Field *)buf;
  }
  else
  {
    dprintf("Longint out of message... DoS attack ?\n");
    return 0;
  }
}

void FFSS_UnpackIP(const char beginning[],char *buf,int len,long int *new_pos,char buf_out[],int Type)
{
  int a,b,c,d;
  int pos = buf - beginning;

  buf_out[0] = 0;
  if((pos+FFSS_IP_FIELD_SIZE) <= len)
  {
    switch(Type)
    {
      case FFSS_IP_V4 :
        if(buf != NULL)
        {
          a = (unsigned char)buf[0];
          b = (unsigned char)buf[1];
          c = (unsigned char)buf[2];
          d = (unsigned char)buf[3];
          snprintf(buf_out,16,"%d.%d.%d.%d",a,b,c,d);
          buf_out[15] = 0;
        }
        break;
      case FFSS_IP_V6 :
        break;
      default :
        dprintf("Unknown IP type : %d\n",Type);
    }
    *new_pos = pos + FFSS_IP_FIELD_SIZE;
  }
  else
  {
    dprintf("IP out of message... DoS attack ?\n");
  }
}

void FFSS_PackIP(char *buf,const char IP[],int Type)
{
  int a,b,c,d;

  switch(Type)
  {
    case FFSS_IP_V4 :
      if(IP != NULL)
      {
        sscanf(IP,"%d.%d.%d.%d",&a,&b,&c,&d);
      }
      else
      {
        a = b = c = d = 0;
      }
      buf[0] = (unsigned char)a;
      buf[1] = (unsigned char)b;
      buf[2] = (unsigned char)c;
      buf[3] = (unsigned char)d;
      break;
    case FFSS_IP_V6 :
      break;
    default :
      dprintf("Unknown IP type : %d\n",Type);
  }
}

FFSS_Field FFSS_ComputeChecksum(FFSS_Field Old,const char Buf[],long int Len)
{
#ifdef DISABLE_CHECKSUM
  return 1;
#else
  if(Buf == NULL)
    return adler32(0L, Z_NULL, 0);
  return adler32(Old, (const unsigned char *)Buf, Len);
#endif
}


bool FFSS_CompresseZlib(char *in,long int len_in,char *out,long int *len_out)
{
  int res;

  res = compress((unsigned char *)out,(unsigned long *)len_out,(const unsigned char *)in,len_in);
#ifdef DEBUG
  dprintf("Using Z compression (before=%ld - after=%ld)\n",len_in,*len_out);
#endif
  return (res == Z_OK);
}

char *FFSS_UncompresseZlib(char *in,long int len_in,long int *len_out)
{
  char *out,*old_out;
  long int len;
  int res;

  len = len_in*3;

  out = (char *) malloc(len);
  if(out == NULL)
    return NULL;

  *len_out = len;
  res = uncompress((unsigned char *)out,(unsigned long *)len_out,(const unsigned char *)in,len_in);
  while(res != Z_OK)
  {
    if((res == Z_MEM_ERROR) || (res == Z_DATA_ERROR))
    {
      free(out);
      return NULL;
    }
    len *= 2;
    old_out = out;
    out = (char *) realloc(out,len);
    if(out == NULL)
    {
      free(old_out);
      return NULL;
    }
    *len_out = len;
    res = uncompress((unsigned char *)out,(unsigned long *)len_out,(const unsigned char *)in,len_in);
  }
  return out;
}

#ifdef HAVE_BZLIB
bool FFSS_CompresseBZlib(char *in,long int len_in,char *out,long int *len_out)
{
  int res;

  res = BZ2_bzBuffToBuffCompress(out,(unsigned int *)len_out,in,len_in,FFSS_BZLIB_BLOCK100K,0,0);
#ifdef DEBUG
  printf("Using BZ compression (before=%ld - after=%ld)\n",len_in,*len_out);
#endif
  return (res == BZ_OK);
}

char *FFSS_UncompresseBZlib(char *in,long int len_in,long int *len_out)
{
  char *out,*old_out;
  long int len;
  int res;

  len = len_in*3;

  out = (char *) malloc(len);
  if(out == NULL)
    return NULL;

  *len_out = len;
  res = BZ2_bzBuffToBuffDecompress(out,(unsigned int *)len_out,in,len_in,FFSS_BZLIB_SMALL,0);
  while(res != BZ_OK)
  {
    if((res == BZ_MEM_ERROR) || (res == BZ_DATA_ERROR) || (res == BZ_DATA_ERROR_MAGIC) || (res == BZ_UNEXPECTED_EOF))
    {
      free(out);
      return NULL;
    }
    len *= 2;
    old_out = out;
    out = (char *) realloc(out,len);
    if(out == NULL)
    {
      free(old_out);
      return NULL;
    }
    *len_out = len;
    res = BZ2_bzBuffToBuffDecompress(out,(unsigned int *)len_out,in,len_in,FFSS_BZLIB_SMALL,0);
  }
  return out;
}
#endif
