#include "divers.h"
#include "ffss.h"

SU_PList FFSS_Domains; /* FC_PDomain */
SU_PList FFSS_Conns; /* FC_PConn */
SU_PList FFSS_Handles; /* PFFSSHANDLE */
VSemaphore *Sem_UDP;
VSemaphore *Sem_TCP;
VSemaphore *Sem_Handles;

void ClearServersMark(SU_PList Servers)
{
  SU_PList Ptr;

  Ptr = Servers;
  while(Ptr != NULL)
  {
    ((FC_PServer)Ptr->Data)->Mark = false;
    Ptr = Ptr->Next;
  }
}

SU_PList RemoveServersByMark(SU_PList Servers)
{
  SU_PList Ptr,Ptr2;

  Ptr2 = Servers;
  Ptr = Servers;
  while(Ptr != NULL)
  {
    if(!((FC_PServer)Ptr->Data)->Mark)
    {
      //dprintf("RemoveServersByMark : Removing %s",((FC_PServer)Ptr->Data)->Name);
      FreeServer((FC_PServer)Ptr->Data);
      if(Ptr == Ptr2)
      {
        Ptr = SU_DelElementHead(Ptr);
        Ptr2 = Ptr;
      }
      else
        Ptr = SU_DelElementHead(Ptr);
    }
    else
      Ptr = Ptr->Next;
  }
  return Ptr2;
}

void ClearSharesMark(SU_PList Shares)
{
  SU_PList Ptr;

  Ptr = Shares;
  while(Ptr != NULL)
  {
    ((FC_PShare)Ptr->Data)->Mark = false;
    Ptr = Ptr->Next;
  }
}

SU_PList RemoveSharesByMark(SU_PList Shares)
{
  SU_PList Ptr,Ptr2;

  Ptr2 = Shares;
  Ptr = Shares;
  while(Ptr != NULL)
  {
    if(!((FC_PShare)Ptr->Data)->Mark)
    {
      //dprintf("RemoveSharesByMark : Removing %s",((FC_PShare)Ptr->Data)->Name);
      FreeShare((FC_PShare)Ptr->Data);
      if(Ptr == Ptr2)
      {
        Ptr = SU_DelElementHead(Ptr);
        Ptr2 = Ptr;
      }
      else
        Ptr = SU_DelElementHead(Ptr);
    }
    else
      Ptr = Ptr->Next;
  }
  return Ptr2;
}

FC_PDomain GetDomainByName(const char Domain[],bool UDPLocked)
{
  SU_PList Ptr;

  if(!UDPLocked)
    Sem_UDP->wait();
  Ptr = FFSS_Domains;
  while(Ptr != NULL)
  {
    if(SU_strcasecmp(((FC_PDomain)Ptr->Data)->Name,Domain))
    {
      if(!UDPLocked)
        Sem_UDP->signal();
      return (FC_PDomain)Ptr->Data;
    }
    Ptr = Ptr->Next;
  }
  if(!UDPLocked)
    Sem_UDP->signal();
  return NULL;
}

FC_PServer GetServerByIP(FC_PDomain Domain,const char IP[])
{
  SU_PList Ptr,Ptr2;

  if(Domain == NULL)
  {
    Ptr = FFSS_Domains;
    while(Ptr != NULL)
    {
      Ptr2 = ((FC_PDomain)Ptr->Data)->Servers;
      while(Ptr2 != NULL)
      {
        if(strcmp(IP,((FC_PServer)Ptr2->Data)->IP) == 0)
          return (FC_PServer)Ptr2->Data;
        Ptr2 = Ptr2->Next;
      }
      Ptr = Ptr->Next;
    }
  }
  else
  {
    Ptr2 = Domain->Servers;
    while(Ptr2 != NULL)
    {
      if(strcmp(IP,((FC_PServer)Ptr2->Data)->IP) == 0)
        return (FC_PServer)Ptr2->Data;
      Ptr2 = Ptr2->Next;
    }
  }
  return NULL;
}

FC_PServer GetServerByName(FC_PDomain Domain,const char Server[],bool UDPLocked)
{
  SU_PList Ptr,Ptr2;

  if(!UDPLocked)
    Sem_UDP->wait();
  if(Domain == NULL)
  {
    Ptr = FFSS_Domains;
    while(Ptr != NULL)
    {
      Ptr2 = ((FC_PDomain)Ptr->Data)->Servers;
      while(Ptr2 != NULL)
      {
        if(SU_strcasecmp(Server,((FC_PServer)Ptr2->Data)->Name))
        {
          if(!UDPLocked)
            Sem_UDP->signal();
          return (FC_PServer)Ptr2->Data;
        }
        Ptr2 = Ptr2->Next;
      }
      Ptr = Ptr->Next;
    }
  }
  else
  {
    Ptr2 = Domain->Servers;
    while(Ptr2 != NULL)
    {
      if(SU_strcasecmp(Server,((FC_PServer)Ptr2->Data)->Name))
      {
        if(!UDPLocked)
          Sem_UDP->signal();
        return (FC_PServer)Ptr2->Data;
      }
      Ptr2 = Ptr2->Next;
    }
  }
  if(!UDPLocked)
    Sem_UDP->signal();
  return NULL;
}

FC_PShare GetShareByName(FC_PServer Server,const char Share[])
{
  SU_PList Ptr;

  Ptr = Server->Shares;
  while(Ptr != NULL)
  {
    if(SU_strcasecmp(((FC_PShare)Ptr->Data)->Name,Share))
      return (FC_PShare)Ptr->Data;
    Ptr = Ptr->Next;
  }
  return NULL;
}

bool IsShareFromServer(FC_PServer Server,const char Share[],bool UDPLocked)
{
  SU_PList Ptr;

  if(!UDPLocked)
    Sem_UDP->wait();
  Ptr = Server->Shares;
  while(Ptr != NULL)
  {
    if(SU_strcasecmp(((FC_PShare)Ptr->Data)->Name,Share))
    {
      if(!UDPLocked)
        Sem_UDP->signal();
      return true;
    }
    Ptr = Ptr->Next;
  }
  if(!UDPLocked)
    Sem_UDP->signal();
  return false;
}

FC_PConn GetConnByIPShare(const char IP[],const char Share[])
{
  SU_PList Ptr;

  Ptr = FFSS_Conns;
  while(Ptr != NULL)
  {
    if(strcmp(IP,((FC_PConn)Ptr->Data)->IP) == 0)
    {
      if(SU_strcasecmp(Share,((FC_PConn)Ptr->Data)->Share))
      {
        if(!((FC_PConn)Ptr->Data)->TCP->IsConnected())
        {
          dprintf("GetConnByIPShare : Connection closed... deleting");
          RemoveConnByIPShare(IP,Share);
          return NULL;
        }
        return (FC_PConn)Ptr->Data;
      }
    }
    Ptr = Ptr->Next;
  }
  return NULL;
}

FC_PConn CreateConnection(const char IP[],const char Share[])
{
  SU_PList Ptr;
  FC_PConn Conn;
  FfssTCP *TCP;

  TCP = FC_SendMessage_ShareConnect(IP,Share,NULL,NULL);
  if(TCP == NULL)
    return NULL;
  Conn = (FC_PConn) malloc(sizeof(FC_TConn));
  if(Conn == NULL)
    return NULL;
  memset(Conn,0,sizeof(FC_TConn));
  Conn->IP = strdup(IP);
  Conn->Share = strdup(Share);
  Conn->TCP = TCP;
  FFSS_Conns = SU_AddElementHead(FFSS_Conns,Conn);
  return Conn;
}

void FreeConn(FC_PConn Conn)
{
  //dprintf("FreeConn : Freeing connection... and TCP %p",Conn->TCP);
  if(Conn->IP != NULL)
    free(Conn->IP);
  if(Conn->Share != NULL)
    free(Conn->Share);
  Conn->TCP->disconnect();
  if(Conn->TCP->Used == 0)
    delete Conn->TCP;
  else
  {
    Conn->TCP->Mark = true;
    dprintf("FreeConn : Cannot free TCP cause it's in use by %d HANDLEs, marking it",Conn->TCP->Used);
  }
  free(Conn);
}

void RemoveConnByIPShare(const char IP[],const char Share[])
{
  SU_PList Ptr;

  Ptr = FFSS_Conns;
  while(Ptr != NULL)
  {
    if(strcmp(IP,((FC_PConn)Ptr->Data)->IP) == 0)
    {
      if(SU_strcasecmp(Share,((FC_PConn)Ptr->Data)->Share))
      {
        FreeConn((FC_PConn)Ptr->Data);
        FFSS_Conns = SU_DelElementElem(FFSS_Conns,Ptr->Data);
      }
    }
    Ptr = Ptr->Next;
  }
}

void RemoveConnByConn(FC_PConn Conn)
{
  FreeConn(Conn);
  FFSS_Conns = SU_DelElementElem(FFSS_Conns,Conn);
}

void FreeShare(FC_PShare Shr)
{
  if(Shr->Name != NULL)
    free(Shr->Name);
  free(Shr);
}

void FreeSharesList(SU_PList Shares)
{
  SU_PList Ptr;

  Ptr = Shares;
  while(Ptr != NULL)
  {
    FreeShare((FC_PShare)Ptr->Data);
    Ptr = Ptr->Next;
  }
  SU_FreeList(Shares);
}

void FreeServer(FC_PServer Ser)
{
  if(Ser->Name != NULL)
    free(Ser->Name);
  if(Ser->IP != NULL)
    free(Ser->IP);
  FreeSharesList(Ser->Shares);
  free(Ser);
}

/*void FreeServerList(SU_PList Servers)
{
  SU_PList Ptr;

  Ptr = Servers;
  while(Ptr != NULL)
  {
    FreeServer((FC_PServer)Ptr->Data);
    Ptr = Ptr->Next;
  }
  SU_FreeList(Servers);
}

void FreeDomain(FC_PDomain Dom)
{
  if(Dom->Name != NULL)
    free(Dom->Name);
  FreeServerList(Dom->Servers);
  free(Dom);
}

void FreeDomainList()
{
  SU_PList Ptr;

  Ptr = FFSS_Domains;
  while(Ptr != NULL)
  {
    FreeDomain((FC_PDomain)Ptr->Data);
    Ptr = Ptr->Next;
  }
  SU_FreeList(FFSS_Domains);
  FFSS_Domains = NULL;
}*/

void FreeEntry(FC_PEntry Ent)
{
  if(Ent->Name != NULL)
    free(Ent->Name);
  free(Ent);
}

void FreeEntries(SU_PList Entries)
{
  SU_PList Ptr;

  Ptr = Entries;
  while(Ptr != NULL)
  {
    FreeEntry((FC_PEntry)Ptr->Data);
    Ptr = Ptr->Next;
  }
  SU_FreeList(Entries);
}

FC_PEntry DupEntry(FC_PEntry Ent)
{
  FC_PEntry Ent2;

  Ent2 = (FC_PEntry) malloc(sizeof(FC_TEntry));
  if(Ent2 == NULL)
  {
    dprintf("DupEntry : Malloc failed");
    return NULL;
  }
  memset(Ent2,0,sizeof(FC_TEntry));
  Ent2->Flags = Ent->Flags;
  Ent2->Name = strdup(Ent->Name);
  Ent2->Size = Ent->Size;
  Ent2->Stamp = Ent->Stamp;
  return Ent2;
}

void FreeEntryList(FC_PEntList EL)
{
  if(EL->Name != NULL)
    free(EL->Name);
  FreeEntries(EL->Entries);
}

FC_PEntList GetEntryListByPath(FfssTCP *TCP,const char Path[])
{
  SU_PList Ptr;
  FC_PEntList EL;

  Ptr = TCP->Entries;
  while(Ptr != NULL)
  {
    EL = (FC_PEntList) Ptr->Data;
    if(!EL->Used)
    {
      //dprintf("GetEntryListByPath : Removing unused Entries %s",EL->Name);
      FreeEntryList(EL);
      if(Ptr == TCP->Entries)
      {
        Ptr = SU_DelElementHead(Ptr);
        TCP->Entries = Ptr;
      }
      else
        Ptr = SU_DelElementHead(Ptr);
    }
    else
    {
      if(strcmp(Path,EL->Name) == 0)
        return EL;
      Ptr = Ptr->Next;
    }
  }
  return NULL;
}

FC_PEntList GetEntryListByPathOnly(FfssTCP *TCP,const char Path[])
{
  SU_PList Ptr;
  FC_PEntList EL;

  Ptr = TCP->Entries;
  while(Ptr != NULL)
  {
    EL = (FC_PEntList) Ptr->Data;
    if(strcmp(Path,EL->Name) == 0)
    {
      if(!EL->Used)
      {
        //dprintf("GetEntryListByPathOnly : Unmarking unused entry %s, cause we are asked for this one",EL->Name);
        EL->Used = true;
      }
      return EL;
    }
    Ptr = Ptr->Next;
  }
  return NULL;
}

PFFSSHANDLE GetHandleByName(const char Path[])
{
  SU_PList Ptr;
  PFFSSHANDLE Hdl;

  Ptr = FFSS_Handles;
  while(Ptr != NULL)
  {
    if(SU_strcasecmp(Path,((PFFSSHANDLE)Ptr->Data)->h_name))
      return (PFFSSHANDLE)Ptr->Data;
    Ptr = Ptr->Next;
  }
  return NULL;
}

PFFSSHANDLE GetHandleByHandle(long int Handle)
{
  SU_PList Ptr;
  PFFSSHANDLE Hdl;

  Ptr = FFSS_Handles;
  while(Ptr != NULL)
  {
    if(Handle == ((PFFSSHANDLE)Ptr->Data)->h_handle)
      return (PFFSSHANDLE)Ptr->Data;
    Ptr = Ptr->Next;
  }
  return NULL;
}
