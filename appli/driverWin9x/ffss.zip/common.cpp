#include "divers.h"
#include "ffss.h"
#include "utils.h"
#include "common.h"

void FC_AnalyseUDP(PTRANSPORT_ADDRESS Client,char Buf[],long int Len);

char *FFSS_MyIP = NULL;

void FfssUDP::GetDatagram(uchar *Data,uint Indicated,PTRANSPORT_ADDRESS pTA)
{
  FFSS_Field Size;
  bool analyse;
	char szIPaddr[150];

  if(len >= BufSize)
  {
    dprintf("WARNING : UDP buffer too short for this message !! Ignoring message...\n");
    len = 0;
  }
  if(Indicated >= (BufSize - len))
  {
    dprintf("WARNING : UDP buffer too short for this message !! Ignoring message...\n");
    len = 0;
    return;
  }
  memcpy(Buf+len,Data,Indicated);
	inet_ntoa(PTDI_ADDRESS_IP(pTA->Address[0].Address)->in_addr, szIPaddr, sizeof(szIPaddr));
  dprintf("Data found on UDP port from %s (%d bytes)... analysing\n",szIPaddr,Indicated);
  /* If size of message won't fit in the buffer */
  if((len == 0) && ((*(FFSS_Field *)Buf) > BufSize))
  {
    dprintf("Length of the message won't fit in the UDP buffer !!\n");
  }
  len += Indicated;
  analyse = true;
  while(analyse)
  {
    if(len < 5)
    {
      dprintf("Length of the message is less than 5 (%d)... DoS attack ?\n",len);
      len = 0;
      break;
    }
    Size = *(FFSS_Field *)Buf;
    if(Size < 5)
    {
      dprintf("Size of the message is less than 5 (%d)... DoS attack ?\n",Size);
      len = 0;
      break;
    }
    if(Size > len)
    {
      dprintf("Warning, Size of the message is greater than received data (%d - %d)... Message splitted ?\n",Size,len);
      break;
      /* Keeps waiting for data */
    }
    else
    {
      FC_AnalyseUDP(pTA,Buf,Size);
      Sem->SignalTimer();
      if(len > Size)
      {
        dprintf("Warning, Size of the message is less than received data (%d - %d)... multiple messages ?\n",Size,len);
        memmove(Buf,Buf+Size,len-Size);
        len -= Size;
        /* Keeps analysing the buffer */
      }
      else
      {
        analyse = false;
        len = 0;
      }
    }
  }
}

