// FFSS.h - include file for VxD FFSS
#ifndef _FFSSFS_H_
#define _FFSSFS_H_

#define USE_NDIS
#include <vtoolscp.h>
#include "myvtoolsc.h"
#include <ddb.h>
extern "C" VDevice* __cdecl _CreateDevice(void);
extern "C" VOID __cdecl _DestroyDevice(void);

#define DEVICE_CLASS		FfssDevice
#define FFSS_DeviceID		UNDEFINED_DEVICE_ID
#define FFSS_Init_Order	UNDEFINED_INIT_ORDER
#define FFSS_Major		1
#define FFSS_Minor		0

#include <tdiclient.h>
#include <tdiSclient.h>

typedef struct
{
  char *Name;
  SU_PList Entries; /* FC_PEntry */
  bool Used;
  bool Listed;
} FC_TEntList, *FC_PEntList;

class FfssTCPXfer : public KStreamServerSession
{
public:
  // handlers - overrides from KStreamServerSession
  BOOLEAN  OnConnect(uint AddressLength, PTRANSPORT_ADDRESS pTA, uint OptionsLength, PVOID Options);
  void OnDisconnect(uint OptionsLength, PVOID Options, BOOLEAN bAbort);
	uint OnReceive(uint Indicated, uchar *Data, uint Available, uchar **RcvBuffer, uint* RcvBufferLen);
	void OnReceiveComplete(TDI_STATUS Status, uint Indicated, uchar *Data);
  void OnSendComplete(PVOID buf, TDI_STATUS status, uint bytecnt);
private:
};

class FfssTimer;

class FfssSem : public VSemaphore
{
public:
  FfssSem() : VSemaphore(1) {Locked=false;}
  void SetTimer(FfssTimer *Timer) {pTimer = Timer;}
  void SignalTimer();
  void WaitTimer();
  void Signal();
  void Wait();
  void SetTimeout(DWORD msec);
//  void wait() { Wait(); }
//  void signal() { Signal(); }
private:
  FfssTimer *pTimer;
  bool Locked;
};

class FfssTimer : public VGlobalTimeOut
{
public:
  FfssTimer(FfssSem *Sem,DWORD msec) : VGlobalTimeOut(msec) {pSem = Sem;}
  BOOL Set() { return VGlobalTimeOut::Set();};
  void SetTimeout(DWORD msec) {m_mSec=msec;}
  virtual VOID handler(VMHANDLE,THREADHANDLE,PCLIENT_STRUCT,DWORD) {pSem->Signal();}
private:
  FfssSem *pSem;
};

class FfssTCP : public KStreamSocket
{
public:
  SU_PList Entries; /* FC_PEntList */
  FfssSem *Sem;
  int Used; /* Nb of HANDLE using this connection */
  bool Mark; /* If conn to be deleted */
  FfssTCP();
  ~FfssTCP();
  TDI_STATUS connect(PTDI_CONNECTION_INFORMATION);
  TDI_STATUS send(void*,uint);
protected:
  void On_connectComplete(PVOID,TDI_STATUS,uint);
  void On_sendComplete(PVOID,TDI_STATUS,uint);
  uint OnReceive(uint,uchar*,uint,uchar**,uint*);
  void OnReceiveComplete(TDI_STATUS,uint,uchar*);
  void On_disconnectComplete(PVOID,TDI_STATUS,uint);
  void OnDisconnect(uint OptionsLength,PVOID Options,BOOLEAN bAbort);
private:
  FfssTimer *Timer;
  char *Buf;
  long int BufSize;
  unsigned int len;
  bool GetPacket(FfssTCP *Server,uchar *Data,uint Indicated);
};

class FfssUDP : public KDatagramSocket
{
public:
  FfssSem *Sem;
  FfssUDP();
  ~FfssUDP();
  TDI_STATUS sendto(PTDI_CONNECTION_INFORMATION pConn,void* pBuf,uint Size,PVOID pCxt = NULL);
protected:
  void On_sendtoComplete(PVOID,TDI_STATUS,uint);
  uint OnReceive(uint,PTRANSPORT_ADDRESS,uint,PVOID,uint,uchar*,uint,uchar**,uint*);
  void OnReceiveComplete(TDI_STATUS,uint,PTRANSPORT_ADDRESS,uint,PVOID,uint,uchar*);
private:
  FfssTimer *Timer;
  char *Buf;
  long int BufSize;
  unsigned int len;
  void GetDatagram(uchar *Data,uint Indicated,PTRANSPORT_ADDRESS pTA);
};

class FfssDevice : public VDevice
{
public:
	virtual BOOL OnSysDynamicDeviceInit();
	virtual BOOL OnSysDynamicDeviceExit();
private:
};

class FfssVM : public VVirtualMachine
{
public:
	FfssVM(VMHANDLE hVM);
};

class FfssThread : public VThread
{
public:
	FfssThread(THREADHANDLE hThread);
};


#include "divers.h"

/////////////////////////////////////////////////////////////////////
// Constants

// Constants required by the VtoolsD framework 
#define FFSS_Major		1
#define FFSS_Minor		0
#define FFSS_DeviceID		UNDEFINED_DEVICE_ID
#define FFSS_Init_Order	UNDEFINED_INIT_ORDER

// Constants for the Device Registration Packet
#define FFSS_NAME	"FFSS           "
#define FFSS_REV 	1
#define FFSS_FEATURE	0
#define FFSS_IFR	0

// Constants for PATH TYPE
#define PATH_TYPE_ROOT      0
#define PATH_TYPE_DOMAINS   1
#define PATH_TYPE_SERVERS   2
#define PATH_TYPE_SHARES    3
#define PATH_TYPE_DIRECTORY 4
#define PATH_TYPE_FILE      5

// Constants for PFFSSHANDLE
#define FFSS_HANDLE_STATE_WAITING 1
#define FFSS_HANDLE_STATE_OPEN    2
#define FFSS_HANDLE_STATE_CLOSE   3
#define STREAMING_BUFFER_SIZE 65536

// Size of the buffer used to read in value data
#define READBUFSIZE 512
// Macro to define the byte offset from the start of an IOP to the 
// start of the embedded IOR. Assumes no IOP extension.
#define IORDELTA ((ULONG)(&((IOP*)0)->IOP_ior))
// Debug signature for a find first handle
#define SIGFIND 'DNIF'
// Debug signature for an open file handle
#define SIGFILE 'ELIF'
// Number of special root keys in the Registry
#define NPREDEFKEYS 6
// Special value to denote the real root of the Registry, i.e., the
// implied root below the six predefined roots.
#define REGISTRY_ROOT	0xffffffff

// Macros for debugging
#ifdef DEBUG
// Display the string s and variable t
#define fsdtrace(s, t) dprintf("%s: pir=%x\n", s, t)
// Force a heap walk (use in conjunction with .m? command in debugger)
#define ForceHeapWalk(s) free(malloc(1));dprintf(s);DebugBreak()
#else  // non-debug versions are empty
#define fsdtrace(s, t) 
#define ForceHeapWalk(s) 
#endif

/////////////////////////////////////////////////////////////////////
// Types

// Declare the device parameters structure. This is defined by DOS, 
// and used for IOCTL calls.
typedef struct tagDeviceParams {
	BYTE	dpSpecFunc;
	BYTE	dpDevType;
	WORD	dpDevAttr;
	WORD	dpCylinders;
	BYTE	dpMediaType;
	WORD	dpBytesPerSector;
	BYTE	dpSectorsPerCluster;
	WORD	dpReservedSectors;
	BYTE	dpFATs;
	WORD	dpRootDirectoryEntries;
	WORD	dpSectors;
	BYTE	dpMedia;
	WORD	dpSectorsPerFAT;
	WORD	dpSectorsPerTrack;
	WORD	dpHeads;
	DWORD	dpHiddenSectors;
	DWORD	dpHugeSectors;        
} DEVICEPARAMS, *PDEVICEPARAMS;

// Declare the media ID structure. This is defined by DOS, and used 
// for IOCTL calls.
typedef struct tagMediaID {
	WORD	midInfoLevel;
	DWORD	midSerialNum;
	CHAR	midVolLable[11];
	CHAR	midFileSysType[8];
} MEDIAID, *PMEDIAID;

// FFSS private handle structure for FindFirst/FindNext operations
typedef struct _findcontext
{
  int   fc_PathType; // One of PATH_TYPE_xxx
	ULONG	fc_sig;		// must be SIGFIND
	PWORD	fc_match;	// meta match specification
  int   fc_index; // Current enum pos
  char  *fc_Domain;
  char  *fc_Server;
  FC_PEntList fc_EntryList;
} FINDCONTEXT, *PFINDCONTEXT;

// FFSS private handle structure for Open File operations
typedef struct _ffsshandle
{
	ULONG	h_sig;		// must be SIGFILE
	PCHAR	h_name;	  // file name
	ULONG	h_pos;		// current position
  int   h_state;  // Current state of the handle
  long int h_size; // Size of file
  long int h_handle; // Handle from server
  FfssTCP *h_TCP;
  char h_buffer[STREAMING_BUFFER_SIZE];
  long int h_buffer_pos;
  bool h_eof;
} FFSSHANDLE, *PFFSSHANDLE;

// Structure used by debug routines to associate strings to constants
typedef struct _name_assoc {
	BYTE _func;
	const char* _name;
} NAMETABLE;

/////////////////////////////////////////////////////////////////////
// Function prototypes

extern "C" {
VOID __cdecl FFSS_Aer(AEP*);
INT FfssMountVolume(pioreq pir);
VOID __cdecl FFSS_RequestHandler(IOP* pIop);
VOID SetupDCB(DCB* pDcb);
bool IsDomainName(PCHAR AscPath);
bool IsServerName(PCHAR AscPath,char IP[],int len);
bool IsShareName(PCHAR ServerIP,PCHAR AscPath);
BOOL ParseOpenPath(path_t path, PHKEY pRootKey, PCHAR RegPath, 
	PCHAR pValue, DWORD ValueSize);
VOID PutShortName(PWORD pUniShortName, PCHAR h, INT e);
WORD CopyParsedPath(path_t dest, path_t source);
BOOL CheckDirectoryExists(path_t path);
void *CheckFileExists(path_t path); /* FC_PEntry */
BYTE AssociateDriveLetter(DCB_COMMON* pDcb);
unsigned int ustrlen(WORD* pUniString);
WORD* ustrcpy(WORD* dest, WORD* src);
BOOL IsThisOurDrive(pioreq pir);
const CHAR* GetAEFunctionName(ULONG func);
const CHAR* GetIOFunctionName(ULONG func);
IOP* GetIop(PFNISP pSvc, USHORT IopSize, ULONG DeltaIor, 
	UCHAR flags, WORD* pResult);
BOOL HasMetaChar(PCHAR s);
BOOL IsThisOurDrive(pioreq pir);
VOID IoctlGetDeviceParams(PDEVICEPARAMS pDP);
VOID ZeroTime(_FILETIME* pft);
BOOL ParseFindPath(path_t path, int *pPathType, PCHAR pFullPath, int PathLen, PathElement** ppMatch, FC_PDomain *pDom, FC_PServer *pSer, char pShare[],FC_PConn *pConn, bool UDPLocked);
WORD ReleaseIop(PFNISP pSvc, IOP* pIop);
}

INT VolDelete(pioreq pir);
INT VolDir(pioreq pir);
INT VolAttrib(pioreq pir);
INT Vol_Flush(pioreq pir);
INT VolInfo(pioreq pir);
INT VolOpen(pioreq pir);
INT VolRename(pioreq pir);
INT VolSearch(pioreq pir);
INT VolQuery(pioreq pir);
INT VolDisconnect(pioreq pir);
INT VolUNCPipe(pioreq pir);
INT VolIoctl16(pioreq pir);
INT VolParams(pioreq pir);
INT VolFindOpen(pioreq pir);
INT VolDasdio(pioreq pir);
INT HandleRead(pioreq pir);
INT HandleWrite(pioreq pir);
INT HandleSeek(pioreq pir);
INT HandleClose(pioreq pir);
INT HandleCommit(pioreq pir);	 
INT HandleFilelocks(pioreq pir);
INT HandleFiletimes(pioreq pir);
INT HandlePiperequest(pioreq pir);
INT HandleHandleinfo(pioreq pir);
INT HandleEnumhandle(pioreq pir);	
INT FindNext(pioreq pir);
INT ErrorFunc(pioreq pir);

/////////////////////////////////////////////////////////////////////
// Global data

// Assigned drive letter designator (0=A)
extern BYTE Drive;
// Pointer the drive's physical DCB
extern DCB* pDcbOfThisDevice;
// Array of names of the six predefined Registry root keys
extern PCHAR PredefinedRegKeyStrings[NPREDEFKEYS];
// Array of values of the six predefined Registry root keys
extern INT PredefinedRegKeyValues[NPREDEFKEYS];
// The volume handle passed to the mount routine
extern VRP* VolumeHandle;
// The driver's IOS linkage block
extern ILB FFSS_Ilb;

extern FfssUDP *pUDP;
extern FfssTimer *Timer_Debug;

extern FfssSem *Sem_Debug;

#endif
