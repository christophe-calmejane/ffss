#ifndef __FFSS_H__
#define __FFSS_H__

#define DRIVER

#ifdef _WIN32
//#define HAVE_BZLIB 1
#endif

#include "ffssfs.h"

#include "skyutils.h"
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <sys/types.h>
#include "zlib.h"
#ifdef HAVE_BZLIB
#include <bzlib.h>
#endif

//#include <process.h>
//#include <time.h>
#define strtok_r(a,b,c) strtok(a,b)

#define FFSS_VERSION "1.0.0-pre35"
#define FFSS_COPYRIGHT "FFSS library v" FFSS_VERSION " (c) Ze KiLleR / SkyTech 2001"
#define FFSS_FTP_SERVER "FFSS FTP compatibility v" FFSS_VERSION

#ifdef __linux__
#define FFSS_SERVER_OS "Linux"
#elif __FreeBSD__
#define FFSS_SERVER_OS "FreeBSD"
#define __BSD__
#elif __NetBSD__
#define FFSS_SERVER_OS "NetBSD"
#define __BSD__
#elif __OpenBSD__
#define FFSS_SERVER_OS "OpenBSD"
#define __BSD__
#elif _WIN32
#define FFSS_SERVER_OS "Win32"
#else
#error "Unknown OS... contact devel team"
#endif
#define FFSS_PROTOCOLE_VERSION 001

#define FFSS_MASTER_PORT 10001
#define FFSS_SERVER_PORT 10002
#define FFSS_SERVER_FTP_PORT 10003
#define FFSS_SERVER_CONF_PORT 10001
#define FFSS_MASTER_PORT_S "10001"
#define FFSS_SERVER_PORT_S "10002"

/*#define FFSS_MASTER_PORT 695
#define FFSS_SERVER_PORT 696
#define FFSS_SERVER_FTP_PORT 697
#define FFSS_SERVER_CONF_PORT 695
#define FFSS_MASTER_PORT_S "695"
#define FFSS_SERVER_PORT_S "696"*/

#define FFSS_IP_V4 1
#define FFSS_IP_V6 2
#define FFSS_IP_FIELD_SIZE 16

#define FFSS_IP_TYPE FFSS_IP_V4

#define FFSS_MAX_SERVERNAME_LENGTH 15
#define FFSS_MAX_SERVEROS_LENGTH 15
#define FFSS_MAX_SERVERCOMMENT_LENGTH 50
#define FFSS_MAX_DOMAIN_LENGTH 20
#define FFSS_MAX_SHARENAME_LENGTH 20
#define FFSS_MAX_SHARECOMMENT_LENGTH 50
#define FFSS_MAX_ERRORMSG_LENGTH 100
#define FFSS_MAX_LOGIN_LENGTH 20
#define FFSS_MAX_PASSWORD_LENGTH 20
#define FFSS_MAX_PATH_LENGTH 1024
#define FFSS_MAX_FILEPATH_LENGTH 1024
#define FFSS_MAX_KEYWORDS_LENGTH 2048
#ifdef __BSD__
#define FFSS_MAX_UDP_PACKET_LENGTH 4000
#else
#define FFSS_MAX_UDP_PACKET_LENGTH 60000
#endif
#define FFSS_MIN_SEARCH_REQUEST_LENGTH 4
#define FFSS_UDP_BUFFER_SIZE 200000
#define FFSS_TCP_BUFFER_SIZE 100000
#ifdef _WIN32
#define FFSS_TRANSFER_BUFFER_SIZE 1460
#else
#ifdef __BSD__
#define FFSS_TRANSFER_BUFFER_SIZE 1460
#else
#define FFSS_TRANSFER_BUFFER_SIZE 1480
#endif
#endif
#define FFSS_STREAMING_BUFFER_SIZE 65536
#define FFSS_TRANSFER_READ_BUFFER_SIZE 65536
#define FFSS_TIMEOUT_INDEX_ACCEPT 5
#define FFSS_TIMEOUT_INDEX_XFER 5
#define FFSS_TIMEOUT_ACCEPT 30
#define FFSS_TIMEOUT_UDP_LOCK 15
#define FFSS_TIMEOUT_TRANSFER 60
#define FFSS_TIMEOUT_UDP_MESSAGE 5
#define FFSS_TIMEOUT_TCP_MESSAGE 15
#define FFSS_TIMEOUT_FTP 60
#define FFSS_PING_INTERVAL 60
#define FFSS_PING_TIMEOUT FFSS_PING_INTERVAL*2
#define FFSS_INDEX_INTERVAL 60*10 // 10 min
#define FFSS_KEEP_HOST_DELAY 60*60*24*30 // 30 days
#define FFSS_STATE_BROADCAST_INTERVAL 120
#define FFSS_UDP_MAX_ERRORS 20
#define FFSS_DEFAULT_MAX_CONN 10
#define FFSS_DEFAULT_MAX_XFER_PER_CONN 2

#define FFSS_MESSAGE_STATE                      1
#define FFSS_MESSAGE_STATE_ANSWER               2
#define FFSS_MESSAGE_NEW_STATES                 3
#define FFSS_MESSAGE_INDEX_REQUEST              4
#define FFSS_MESSAGE_INDEX_ANSWER               5
#define FFSS_MESSAGE_SERVER_LISTING             6
#define FFSS_MESSAGE_SERVER_LISTING_ANSWER      7
#define FFSS_MESSAGE_CLIENT_SERVER_FAILED       8
#define FFSS_MESSAGE_PING                       9
#define FFSS_MESSAGE_PONG                      10
#define FFSS_MESSAGE_SERVER_SEARCH             11
#define FFSS_MESSAGE_SHARES_LISTING            12
#define FFSS_MESSAGE_SHARES_LISTING_ANSWER     13
#define FFSS_MESSAGE_SHARE_CONNECTION          14
#define FFSS_MESSAGE_DIRECTORY_LISTING         15
#define FFSS_MESSAGE_DIRECTORY_LISTING_ANSWER  16
#define FFSS_MESSAGE_DOWNLOAD                  17
#define FFSS_MESSAGE_UPLOAD                    18
#define FFSS_MESSAGE_MOVE                      19
#define FFSS_MESSAGE_COPY                      20
#define FFSS_MESSAGE_DELETE                    21
#define FFSS_MESSAGE_MKDIR                     22
#define FFSS_MESSAGE_DOMAINS_LISTING           30
#define FFSS_MESSAGE_DOMAINS_LISTING_ANSWER    31
#define FFSS_MESSAGE_SEARCH                    50
#define FFSS_MESSAGE_SEARCH_ANSWER             51
#define FFSS_MESSAGE_SEARCH_MASTER             55
#define FFSS_MESSAGE_SEARCH_MASTER_ANSWER      56
#define FFSS_MESSAGE_STREAMING_OPEN            80
#define FFSS_MESSAGE_STREAMING_OPEN_ANSWER     81
#define FFSS_MESSAGE_STREAMING_CLOSE           82
#define FFSS_MESSAGE_STREAMING_READ            83
#define FFSS_MESSAGE_STREAMING_READ_ANSWER     84
#define FFSS_MESSAGE_STREAMING_WRITE           85
#define FFSS_MESSAGE_STREAMING_WRITE_ANSWER    86
#define FFSS_MESSAGE_STREAMING_SEEK            87
#define FFSS_MESSAGE_INIT_XFER                 97
#define FFSS_MESSAGE_CANCEL_XFER               98
#define FFSS_MESSAGE_DATA                      99
#define FFSS_MESSAGE_DISCONNECT               100
#define FFSS_MESSAGE_ERROR                    200

#define FFSS_MESSAGESIZE_STATE                      4
#define FFSS_MESSAGESIZE_STATE_ANSWER               2
#define FFSS_MESSAGESIZE_NEW_STATES                 3
#define FFSS_MESSAGESIZE_NEW_STATES_2               3
#define FFSS_MESSAGESIZE_INDEX_REQUEST              3
#define FFSS_MESSAGESIZE_INDEX_ANSWER               5
#define FFSS_MESSAGESIZE_INDEX_ANSWER_2             5
#define FFSS_MESSAGESIZE_SERVER_LISTING             3
#define FFSS_MESSAGESIZE_SERVER_LISTING_ANSWER      3
#define FFSS_MESSAGESIZE_SERVER_LISTING_ANSWER_2    1
#define FFSS_MESSAGESIZE_SERVER_LISTING_ANSWER_3    2
#define FFSS_MESSAGESIZE_CLIENT_SERVER_FAILED       3
#define FFSS_MESSAGESIZE_PING                       2
#define FFSS_MESSAGESIZE_PONG                       3
#define FFSS_MESSAGESIZE_SERVER_SEARCH              2
#define FFSS_MESSAGESIZE_SHARES_LISTING             2
#define FFSS_MESSAGESIZE_SHARES_LISTING_ANSWER      4
#define FFSS_MESSAGESIZE_SHARE_CONNECTION           3
#define FFSS_MESSAGESIZE_DIRECTORY_LISTING          2
#define FFSS_MESSAGESIZE_DIRECTORY_LISTING_ANSWER   4
#define FFSS_MESSAGESIZE_DIRECTORY_LISTING_ANSWER_2 3
#define FFSS_MESSAGESIZE_DOWNLOAD                   4
#define FFSS_MESSAGESIZE_UPLOAD                     4
#define FFSS_MESSAGESIZE_MOVE                       2
#define FFSS_MESSAGESIZE_COPY                       2
#define FFSS_MESSAGESIZE_DELETE                     2
#define FFSS_MESSAGESIZE_MKDIR                      2
#define FFSS_MESSAGESIZE_DOMAINS_LISTING            2
#define FFSS_MESSAGESIZE_DOMAINS_LISTING_ANSWER     3
#define FFSS_MESSAGESIZE_SEARCH                     4
#define FFSS_MESSAGESIZE_SEARCH_ANSWER              3
#define FFSS_MESSAGESIZE_SEARCH_MASTER              3
#define FFSS_MESSAGESIZE_SEARCH_MASTER_ANSWER       3
#define FFSS_MESSAGESIZE_STREAMING_OPEN             3
#define FFSS_MESSAGESIZE_STREAMING_OPEN_ANSWER      5
#define FFSS_MESSAGESIZE_STREAMING_CLOSE            3
#define FFSS_MESSAGESIZE_STREAMING_READ             4
#define FFSS_MESSAGESIZE_STREAMING_READ_ANSWER      3
#define FFSS_MESSAGESIZE_STREAMING_WRITE            4
#define FFSS_MESSAGESIZE_STREAMING_WRITE_ANSWER     4
#define FFSS_MESSAGESIZE_STREAMING_SEEK             5
#define FFSS_MESSAGESIZE_INIT_XFER                  3
#define FFSS_MESSAGESIZE_CANCEL_XFER                3
#define FFSS_MESSAGESIZE_DATA                       3
#define FFSS_MESSAGESIZE_DISCONNECT                 2
#define FFSS_MESSAGESIZE_ERROR                      3

#define FFSS_STATE_ON       1
#define FFSS_STATE_OFF      2
#define FFSS_STATE_QUIET    4
#define FFSS_STATE_ALL      7

#define FFSS_SEEK_SET  1
#define FFSS_SEEK_CUR  2
#define FFSS_SEEK_END  3

#define FFSS_STRM_OPEN_READ    1
#define FFSS_STRM_OPEN_WRITE   2
#define FFSS_STRM_OPEN_TEXT    4
#define FFSS_STRM_OPEN_BINARY  8

#define FFSS_THREAD_SERVER 1
#define FFSS_THREAD_CLIENT 2
#define FFSS_THREAD_MASTER 3

#define FFSS_ERROR_SERVER_TOO_OLD             1
#define FFSS_ERROR_RESOURCE_NOT_AVAIL         2
#define FFSS_ERROR_NEED_LOGIN_PASS            3
#define FFSS_ERROR_TOO_MANY_CONNECTIONS       4
#define FFSS_ERROR_FILE_NOT_FOUND             5
#define FFSS_ERROR_ACCESS_DENIED              6
#define FFSS_ERROR_NOT_ENOUGH_SPACE           7
#define FFSS_ERROR_CANNOT_CONNECT             8
#define FFSS_ERROR_INTERNAL_ERROR             9
#define FFSS_ERROR_TOO_MANY_TRANSFERS        10
#define FFSS_ERROR_DIRECTORY_NOT_EMPTY       11
#define FFSS_ERROR_FILE_ALREADY_EXISTS       12
#define FFSS_ERROR_IDLE_TIMEOUT              13
#define FFSS_ERROR_SERVER_IS_QUIET           14
#define FFSS_ERROR_SHARE_DISABLED            15
#define FFSS_ERROR_SHARE_EJECTED             16
#define FFSS_ERROR_BUFFER_OVERFLOW           17
#define FFSS_ERROR_XFER_MODE_NOT_SUPPORTED   18
#define FFSS_ERROR_RESEND_LAST_UDP           19
#define FFSS_ERROR_BAD_SEARCH_REQUEST        20
#define FFSS_ERROR_NOT_IMPLEMENTED          100
#define FFSS_ERROR_NO_ERROR                 666

#define FFSS_ERROR_TRANSFER_MALLOC       1
#define FFSS_ERROR_TRANSFER_TIMEOUT      2
#define FFSS_ERROR_TRANSFER_SEND         3
#define FFSS_ERROR_TRANSFER_EOF          4
#define FFSS_ERROR_TRANSFER_READ_FILE    5
#define FFSS_ERROR_TRANSFER_ACCEPT       6
#define FFSS_ERROR_TRANSFER_OPENING      7
#define FFSS_ERROR_TRANSFER_RECV         8
#define FFSS_ERROR_TRANSFER_WRITE_FILE   9
#define FFSS_ERROR_TRANSFER_FILE_BIGGER 10
#define FFSS_ERROR_TRANSFER_CHECKSUM    11
#define FFSS_ERROR_TRANSFER_CANCELED    12

#define FFSS_FILE_DIRECTORY  1
#define FFSS_FILE_EXECUTABLE 2
#define FFSS_FILE_LINK       4

#define FFSS_COMPRESSION_NONE  0
#define FFSS_COMPRESSION_ZLIB  1
#define FFSS_COMPRESSION_BZLIB 2

#define FFSS_BZLIB_BLOCK100K 4
#define FFSS_BZLIB_SMALL 1

#define CRLF "\xD\xA"

/* ************************************************ */
/*                   DATA STRUCTURE                 */
/* ************************************************ */
typedef long int FFSS_Field;

typedef struct
{
  char *Name;
  FFSS_Field Flags;
  FFSS_Field Size;
  FFSS_Field Stamp;
} FC_TEntry, *FC_PEntry;

typedef struct
{
  char *Name;
  char *OS;
  char *Comment;
  char *IP;
  FFSS_Field State;
  long LastPong;
  long OffSince;
  /* Ajouter un pointeur sur la table d'index */
  long LastIndex; /* For Master use */
} FM_THost, *FM_PHost;

typedef struct
{
  char *Name;      /* Name of the domain */
  char *Master;    /* Address of the master of the domain */
  SU_PList Hosts;  /* FM_PHost */ /* Hosts of the domain */
} FM_TDomain, *FM_PDomain;

typedef struct
{
  long int total;
  FFSS_Field fsize,Checksum;
  FFSS_Field XFerTag;
  bool Download;
  bool UseConnSock;
} FFSS_TXFerInfo, *FFSS_PXFerInfo;

typedef struct
{
  int  sock;                /* Opened socket for file transfer */
//  FILE *fp;                 /* Opened file for reading/writing */
  int fp;
  char *FileName;           /* Remote file name */ /* NULL on server side */
  char *LocalPath;          /* Local path of file used for fopen */
  long int StartingPos;     /* Reading/Writing starting pos in the file */
  int  ThreadType;          /* Type of the thread (SERVER / CLIENT) */
//  SU_PClientSocket Client;  /* SU_PClientSocket structure of the share connection we transfer from */ /* Do NOT free this, only a pointer !! */
  FfssTCP *Client;
  bool Cancel;              /* If the transfer is to be canceled */
  void *User;               /* User information */
  FFSS_TXFerInfo XI;        /* XFer info for xfer using connection socket */
} FFSS_TTransfer, *FFSS_PTransfer;

typedef struct
{
  /* UDP callbacks */
  void (*OnPing)(struct sockaddr_in Master);
  void (*OnStateAnswer)(const char Domain[]);
  void (*OnServerSearch)(struct sockaddr_in Client);
  void (*OnSharesListing)(struct sockaddr_in Client);
  void (*OnIndexRequest)(struct sockaddr_in Master,FFSS_Field Port);
  void (*OnError)(FFSS_Field ErrorCode,const char Description[]);
  void (*OnMasterSearchAnswer)(struct sockaddr_in Master,FFSS_Field MasterVersion,const char Domain[]);

  /* TCP callbacks */
  bool (*OnShareConnection)(FfssTCP *Client,const char ShareName[],const char Login[],const char Password[],long int Compressions);
  bool (*OnDirectoryListing)(FfssTCP * Client,const char Path[]); /* Path IN the share (without share name) */
  bool (*OnDownload)(FfssTCP * Client,const char Path[],long int StartPos,int Port); /* Path IN the share (without share name) */
  bool (*OnUpload)(FfssTCP * Client,const char Path[],long int Size,int Port); /* Path IN the share (without share name) */
  bool (*OnRename)(FfssTCP * Client,const char Path[],const char NewPath[]); /* Path IN the share (without share name) */
  bool (*OnCopy)(FfssTCP * Client,const char Path[],const char NewPath[]); /* Path IN the share (without share name) */
  bool (*OnDelete)(FfssTCP * Client,const char Path[]); /* Path IN the share (without share name) */
  bool (*OnMkDir)(FfssTCP * Client,const char Path[]); /* Path IN the share (without share name) */
  void (*OnEndTCPThread)(void);
  bool (*OnSelect)(void); /* If true, don't do the timed-out select when returning from this callback */
  void (*OnIdleTimeout)(FfssTCP * Client);
  void (*OnTransferFailed)(FFSS_PTransfer FT,FFSS_Field ErrorCode,const char Error[],bool Download);
  void (*OnTransferSuccess)(FFSS_PTransfer FT,bool Download);
  void (*OnTransferActive)(FFSS_PTransfer FT,long int Amount,bool Download);
  void (*OnCancelXFer)(FfssTCP * Server,FFSS_Field XFerTag);
  void (*OnStrmOpen)(FfssTCP * Client,long int Flags,const char Path[]); /* Path IN the share (without share name) */
  void (*OnStrmClose)(FfssTCP * Client,long int Handle);
  void (*OnStrmRead)(FfssTCP * Client,long int Handle,long int StartPos);
  void (*OnStrmWrite)(FfssTCP * Client,long int Handle,long int StartPos,const char Bloc[],long int BlocSize);
  void (*OnStrmSeek)(FfssTCP * Client,long int Handle,long int Flags,long int Pos);

  /* FTP callbacks */
  bool (*OnConnectionFTP)(FfssTCP * Client);
  void (*OnPWDFTP)(FfssTCP * Client);
  void (*OnTypeFTP)(FfssTCP * Client,const char Type);
  void (*OnModeFTP)(FfssTCP * Client,const char Mode);
  bool (*OnDirectoryListingFTP)(FfssTCP * Client,FfssTCP * Data,const char Path[]);
  void (*OnCWDFTP)(FfssTCP * Client,const char Path[]);

  void (*OnDownloadFTP)(FfssTCP * Client,const char Path[],long int StartPos,const char Host[],const char Port[]); /* Path from the root of all shares */
  bool (*OnUploadFTP)(FfssTCP * Client,const char Path[],long int Size,int Port); /* Path from the root of all shares */
  bool (*OnRenameFTP)(FfssTCP * Client,const char Path[],const char NewPath[]); /* Path from the root of all shares */
  bool (*OnDeleteFTP)(FfssTCP * Client,const char Path[]); /* Path from the root of all shares */
  bool (*OnMkDirFTP)(FfssTCP * Client,const char Path[]); /* Path from the root of all shares */
  void (*OnEndTCPThreadFTP)(void);
  void (*OnIdleTimeoutFTP)(FfssTCP * Client);
} FFSS_TServerCallbacks, *FFSS_PServerCallbacks;

typedef struct
{
  /* UDP callbacks */
  void (*OnNewState)(FFSS_Field State,const char IP[],const char Domain[],const char Name[],const char OS[],const char Comment[],const char MasterIP[]);
  void (*OnSharesListing)(const char IP[],const char **Names,const char **Comments,int NbShares);
  /* WARNING !! (char *) of the FM_PHost structure are pointers to STATIC buffer, and must be dupped ! */
  /* Except for the FM_PHost->IP that is dupped internaly, and if you don't use it, you MUST free it !! */
  void (*OnServerListingAnswer)(const char Domain[],int NbHost,SU_PList HostList); /* SU_PList of FM_PHost */
  void (*OnEndServerListingAnswer)(void);
  void (*OnDomainListingAnswer)(const char **Domains,int NbDomains); /* First domain is assumed to be domain from the answering master */
  void (*OnMasterSearchAnswer)(struct sockaddr_in Master,FFSS_Field MasterVersion,const char Domain[]);
  void (*OnSearchAnswer)(const char Query[],const char Domain[],const char **Answers,int NbAnswers);
  void (*OnUDPError)(int ErrNum);

  /* TCP callbacks */
  void (*OnBeginTCPThread)(FfssTCP * Server);
  bool (*OnError)(FfssTCP * Server,int Code,const char Descr[]);
  bool (*OnDirectoryListingAnswer)(FfssTCP * Server,const char Path[],int NbEntries,SU_PList Entries);
  void (*OnEndTCPThread)(FfssTCP * Server);
  void (*OnIdleTimeout)(FfssTCP * Server);
  void (*OnTransferFailed)(FFSS_PTransfer FT,FFSS_Field ErrorCode,const char Error[],bool Download);
  void (*OnTransferSuccess)(FFSS_PTransfer FT,bool Download);
  void (*OnTransferActive)(FFSS_PTransfer FT,long int Amount,bool Download);
  FFSS_PTransfer (*OnInitXFer)(FfssTCP * Server,const char RequestedFileName[]); /* Returns PTransfer from RequestedFileName */
  FFSS_PTransfer (*OnData)(FfssTCP * Server,FFSS_Field XFerTag); /* Returns PTransfer from XFerTag */
  void (*OnStrmOpenAnswer)(FfssTCP * Client,const char Path[],int Code,long int Handle,long int FileSize);
  void (*OnStrmReadAnswer)(FfssTCP * Client,long int Handle,const char Bloc[],long int BlocSize);
  void (*OnStrmWriteAnswer)(FfssTCP * Client,long int Handle,int Code);

  /* Fatal error */
  void (*OnFatalError)(void);
} FFSS_TClientCallbacks, *FFSS_PClientCallbacks;

typedef struct
{
  /* UDP callbacks */
  void (*OnState)(struct sockaddr_in Server,FFSS_Field State,FFSS_Field ServerVersion,const char Name[],const char OS[],const char Comment[]);
  void (*OnNewState)(FFSS_Field State,const char IP[],const char Domain[],const char Name[],const char OS[],const char Comment[],const char MasterIP[]);
  void (*OnServerListing)(struct sockaddr_in Client,const char OS[],const char Domain[],long int Compressions);
//  void (*OnServerListingAnswer)(const char Domain[],const char NbHost,SU_PList HostList); /* SU_PList of FM_PHost */ /* WARNING !! (char *) of the FM_PHost structure are pointers to STATIC buffer, and must be dupped ! */
  void (*OnClientServerFailed)(const char IP[]);
  void (*OnPong)(struct sockaddr_in Server,FFSS_Field State);
  void (*OnDomainListing)(struct sockaddr_in Client);
  void (*OnSearch)(struct sockaddr_in Client,int Port,const char Domain[],const char KeyWords[],long int Compressions);
  void (*OnSearchForward)(struct sockaddr_in Master,const char ClientIP[],int Port,const char KeyWords[],long int Compressions);
  void (*OnMasterSearch)(struct sockaddr_in Client,bool Server);
  void (*OnIndexAnswer)(struct sockaddr_in Client,FFSS_Field CompressionType,FFSS_Field IndexSize,int Port);
} FFSS_TMasterCallbacks, *FFSS_PMasterCallbacks;

typedef struct
{
  FFSS_TServerCallbacks SCB;
  FFSS_TClientCallbacks CCB;
  FFSS_TMasterCallbacks MCB;
} FFSS_TCallbacks, *FFSS_PCallbacks;

typedef struct
{
  long int Handle;
  char *Buf;
  long int BufSize;
} FC_THandle, *FC_PHandle;

/* ************************************************ */
/*                 EXTERN VARIABLES                 */
/* ************************************************ */
#ifdef _WIN32
extern unsigned long FS_THR_UDP,FS_THR_TCP,FS_THR_TCP_FTP;
extern unsigned long FC_THR_UDP;
extern unsigned long FM_THR_UDP;
#else
extern pthread_t FS_THR_UDP,FS_THR_TCP,FS_THR_TCP_FTP;
extern pthread_t FC_THR_UDP;
extern pthread_t FM_THR_UDP;
#endif
extern FFSS_TCallbacks FFSS_CB;
extern char *FFSS_MyIP;

extern char *FFSS_ErrorTable[];

void FFSS_PrintDebug(int Level,char *Txt, ...);


/* ************************************************ */
/*              FFSS SERVER FUNCTIONS               */
/* ************************************************ */

/* FFSS Server : Init */
/* Initialisation of the FFSS Server - Must be called before any other FFSS function */
/* Returns true on success, false otherwise */
bool FS_Init(int ServerPort,bool FTP);

/* FFSS Server : UnInit */
/* Uninitialisation of the FFSS Server - Must be called at the end of the main */
/* Returns true on success, false otherwise */
bool FS_UnInit(void);


/* ************************************************ */
/*              FFSS CLIENT FUNCTIONS               */
/* ************************************************ */

/* FFSS Client : Init */
/* Initialisation of the FFSS Client - Must be called before any other FFSS function */
/* Returns true on success, false otherwise */
bool FC_Init(void);

/* FFSS Client : UnInit */
/* Uninitialisation of the FFSS Client - Must be called at the end of the main */
/* Returns true on success, false otherwise */
bool FC_UnInit(void);


/* ************************************************ */
/*              FFSS MASTER FUNCTIONS               */
/* ************************************************ */

/* FFSS Master : Init */
/* Initialisation of the FFSS Master - Must be called before any other FFSS function */
/* Returns true on success, false otherwise */
bool FM_Init(int MasterPort);

/* FFSS Master : UnInit */
/* Uninitialisation of the FFSS Master - Must be called at the end of the main */
/* Returns true on success, false otherwise */
bool FM_UnInit(void);

/* ************************************************ */
/*              FFSS DRIVER FUNCTIONS               */
/* ************************************************ */
FC_PHandle FC_CreateHandle(void);
void FC_FreeHandle(FC_PHandle Hdl);
/* Return true on success, false otherwise. If error, the socket is closed */
bool FC_WaitDataTCP(FfssTCP * Client,FC_PHandle Hdl);
/*
  The 'bool FC_Init(void)' and 'bool FC_UnInit(void)' functions have the same prototype than CLIENT's one
*/

/* ************************************************ */
/*               FFSS UTILS FUNCTIONS               */
/* ************************************************ */

/* FFSS_ComputeChecksum                                     */
/* Computes and updates the Checksum of a buffer            */
/* Set Buf to NULL for the first call, to init the checksum */
FFSS_Field FFSS_ComputeChecksum(FFSS_Field Old,const char Buf[],long int Len);

/* Retrieve local IP of interface named IntName */
//bool FFSS_GetMyIP(SU_PServerInfo SI,const char IntName[]);

/* ************************************************ */
/*              FFSS TRANSFER FUNCTIONS             */
/* ************************************************ */

/* If FT_out is NULL, not filled */
bool FFSS_UploadFile(FfssTCP * Client,const char FilePath[],long int StartingPos,int Port,void *User,bool UseConnSock,FFSS_PTransfer *FT_out);

/* RemotePath in the share */
/* If FT_out is NULL, not filled */
bool FFSS_DownloadFile(FfssTCP * Server,const char RemotePath[],const char LocalPath[],long int StartingPos,void *User,bool UseConnSock,FFSS_PTransfer *FT_out);


/* ************************************************ */
/*                  SERVER MESSAGES                 */
/* ************************************************ */

/* FS_SendMessage_State Function                    */
/* Sends a STATE message to a master                */
/*  Master : The name of my master, or NULL if none */
/*  Name : The name of my server                    */
/*  OS : The os of my server                        */
/*  Comment : The comment of my server              */
/*  State : The new state of my server              */
bool FS_SendMessage_State(const char Master[],const char Name[],const char OS[],const char Comment[],int State);

/* FS_SendMessage_ServerSearchAnswer Function       */
/* Sends a STATE message to a client                */
/*  Domain : The domain of my master                */
/*  Name : The name of my server                    */
/*  OS : The os of my server                        */
/*  Comment : The comment of my server              */
/*  State : The state of my server                  */
/*  IP : The IP address of my server                */
/*  MasterIP : The IP address of my server          */
bool FS_SendMessage_ServerSearchAnswer(struct sockaddr_in Client,const char Domain[],const char Name[],const char OS[],const char Comment[],int State,const char IP[],const char MasterIP[]);

/* FS_SendMessage_ServerSharesAnswer Function                */
/* Sends a SHARES ANSWER message to a client                 */
/*  IP : The IP address of my server                         */
/*  ShareNames : A tab of the share names of my server       */
/*  ShareComments : A tab of the share comments of my server */
/*  NbShares : The number of shares of my server             */
bool FS_SendMessage_ServerSharesAnswer(struct sockaddr_in Client,const char IP[],const char **ShareNames,const char **ShareComments,int NbShares);

/* FS_SendMessage_Pong Function     */
/* Sends a PONG message to a master */
/*  Master : The sin of my master   */
/*  State : The state of my server  */
bool FS_SendMessage_Pong(struct sockaddr_in Master,int State);

/* FS_SendMessage_Error Function              */
/* Sends an ERROR message to a client         */
/*  Client : The socket of the client         */
/*  Code : The error code to send             */
/*  Descr : The description of the error code */
bool FS_SendMessage_Error(int Client,FFSS_Field Code,const char Descr[]);

/* FS_SendMessage_DirectoryListingAnswer Function                     */
/* Sends a DIRECTORY LISTING ANSWER message to a client               */
/*  Client : The socket of the client                                 */
/*  Path : The path of the directory IN the share                     */
/*  Buffer : The buffer containing the nb of entries, and the entries */
/*  BufSize : The size of the buffer                                  */
/*  Compression : The type of compression to be applied to Buffer     */
bool FS_SendMessage_DirectoryListingAnswer(int Client,const char Path[],const char *Buffer,long int BufSize,int Compression);

/* FS_SendMessage_InitXFer Function                        */
/* Sends an INIT XFER message to a client                  */
/*  Client : The socket of the client                      */
/*  Tag : The xfer tag that will be used when sending data */
/*  FileName : The name of the requested file              */
bool FS_SendMessage_InitXFer(int Client,FFSS_Field Tag,const char FileName[]);

/* FS_SendMessage_MasterSearch Function      */
/* Sends a MASTER SEARCH message to broadcast */
bool FS_SendMessage_MasterSearch();

/* FS_SendMessage_IndexAnswer Function                             */
/* Sends an INDEX ANSWER message to someone                        */
/*  Host : The name of the host to send to                         */
/*  Port : The port to use                                         */
/*  Buffers : Chained list of share buffers                        */
/*  Sizes : Chained list of sizes of share buffers                 */
/*  Compression : The type of compression to be applied to Buffers */
bool FS_SendMessage_IndexAnswer(const char Host[],const char Port[],SU_PList Buffers,SU_PList Sizes,int Compression);


/* ************************************************ */
/*                  CLIENT MESSAGES                 */
/* ************************************************ */

/* FC_SendMessage_ServerSearch Function       */
/* Sends a SERVER SEARCH message to broadcast */
bool FC_SendMessage_ServerSearch(void);

/* FC_SendMessage_SharesListing Function                       */
/* Sends a SHARES LISTING message to a server                  */
/*  Server : The name of the server we want the shares listing */
bool FC_SendMessage_SharesListing(const char Server[]);

/* NC_SendMessage_ServerList Function                      */
/* Sends a SERVER LIST message to a master                 */
/*  Master : The name of my master, or NULL if none        */
/*  OS : The desired OS, or NULL if requesting all         */
/*  Domain : The desired domain, or NULL if requesting all */
bool FC_SendMessage_ServerList(const char Master[],const char OS[],const char Domain[]);

/* FC_SendMessage_ShareConnect Function                  */
/* Sends a SHARE CONNECTION message to a server          */
/*  Server : The name of Server we wish to connect to    */
/*  ShareName : The Share Name we wish to connect to     */
/*  Login : The Login we may use (or NULL if none)       */
/*  Password : The Password we may use (or NULL if none) */
FfssTCP * FC_SendMessage_ShareConnect(const char Server[],const char ShareName[],const char Login[],const char Password[]);

/* FC_SendMessage_DirectoryListing Function             */
/* Sends a DIRECTORY LISTING message to a server        */
/*  Server : The Server's structure we are connected to */
/*  Path : The path we request a listing                */
bool FC_SendMessage_DirectoryListing(FfssTCP * Server,const char Path[]);

/* FC_SendMessage_Download Function                                 */
/* Sends a DOWNLOAD message to a server                             */
/*  Server : The Server's structure we are connected to             */
/*  Path : The path of requested file (in the share)                */
/*  StartingPos : The pos we want to download the file starting at  */
/*  UseConnSock : Use a separate socket/thread, or use the existing */
KStreamServer<FfssTCPXfer> *FC_SendMessage_Download(FfssTCP * Server,const char Path[],long int StartingPos,bool UseConnSock);

/* FC_SendMessage_Disconnect Function                   */
/* Sends an DISCONNECT message to a server              */
/*  Server : The Server's structure we are connected to */
void FC_SendMessage_Disconnect(FfssTCP * Server);

/* FC_SendMessage_CancelXFer Function                   */
/* Sends an CANCEL XFER message to a server             */
/*  Server : The Server's structure we are connected to */
/*  XFerTag : The tag of the xfer we want to cancel     */
void FC_SendMessage_CancelXFer(FfssTCP * Server,FFSS_Field XFerTag);

/* FC_SendMessage_DomainListing Function   */
/* Sends a DOMAIN LIST message to a master */
/*  Master : The name of my master         */
bool FC_SendMessage_DomainListing(const char Master[]);

/* FC_SendMessage_Search Function                          */
/* Sends a SEARCH message to a master                      */
/*  Master : The name of my master                         */
/*  Domain : The desired domain, or NULL if requesting all */
/*  Keys   : A String of keywords                          */
bool FC_SendMessage_Search(const char Master[],const char Domain[],const char Key[]);

/* FC_SendMessage_MasterSearch Function       */
/* Sends a MASTER SEARCH message to broadcast */
bool FC_SendMessage_MasterSearch();

/* FC_SendMessage_StrmOpen Function                     */
/* Sends an STREAMING OPEN message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Path : The path of the requested file               */
/*  Flags : The opening mode flags                      */
bool FC_SendMessage_StrmOpen(FfssTCP * Server,const char Path[],int Flags);

/* FC_SendMessage_StrmClose Function                     */
/* Sends an STREAMING CLOSE message to a server          */
/*  Server : The Server's structure we are connected to  */
/*  Handle : The handle of the file to close             */
bool FC_SendMessage_StrmClose(FfssTCP * Server,long int Handle);

/* FC_SendMessage_StrmRead Function                     */
/* Sends an STREAMING READ message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  StartPos : The start position of the requested bloc */
bool FC_SendMessage_StrmRead(FfssTCP * Server,long int Handle,long int StartPos,long int Length);

/* FC_SendMessage_StrmWrite Function                    */
/* Sends an STREAMING WRITE message to a server         */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  StartPos : The start position of the requested bloc */
/*  Buf : The buffer of datas                           */
/*  BlocLen : The length of the datas                   */
bool FC_SendMessage_StrmWrite(FfssTCP * Server,long int Handle,long int StartPos,char *Buf,long int BlocLen);

/* FC_SendMessage_StrmSeek Function                     */
/* Sends an STREAMING SEEK message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  Flags : The flags for the seek operation            */
/*  StartPos : The position of the seek                 */
bool FC_SendMessage_StrmSeek(FfssTCP * Server,long int Handle,int Flags,long int StartPos);


/* ************************************************ */
/*                  MASTER MESSAGES                 */
/* ************************************************ */

/* FM_SendMessage_Ping Function    */
/* Sends a PING message to servers */
bool FM_SendMessage_Ping();

/* FM_SendMessage_NewStatesClients Function                         */
/* Sends a NEW STATES message to clients                            */
/*  Buffer : The buffer containing the nb of states, and the states */
/*  BufSize : The size of the buffer                                */
/*  Compression : The type of compression to be applied to Buffer   */
  /* !!!!!!!!!!!!!!!!!!!!! USELESS FUNCTION !!!!!!!!!!!!!!!!!!!!!!!!!!! */
  /* Client should NOT be listening on a fixed port, or we won't be able to run multiple clients on the same host */
//bool FM_SendMessage_NewStatesClients(const char *Buffer,long int BufSize,int Compression);

/* FM_SendMessage_NewStatesMaster Function                          */
/* Sends a NEW STATES message to a master                           */
/*  Master : The name of the master we want to send states          */
/*  Buffer : The buffer containing the nb of states, and the states */
/*  BufSize : The size of the buffer                                */
/*  Compression : The type of compression to be applied to Buffer   */
bool FM_SendMessage_NewStatesMaster(const char Master[],const char *Buffer,long int BufSize,int Compression);

/* FM_SendMessage_ServerListing Function                            */
/* Sends a NEW STATES message to client                             */
/*  Client : The sin of the client                                  */
/*  Buffer : The buffer containing the nb of domains, and the hosts */
/*  BufSize : The size of the buffer                                */
/*  Compression : The type of compression to be applied to Buffer   */
bool FM_SendMessage_ServerListing(struct sockaddr_in Client,const char *Buffer,long int BufSize,int Compression);

/* FM_SendMessage_Error Function              */
/* Sends an ERROR message to a server         */
/*  Server : The name of the server           */
/*  Code : The error code to send             */
/*  Descr : The description of the error code */
bool FM_SendMessage_Error(const char Server[],FFSS_Field Code,const char Descr[]);

/* FM_SendMessage_ErrorClient Function        */
/* Sends an ERROR message to a client         */
/*  Client : The sin of the client            */
/*  Code : The error code to send             */
/*  Descr : The description of the error code */
bool FM_SendMessage_ErrorClient(struct sockaddr_in Client,FFSS_Field Code,const char Descr[]);

/* FM_SendMessage_ServerList Function              */
/* Sends a SERVER LIST message to a foreign master */
/*  Master : The name of the foreign master        */
bool FM_SendMessage_ServerList(const char Master[]);

/* FM_SendMessage_DomainListingAnswer Function */
/* Sends a DOMAIN ANSWER message to client     */
/*  Client : The sin of the client             */
/*  Domains : A SU_PList of FM_PDomain         */
bool FM_SendMessage_DomainListingAnswer(struct sockaddr_in Client,SU_PList Domains);

/* FM_SendMessage_MasterSearchAnswer Function               */
/* Sends a MASTER SEARCH ANSWER message to client or server */
/*  Client : The sin of the client or the server            */
/*  Server : True if from server                            */
/*  Domain : The name of my domain                          */
bool FM_SendMessage_MasterSearchAnswer(struct sockaddr_in Client,bool Server,const char Domain[]);

/* FM_SendMessage_SearchAnswer Function                                          */
/* Sends a SEARCH ANSWER message to client                                       */
/*  Client : The sin of the client                                               */
/*  Buffer : The buffer containing the query, the nb of answers, and the answers */
/*  BufSize : The size of the buffer                                             */
/*  Compression : The type of compression to be applied to Buffer                */
bool FM_SendMessage_SearchAnswer(struct sockaddr_in Client,const char *Buffer,long int BufSize,int Compression);



/* ************************************************************************* */
/* TRANSFER.H                                                                */
/* ************************************************************************* */
void FFSS_FreeTransfer(FFSS_PTransfer T);
bool FFSS_SendData(FFSS_PTransfer FT,FFSS_Field Tag,char *Buf,int len);
void FFSS_OnDataDownload(FFSS_PTransfer FT,const char Buf[],int Len);
void FFSS_InitXFerDownload(FFSS_PTransfer FT,FFSS_Field XFerTag);
extern char *FFSS_TransferErrorTable[];
extern long int FFSS_TransferBufferSize;
extern long int FFSS_TransferReadBufferSize;

/* ************************************************************************* */
/* UTILS.H                                                                   */
/* ************************************************************************* */
/* Unpacks a string from a message, checking if the string really terminates (prevents DoS attacks) */
/*  Returns the string, or NULL if there is a problem */
char *FFSS_UnpackString(const char beginning[],const char buf[],int len,long int *new_pos);
/* Unpacks a FFSS_Field from a message, checking if the FFSS_Field is fully in the message (prevents DoS attacks) */
/*  Returns the FFSS_Field, or 0 if there is a problem */
FFSS_Field FFSS_UnpackField(const char beginning[],const char buf[],int len,long int *new_pos);
void FFSS_UnpackIP(const char beginning[],char *buf,int len,long int *new_pos,char buf_out[],int Type);
void FFSS_PackIP(char *buf,const char IP[],int Type);

bool FFSS_CompresseZlib(char *in,long int len_in,char *out,long int *len_out);
char *FFSS_UncompresseZlib(char *in,long int len_in,long int *len_out);
#ifdef HAVE_BZLIB
bool FFSS_CompresseBZlib(char *in,long int len_in,char *out,long int *len_out);
char *FFSS_UncompresseBZlib(char *in,long int len_in,long int *len_out);
#endif

extern int N_DebugLevel;

#endif
