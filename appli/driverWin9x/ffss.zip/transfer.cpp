#include "divers.h"
#include "ffss.h"
#include "utils.h"
#include "common.h"

char *FFSS_TransferErrorTable[]={"","Transfer buffer allocation failed","Timed out","Send error","EOF from remote host","Error reading file","Error accepting connection","Error opening file","Recv error","Local write error. Disk full ?","Received file bigger than specified","Checksum check failed","Transfer canceled"};
long int FFSS_TransferBufferSize = FFSS_TRANSFER_BUFFER_SIZE;
long int FFSS_TransferReadBufferSize = FFSS_TRANSFER_READ_BUFFER_SIZE;

void FFSS_FreeTransfer(FFSS_PTransfer T)
{
/*  if(T->FileName != NULL)
    free(T->FileName);
  if(T->LocalPath != NULL)
    free(T->LocalPath);
  if(T->fp != NULL)
    fclose(T->fp);
  if(!T->XI.UseConnSock)
  {
#ifdef __unix__
    close(T->sock);
#else
    closesocket(T->sock);
#endif
  }
  free(T);*/
}

#ifdef _WIN32
void FFSS_UploadFileFunc(void *Info)
#else
void *FFSS_UploadFileFunc(void *Info)
#endif
{
#ifdef ENABLE_XFERS
  FFSS_PTransfer FT = (FFSS_PTransfer) Info;
  long int total=0,rpos=0,rlen;
  FFSS_Field fsize,Checksum;
  fd_set rfds;
  struct timeval tv;
  int retval,res,len;
  char *RBuf;
  time_t t1,t2;

  fseek(FT->fp,0,SEEK_END);
  fsize = ftell(FT->fp);
  rewind(FT->fp);
  printf("In ul thread.... computing chksum\n");
  Checksum = FFSS_ComputeChecksum(0,NULL,0);
  printf("done with chksum\n");

  if(FFSS_TransferReadBufferSize == 0)
    FFSS_TransferReadBufferSize = FFSS_TRANSFER_READ_BUFFER_SIZE;
  RBuf = (char *) malloc(FFSS_TransferReadBufferSize);
  if(RBuf == NULL)
  {
    dprintf("Cannot allocate buffer in Upload function\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_MALLOC,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_MALLOC],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_MALLOC,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_MALLOC],false);
    }
    FFSS_FreeTransfer(FT);
#ifdef __unix__
    return (void *)1;
#else
    _endthread();
#endif
  }
  t1 = time(NULL);
  /* Send File Size */
  FD_ZERO(&rfds);
  FD_SET(FT->sock,&rfds);
  tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
  tv.tv_usec = 0;
  retval = select(FT->sock+1,NULL,&rfds,NULL,&tv);
  if(!retval)
  {
    dprintf("Transfer timed out\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)1;
#else
    _endthread();
#endif
  }
  printf("Sending size...\n");
  res = send(FT->sock,(char *)&fsize,sizeof(fsize),SU_MSG_NOSIGNAL);
  if(res == SOCKET_ERROR)
  {
    dprintf("Error while uploading file (size) : %d %s\n",errno,strerror(errno));
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)2;
#else
    _endthread();
#endif
  }
  else if(res == 0)
  {
    dprintf("EOF from remote host while uploading file\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)3;
#else
    _endthread();
#endif
  }
  printf("size sent\n");

  while(total < fsize)
  {
    if(FT->Cancel)
    {
      printf("IN CANCEL !!!\n");
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CANCELED,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CANCELED],false);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CANCELED,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CANCELED],false);
      }
      FFSS_FreeTransfer(FT);
#ifdef __unix__
      return (void *)1;
#else
      _endthread();
#endif
    }
    if((total+FFSS_TransferReadBufferSize) <= fsize)
      rlen = FFSS_TransferReadBufferSize;
    else
      rlen = fsize - total;
    printf("Reading file from disk\n");
    if(fread(RBuf,1,rlen,FT->fp) != rlen)
    {
      dprintf("Error reading file while uploading : %d\n",errno);
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_READ_FILE,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_READ_FILE],false);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_READ_FILE,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_READ_FILE],false);
      }
      FFSS_FreeTransfer(FT);
      free(RBuf);
#ifdef __unix__
      return (void *)4;
#else
      _endthread();
#endif
    }
    printf("compute block chksum...\n");
    Checksum = FFSS_ComputeChecksum(Checksum,RBuf,rlen);
    printf("done with block chksum\n");
    rpos = 0;
    while(rpos < rlen)
    {
      if((rpos+FFSS_TransferBufferSize) <= rlen)
        len = FFSS_TransferBufferSize;
      else
        len = rlen - rpos;
      FD_ZERO(&rfds);
      FD_SET(FT->sock,&rfds);
      tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
      tv.tv_usec = 0;
      retval = select(FT->sock+1,NULL,&rfds,NULL,&tv);
      if(!retval)
      {
        dprintf("Transfer timed out while uploading file\n");
        if(FT->ThreadType == FFSS_THREAD_SERVER)
        {
          if(FFSS_CB.SCB.OnTransferFailed != NULL)
            FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
        }
        else
        {
          if(FFSS_CB.CCB.OnTransferFailed != NULL)
            FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
        }
        FFSS_FreeTransfer(FT);
        free(RBuf);
#ifdef __unix__
        return (void *)5;
#else
        _endthread();
#endif
      }
      res = 0;
      while(res != len)
      {
        printf("Sending block to client...\n");
        res += send(FT->sock,RBuf+rpos+res,len-res,SU_MSG_NOSIGNAL);
        if(res <= 0)
        {
          dprintf("Error while uploading file (buf) : %d %s\n",errno,strerror(errno));
          if(FT->ThreadType == FFSS_THREAD_SERVER)
          {
            if(FFSS_CB.SCB.OnTransferFailed != NULL)
              FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
          }
          else
          {
            if(FFSS_CB.CCB.OnTransferFailed != NULL)
              FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
          }
          FFSS_FreeTransfer(FT);
          free(RBuf);
#ifdef __unix__
          return (void *)5;
#else
          _endthread();
#endif
        }
        printf("done block send\n");
      }
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferActive != NULL)
          FFSS_CB.SCB.OnTransferActive(FT,len,false);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferActive != NULL)
          FFSS_CB.CCB.OnTransferActive(FT,len,false);
      }
      rpos += len;
    }
    total += rlen;
  }

  /* Send Checksum */
  FD_ZERO(&rfds);
  FD_SET(FT->sock,&rfds);
  tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
  tv.tv_usec = 0;
  retval = select(FT->sock+1,NULL,&rfds,NULL,&tv);
  if(!retval)
  {
    dprintf("Transfer timed out\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)1;
#else
    _endthread();
#endif
  }
  res = send(FT->sock,(char *)&Checksum,sizeof(Checksum),SU_MSG_NOSIGNAL);
  if(res == SOCKET_ERROR)
  {
    dprintf("Error while uploading file (chksum) : %d %s\n",errno,strerror(errno));
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)2;
#else
    _endthread();
#endif
  }
  else if(res == 0)
  {
    dprintf("EOF from client while uploading file\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],false);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],false);
    }
    FFSS_FreeTransfer(FT);
    free(RBuf);
#ifdef __unix__
    return (void *)3;
#else
    _endthread();
#endif
  }

  if(FT->ThreadType == FFSS_THREAD_SERVER)
  {
    if(FFSS_CB.SCB.OnTransferSuccess != NULL)
      FFSS_CB.SCB.OnTransferSuccess(FT,false);
  }
  else
  {
    if(FFSS_CB.CCB.OnTransferSuccess != NULL)
      FFSS_CB.CCB.OnTransferSuccess(FT,false);
  }
  FFSS_FreeTransfer(FT);
  free(RBuf);
  t2 = time(NULL);
  if(t1 == t2)
    t2 = t1+1;
  dprintf("Successfully uploaded the file in %d sec (%.2f ko/s)\n",((int)(t2-t1)),fsize/1024.0/(t2-t1));
#ifdef __unix__
  return 0;
#endif
#endif
}

#ifdef _WIN32
void FFSS_DownloadFileFunc(void *Info)
#else
void *FFSS_DownloadFileFunc(void *Info)
#endif
{
#ifdef ENABLE_XFER
  FFSS_PTransfer FT = (FFSS_PTransfer) Info;
  struct sockaddr sad;
  int len;
  int client;
  char Buf[FFSS_TRANSFER_BUFFER_SIZE];
  int res;
  long int total=0;
  fd_set rfds;
  struct timeval tv;
  int retval;
  FILE *fp;
  FFSS_Field Size;
  FFSS_Field ChkSum,Checksum;
  bool error = false;
  time_t t1,t2;

  Checksum = FFSS_ComputeChecksum(0,NULL,0);

  FD_ZERO(&rfds);
  FD_SET(FT->sock,&rfds);
  tv.tv_sec = FFSS_TIMEOUT_ACCEPT;
  tv.tv_usec = 0;
  retval = select(FT->sock+1,&rfds,NULL,NULL,&tv);
  if(!retval)
  {
    dprintf("Error accepting connection (timed out)\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
    }
    FFSS_FreeTransfer(FT);
#ifdef __unix__
    return 0;
#else
    _endthread();
#endif
  }
  len = sizeof(sad);
  client = accept(FT->sock,&sad,&len);
#ifdef __unix__
  close(FT->sock);
#else
  closesocket(FT->sock);
#endif
  FT->sock = client;
  dprintf("Connection accepted from %s\n",inet_ntoa(((struct sockaddr_in *)&sad)->sin_addr));
  if(FT->sock == SOCKET_ERROR)
  {
    dprintf("Error accepting connections\n");
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_ACCEPT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_ACCEPT],true);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_ACCEPT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_ACCEPT],true);
    }
    FFSS_FreeTransfer(FT);
#ifdef __unix__
    return 0;
#else
    _endthread();
#endif
  }
  t1 = time(NULL);
  if(FT->StartingPos != 0)
    fp = fopen(FT->LocalPath,"ab");
  else
    fp = fopen(FT->LocalPath,"wb");
  if(fp == NULL)
  {
    dprintf("Can't open local file for writting (%s)\n",FT->LocalPath);
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_OPENING,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_OPENING],true);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_OPENING,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_OPENING],true);
    }
    FFSS_FreeTransfer(FT);
#ifdef __unix__
    return 0;
#else
    _endthread();
#endif
  }
  FD_ZERO(&rfds);
  FD_SET(FT->sock,&rfds);
  tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
  tv.tv_usec = 0;
  retval = select(FT->sock+1,&rfds,NULL,NULL,&tv);
  if(!retval)
  {
    dprintf("Transfer timed out while downloading file\n");
    /* Remove or not file from disk (ask user) */
    fclose(fp);
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
    }
    error = true;
  }
  if(!error)
  {
    res = recv(FT->sock,(char *)&Size,sizeof(Size),SU_MSG_NOSIGNAL);
    if(res == SOCKET_ERROR)
    {
      dprintf("Error while downloading file (size) : %d %s\n",errno,strerror(errno));
      /* Remove or not file from disk (ask user) */
      fclose(fp);
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_RECV,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_RECV],true);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_RECV,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_RECV],true);
      }
      error = true;
    }
    else if(res == 0)
    {
      dprintf("EOF from server while downloading file\n");
      /* Remove or not file from disk (ask user) */
      fclose(fp);
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],true);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],true);
      }
      error = true;
    }
    Size += sizeof(Checksum); /* Adds size of the checksum */
  }

  while(!error)
  {
    if(FT->Cancel)
    {
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CANCELED,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CANCELED],true);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CANCELED,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CANCELED],true);
      }
      FFSS_FreeTransfer(FT);
  #ifdef __unix__
      return (void *)1;
  #else
      _endthread();
  #endif
    }
    FD_ZERO(&rfds);
    FD_SET(FT->sock,&rfds);
    tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
    tv.tv_usec = 0;
    retval = select(FT->sock+1,&rfds,NULL,NULL,&tv);
    if(!retval)
    {
      dprintf("Transfer timed out while downloading file\n");
      /* Remove or not file from disk (ask user) */
      fclose(fp);
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],true);
      }
      error = true;
    }
    if(!error)
    {
      res = recv(FT->sock,Buf,sizeof(Buf),SU_MSG_NOSIGNAL);
      if(res == SOCKET_ERROR)
      {
        dprintf("Error while downloading file (buf) : %d %s\n",errno,strerror(errno));
        /* Remove or not file from disk (ask user) */
        fclose(fp);
        if(FT->ThreadType == FFSS_THREAD_SERVER)
        {
          if(FFSS_CB.SCB.OnTransferFailed != NULL)
            FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_RECV,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_RECV],true);
        }
        else
        {
          if(FFSS_CB.CCB.OnTransferFailed != NULL)
            FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_RECV,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_RECV],true);
        }
        error = true;
      }
      else if(res == 0)
      {
        dprintf("EOF from server while downloading file\n");
        /* Remove or not file from disk (ask user) */
        fclose(fp);
        if(FT->ThreadType == FFSS_THREAD_SERVER)
        {
          if(FFSS_CB.SCB.OnTransferFailed != NULL)
            FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],true);
        }
        else
        {
          if(FFSS_CB.CCB.OnTransferFailed != NULL)
            FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],true);
        }
        error = true;
      }
      else
      {
        if(FT->ThreadType == FFSS_THREAD_SERVER)
        {
          if(FFSS_CB.SCB.OnTransferActive != NULL)
            FFSS_CB.SCB.OnTransferActive(FT,res,true);
        }
        else
        {
          if(FFSS_CB.CCB.OnTransferActive != NULL)
            FFSS_CB.CCB.OnTransferActive(FT,res,true);
        }
      }
      if(!error)
      {
        total += res;
        if(total == Size)
          res -= sizeof(Checksum);
        if(fwrite(Buf,1,res,fp) != res)
        {
          dprintf("Disk full ?\n");
          /* Remove or not file from disk (ask user) */
          fclose(fp);
          if(FT->ThreadType == FFSS_THREAD_SERVER)
          {
            if(FFSS_CB.SCB.OnTransferFailed != NULL)
              FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_WRITE_FILE,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_WRITE_FILE],true);
          }
          else
          {
            if(FFSS_CB.CCB.OnTransferFailed != NULL)
              FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_WRITE_FILE,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_WRITE_FILE],true);
          }
          error = true;
        }
        Checksum = FFSS_ComputeChecksum(Checksum,Buf,res);
        if(!error)
        {
          if(total == Size)
          {
            ChkSum = *((FFSS_Field *)(Buf+res));
#ifdef DISABLE_CHECKSUM
            if(true)
#else
            if((ChkSum == Checksum) || (ChkSum == 1)) /* A ChkSum of 1 means NO checksum on the other side */
#endif
            {
              dprintf("File successfully downloaded\n");
              fclose(fp);
              if(FT->ThreadType == FFSS_THREAD_SERVER)
              {
                if(FFSS_CB.SCB.OnTransferSuccess != NULL)
                  FFSS_CB.SCB.OnTransferSuccess(FT,true);
              }
              else
              {
                if(FFSS_CB.CCB.OnTransferSuccess != NULL)
                  FFSS_CB.CCB.OnTransferSuccess(FT,true);
              }
            }
            else
            {
              dprintf("Checksum check failed\n");
              /* Remove or not file from disk (ask user) */
              fclose(fp);
              if(FT->ThreadType == FFSS_THREAD_SERVER)
              {
                if(FFSS_CB.SCB.OnTransferFailed != NULL)
                  FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CHECKSUM,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CHECKSUM],true);
              }
              else
              {
                if(FFSS_CB.CCB.OnTransferFailed != NULL)
                  FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CHECKSUM,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CHECKSUM],true);
              }
              error = true;
            }
            break;
          }
          else if(total > Size)
          {
            dprintf("Received data bigger than file size (%ld - %ld)\n",total,Size);
            /* Remove or not file from disk (ask user) */
            fclose(fp);
            if(FT->ThreadType == FFSS_THREAD_SERVER)
            {
              if(FFSS_CB.SCB.OnTransferFailed != NULL)
                FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_FILE_BIGGER,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_FILE_BIGGER],true);
            }
            else
            {
              if(FFSS_CB.CCB.OnTransferFailed != NULL)
                FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_FILE_BIGGER,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_FILE_BIGGER],true);
            }
            error = true;
          }
        }
      }
    }
  }
  FFSS_FreeTransfer(FT);
  if(!error)
  {
    t2 = time(NULL);
    if(t1 == t2)
      t2 = t1+1;
    dprintf("Successfully downloaded the file in %d sec (%.2f ko/s)\n",((int)(t2-t1)),Size/1024.0/(t2-t1));
  }
#ifdef __unix__
  return 0;
#else
  _endthread();
#endif
#endif
}


bool FFSS_UploadFile(FfssTCP * Client,const char FilePath[],long int StartingPos,int Port,void *User,bool UseConnSock,FFSS_PTransfer *FT_out)
{
#ifdef ENABLE_XFER
  FILE *fp;
#ifdef __unix__
  pthread_t Thread;
#else
  unsigned long Thread;
#endif
  struct sockaddr_in SAddr;
  int sock=0;
  FFSS_PTransfer FT;

  *FT_out = NULL;
  fp = fopen(FilePath,"rb");
  if(fp == NULL)
  {
    dprintf("Couldn't open file for upload : %s (%d)\n",FilePath,errno);
    return FS_SendMessage_Error(Client->sock,FFSS_ERROR_FILE_NOT_FOUND,FFSS_ErrorTable[FFSS_ERROR_FILE_NOT_FOUND]);
  }
  if(!UseConnSock)
  {
    sock = socket(AF_INET,SOCK_STREAM,getprotobyname("tcp")->p_proto);
    if(sock == SOCKET_ERROR)
    {
      fclose(fp);
      return FS_SendMessage_Error(Client->sock,FFSS_ERROR_INTERNAL_ERROR,FFSS_ErrorTable[FFSS_ERROR_INTERNAL_ERROR]);
    }
    SAddr.sin_family = AF_INET;
    SAddr.sin_port = htons(Port);
    SAddr.sin_addr.s_addr = Client->SAddr.sin_addr.s_addr;
    printf("connecting to client...\n");
    if(connect(sock,(struct sockaddr *)(&SAddr),sizeof(SAddr)) == SOCKET_ERROR)
    {
#ifdef __unix__
      close(sock);
#else
      closesocket(sock);
#endif
      fclose(fp);
      return FS_SendMessage_Error(Client->sock,FFSS_ERROR_CANNOT_CONNECT,FFSS_ErrorTable[FFSS_ERROR_CANNOT_CONNECT]);
    }
    printf("done\n");
  }
  FT = (FFSS_PTransfer) malloc(sizeof(FFSS_TTransfer));
  memset(FT,0,sizeof(FFSS_TTransfer));
  FT->fp = fp;
  FT->StartingPos = StartingPos;
  FT->XI.UseConnSock = UseConnSock;
  if(UseConnSock)
    FT->sock = Client->sock;
  else
    FT->sock = sock;
  FT->LocalPath = strdup(FilePath);
  FT->Client = Client;
  FT->User = User;
  FT->ThreadType = FFSS_THREAD_SERVER;
  if(!UseConnSock)
  {
    printf("launching thread...\n");
#ifdef _WIN32
    if((Thread = _beginthread(FFSS_UploadFileFunc,0,FT)) == -1)
#else
    if(pthread_create(&Thread,NULL,&FFSS_UploadFileFunc,FT) != 0)
#endif
    {
      FFSS_FreeTransfer(FT);
      return FS_SendMessage_Error(Client->sock,FFSS_ERROR_TOO_MANY_TRANSFERS,FFSS_ErrorTable[FFSS_ERROR_TOO_MANY_TRANSFERS]);
    }
#ifdef __unix__
    pthread_detach(Thread);
#endif
    printf("done... exiting\n");
  }
  if(FT_out != NULL)
    *FT_out = FT;
#endif
  return true;
}

bool FFSS_DownloadFile(FfssTCP * Server,const char RemotePath[],const char LocalPath[],long int StartingPos,void *User,bool UseConnSock,FFSS_PTransfer *FT_out)
{
#ifdef ENABLE_XFER
  int sock;
#ifdef __unix__
  pthread_t Thread;
#else
  unsigned long Thread;
#endif
  FFSS_PTransfer FT;

  sock = FC_SendMessage_Download(Server,RemotePath,StartingPos,UseConnSock);
  if(sock == SOCKET_ERROR)
  {
    dprintf("Error sending DOWNLOAD request : %d\n",errno);
    return false;
  }
  FT = (FFSS_PTransfer) malloc(sizeof(FFSS_TTransfer));
  memset(FT,0,sizeof(FFSS_TTransfer));
  FT->FileName = strdup(RemotePath);
  FT->LocalPath = strdup(LocalPath);
  FT->StartingPos = StartingPos;
  FT->XI.UseConnSock = UseConnSock;
  if(UseConnSock)
    FT->sock = Server->sock;
  else
    FT->sock = sock;
  FT->Client = Server;
  FT->User = User;
  FT->ThreadType = FFSS_THREAD_CLIENT;
  if(!UseConnSock)
  {
#ifdef _WIN32
    if((Thread = _beginthread(FFSS_DownloadFileFunc,0,FT)) == -1)
#else
    if(pthread_create(&Thread,NULL,&FFSS_DownloadFileFunc,FT) != 0)
#endif
    {
      FFSS_FreeTransfer(FT);
      return false;
    }
#ifdef __unix__
    pthread_detach(Thread);
#endif
  }
  if(FT_out != NULL)
    *FT_out = FT;
#endif
  return true;
}

bool FFSS_SendData(FFSS_PTransfer FT,FFSS_Field Tag,char *Buf,int len)
{
#ifdef ENABLE_XFER
  char *msg;
  int size,pos;
  int res;
  fd_set rfds;
  struct timeval tv;
  int retval;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_DATA + len;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_DATA;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = Tag;
  pos += sizeof(FFSS_Field);
  memcpy(msg+pos,Buf,len);
  pos += len;

  *(FFSS_Field *)(msg) = pos;

  FD_ZERO(&rfds);
  FD_SET(FT->sock,&rfds);
  tv.tv_sec = FFSS_TIMEOUT_TRANSFER;
  tv.tv_usec = 0;
  retval = select(FT->sock+1,NULL,&rfds,NULL,&tv);
  if(!retval)
  {
    dprintf("Transfer timed out\n");
    if(FFSS_CB.SCB.OnTransferFailed != NULL)
      FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_TIMEOUT,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_TIMEOUT],false);
    FFSS_FreeTransfer(FT);
    free(msg);
    return false;
  }
  res = 0;
  while(res != pos)
  {
    res += send(FT->sock,msg+res,pos-res,SU_MSG_NOSIGNAL);
    if(res == SOCKET_ERROR)
    {
      dprintf("Error while uploading file (data) : %d %s\n",errno,strerror(errno));
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_SEND,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_SEND],false);
      FFSS_FreeTransfer(FT);
      free(msg);
      return false;
    }
    else if(res == 0)
    {
      dprintf("EOF from remote host while uploading file\n");
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_EOF,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_EOF],false);
      FFSS_FreeTransfer(FT);
      free(msg);
      return false;
    }
  }
  free(msg);
#endif
  return true;
}

void FFSS_OnDataDownload(FFSS_PTransfer FT,const char Buf[],int Len)
{
#ifdef ENABLE_XFER
  FFSS_Field Checksum=0;

  if(FT->XI.fsize == 0) /* Extract FileSize */
  {
    FT->XI.fsize = *(FFSS_Field *)(Buf);
    Len -= sizeof(FFSS_Field);
  }
  FT->XI.total += Len;
  if(FT->XI.total > FT->XI.fsize) /* Extract Checksum */
  {
    Len -= sizeof(FFSS_Field);
    Checksum = *(FFSS_Field *)(Buf+Len);
  }
  if(Len != 0)
  {
    if(FT->fp != NULL)
      fwrite(Buf,1,Len,FT->fp);
    FT->XI.Checksum = FFSS_ComputeChecksum(FT->XI.Checksum,Buf,Len);
  }
  if(FT->XI.total == (FT->XI.fsize+sizeof(FFSS_Field))) /* Compares checksum */
  {
#ifdef DISABLE_CHECKSUM
    if(true)
#else
    if((Checksum == FT->XI.Checksum) || (Checksum == 1)) /* A Checksum of 1 means NO checksum on the other side */
#endif
    {
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferSuccess != NULL)
          FFSS_CB.SCB.OnTransferSuccess(FT,FT->XI.Download);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferSuccess != NULL)
          FFSS_CB.CCB.OnTransferSuccess(FT,FT->XI.Download);
      }
    }
    else
    {
      if(FT->ThreadType == FFSS_THREAD_SERVER)
      {
        if(FFSS_CB.SCB.OnTransferFailed != NULL)
          FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CHECKSUM,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CHECKSUM],FT->XI.Download);
      }
      else
      {
        if(FFSS_CB.CCB.OnTransferFailed != NULL)
          FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_CHECKSUM,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_CHECKSUM],FT->XI.Download);
      }
    }
    FFSS_FreeTransfer(FT);
  }
#endif
}

void FFSS_InitXFerDownload(FFSS_PTransfer FT,FFSS_Field XFerTag)
{
#ifdef ENABLE_XFER
  FT->XI.Download = true;
  FT->XI.XFerTag = XFerTag;
  FT->XI.total = 0;
  FT->XI.fsize = 0;
  FT->XI.Checksum = FFSS_ComputeChecksum(0,NULL,0);
  if(FT->StartingPos != 0)
    FT->fp = fopen(FT->LocalPath,"ab");
  else
    FT->fp = fopen(FT->LocalPath,"wb");
  if(FT->fp == NULL)
  {
    dprintf("Can't open local file for writting (%s)\n",FT->LocalPath);
    if(FT->ThreadType == FFSS_THREAD_SERVER)
    {
      if(FFSS_CB.SCB.OnTransferFailed != NULL)
        FFSS_CB.SCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_OPENING,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_OPENING],FT->XI.Download);
    }
    else
    {
      if(FFSS_CB.CCB.OnTransferFailed != NULL)
        FFSS_CB.CCB.OnTransferFailed(FT,FFSS_ERROR_TRANSFER_OPENING,FFSS_TransferErrorTable[FFSS_ERROR_TRANSFER_OPENING],FT->XI.Download);
    }
    FFSS_FreeTransfer(FT);
    FC_SendMessage_CancelXFer(FT->Client,XFerTag);
  }
#endif
}



/////////////////////////////////////////////////////////////////////////
// FfssTCPXfer   -- Event handlers. 
BOOLEAN  FfssTCPXfer::OnConnect(uint AddressLength, PTRANSPORT_ADDRESS pTA,	uint OptionsLength, PVOID Options)
{
	// Connecting: print the IP address of the requestor and grant the connection

	char szIPaddr[20];

	inet_ntoa(PTDI_ADDRESS_IP(pTA->Address[0].Address)->in_addr, szIPaddr, sizeof(szIPaddr));
  dprintf("TcpechoDevice: Connecting client, IP addr = %s, session %8X\n", szIPaddr, this);

	UNREFERENCED_PARAMETERS4(AddressLength, pTA, OptionsLength, Options);
  return TRUE;
}

void FfssTCPXfer::OnDisconnect(uint OptionsLength, PVOID Options, BOOLEAN bAbort)
{
  dprintf("TcpechoDevice: Disconnecting client, session %8X\n", this);
}

uint FfssTCPXfer::OnReceive(uint Indicated, uchar *Data, uint Available, uchar **RcvBuffer, uint* RcvBufferLen) 
{ 
  // Received some data from the client peer. Allocate a buffer and echo the data.
	// Note the use of the echo buffer as a context for the callback.
  uchar* echo = new uchar [Indicated];
  if (echo) {
    memcpy(echo, Data, Indicated);
    TDI_STATUS status = send(echo, Indicated, echo);
    if (status == TDI_PENDING) 
      return Indicated; // normal case
    if (status != TDI_SUCCESS)
      dprintf("TcpechoDevice: Error %u sending echo\n", status);
    delete echo;
  }

	// Now, if the transport has more data available than indicated,
	// allocate another buffer to read the rest. When the transport
	// done with it - asynchronously - our OnReceiveComplete() handler
	// is called. Note that failure to submit a buffer supressed further
	// recieve indications - until and if a recv() is issued.

	if (Indicated < Available) {
		*RcvBuffer = new uchar [*RcvBufferLen = Available-Indicated];
	}
  return Indicated;
}

void FfssTCPXfer::OnReceiveComplete(TDI_STATUS status, uint Indicated, uchar *Data)
{
	// Buffer for the partially indicated data allocated and submitted during 
	// OnReceive() processing is filled in by the transport. If everything is OK,
	// echo the buffer back to the remote client

  if (status == TDI_SUCCESS) 
		status = send(Data, Indicated, Data);
	else 
    dprintf("TcpechoDevice: Failed completing receive, err %X\n", status);

	if (status != TDI_PENDING)
		delete Data;
}

void FfssTCPXfer::OnSendComplete(PVOID buf, TDI_STATUS status, uint bytecnt)
{ 
  // Our send request has completed. Free the buffer

  if (status != TDI_SUCCESS)
    dprintf("TcpechoDevice: Failed sending echo, err %X\n", status);
  delete ((uchar*)buf);
}

