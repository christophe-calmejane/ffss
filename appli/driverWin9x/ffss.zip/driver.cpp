
/* Functions of this driver are NOT reentrant */

#include "divers.h"
#include "ffss.h"
#include "utils.h"
#include "transfer.h"

SU_PList FC_Handles = NULL; /* FC_PHandle */
long int FC_CurrentHandle = 1;

FC_PHandle FC_CreateHandle(void)
{
  FC_PHandle Hdl;

  Hdl = (FC_PHandle) malloc(sizeof(FC_THandle));
  if(Hdl == NULL)
    return NULL;
  memset(Hdl,0,sizeof(FC_THandle));
  Hdl->Handle = FC_CurrentHandle++;
  Hdl->BufSize = FFSS_TCP_BUFFER_SIZE;
  Hdl->Buf = (char *) malloc(Hdl->BufSize);
  if(Hdl->Buf == NULL)
  {
    free(Hdl);
    return NULL;
  }
  FC_Handles = SU_AddElementHead(FC_Handles,Hdl);
  return Hdl;
}

void FC_FreeHandle(FC_PHandle Hdl)
{
  if(Hdl->Buf != NULL)
    free(Hdl->Buf);
  free(Hdl);
}


void FC_AnalyseUDP(PTRANSPORT_ADDRESS Client,char Buf[],long int Len)
{
  int Type;
  char *str,*str2,*str3,*str4;
  char **Names,**Comments;
  char **answers;
  long int pos;
  FFSS_Field val,val2,val3;
  FFSS_Field i,j,state,type_ip,type_ip2;
  char IP[512], IP2[512];
  FM_PHost Hst;
  SU_PList HostList;
  bool do_it,error,free_it;
  char *u_Buf;
  long int u_pos,u_Len;

  Type = *(FFSS_Field *)(Buf+sizeof(FFSS_Field));
  pos = sizeof(FFSS_Field)*2;
  free_it = false;
  u_Buf = Buf;
  u_Len = Len;
  switch(Type)
  {
    case FFSS_MESSAGE_NEW_STATES :
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      error = false;
      switch(val2)
      {
        case FFSS_COMPRESSION_NONE:
          u_pos = pos;
          break;
        case FFSS_COMPRESSION_ZLIB:
          u_Buf = FFSS_UncompresseZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_NEW_STATES,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted Z compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#ifdef HAVE_BZLIB
        case FFSS_COMPRESSION_BZLIB:
          u_Buf = FFSS_UncompresseBZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_NEW_STATES,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted BZ compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#endif
        default:
          dprintf("Unknown compression type : %ld ... DoS attack ?\n",val2);
          error = true;
          break;
      }
      if(error)
        break;
      val = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
      dprintf("Received a new state message (%d states)\n",val);
      for(i=0;i<val;i++)
      {
        state = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        type_ip = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        FFSS_UnpackIP(u_Buf,u_Buf+u_pos,u_Len,&u_pos,IP,type_ip);
        str = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        str2 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        str3 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        str4 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        type_ip2 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        FFSS_UnpackIP(u_Buf,u_Buf+u_pos,u_Len,&u_pos,IP2,type_ip2);
        if((state == 0) || (type_ip == 0) || (IP[0] == 0) || (str == NULL) || (str2 == NULL) || (str3 == NULL) || (str4 == NULL) || (type_ip2 == 0) || (IP2[0] == 0))
        {
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          break;
        }
        if(FFSS_CB.CCB.OnNewState != NULL)
          FFSS_CB.CCB.OnNewState(state,IP2,str,str2,str3,str4,IP);
      }
      break;
    case FFSS_MESSAGE_SHARES_LISTING_ANSWER :
      type_ip = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      FFSS_UnpackIP(Buf,Buf+pos,Len,&pos,IP,type_ip);
      if((type_ip == 0) || (IP[0] == 0))
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        break;
      }
      val = FFSS_UnpackField (Buf, Buf + pos, Len, &pos);
      if(val == 0)
      {
        dprintf("Received a shares listing message, but server has no shares\n");
        if(FFSS_CB.CCB.OnSharesListing != NULL)
          FFSS_CB.CCB.OnSharesListing(IP,NULL,NULL,0);
        break;
      }
      dprintf("Received a shares listing message (%d shares)\n",val);
      Names = (char **) malloc(val*sizeof(char *));
      Comments = (char **) malloc(val*sizeof (char *));
      for(i=0;i<val;i++)
      {
        str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
        str2 = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
        if((str == NULL) || (str2 == NULL))
        {
          free (Names);
          free (Comments);
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          break;
        }
        Names[i] = str;
        Comments[i] = str2;
      }
      if(FFSS_CB.CCB.OnSharesListing != NULL)
        FFSS_CB.CCB.OnSharesListing (IP,(const char **)Names,(const char **)Comments,val);
      free(Names);
      free(Comments);
      break;
    case FFSS_MESSAGE_SERVER_LISTING_ANSWER :
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      error = false;
      switch(val2)
      {
        case FFSS_COMPRESSION_NONE:
          u_pos = pos;
          break;
        case FFSS_COMPRESSION_ZLIB:
          u_Buf = FFSS_UncompresseZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SERVER_LISTING_ANSWER,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted Z compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#ifdef HAVE_BZLIB
        case FFSS_COMPRESSION_BZLIB:
          u_Buf = FFSS_UncompresseBZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SERVER_LISTING_ANSWER,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted BZ compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#endif
        default:
          dprintf("Unknown compression type : %ld ... DoS attack ?\n",val2);
          error = true;
          break;
      }
      if(error)
        break;
      val = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
      dprintf("Received a server listing answer (%d domains)\n",val);
      for(i=0;i<val;i++)
      {
        str = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        val2 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        if(str == NULL)
        {
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          break;
        }
        dprintf("\t%d hosts in domain %s\n",val2,str);
        HostList = NULL;
        do_it = true;
        if(val2 != 0)
        {
          for (j=0;j<val2;j++)
          {
            val3 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
            str2 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
            str3 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
            str4 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
            type_ip = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
            FFSS_UnpackIP(u_Buf,u_Buf+u_pos,u_Len,&u_pos,IP,type_ip);
            if((val3 == 0) || (str2 == NULL) || (str3 == NULL) || (str4 == NULL) || (type_ip == 0) || (IP[0] == 0))
            {
              dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
              do_it = false;
              break;
            }
            Hst = (FM_PHost) malloc(sizeof(FM_THost));
            memset (Hst,0,sizeof(FM_THost));
            Hst->State = val3;
            Hst->Name = str2;
            Hst->OS = str3;
            Hst->Comment = str4;
            Hst->IP = strdup(IP);
            HostList = SU_AddElementHead(HostList,Hst);
          }
        }
        if(do_it)
        {
          if(FFSS_CB.CCB.OnServerListingAnswer != NULL)
            FFSS_CB.CCB.OnServerListingAnswer(str,val2,HostList);
        }
        SU_FreeListElem(HostList);
      }
      if(FFSS_CB.CCB.OnEndServerListingAnswer != NULL)
        FFSS_CB.CCB.OnEndServerListingAnswer();
      break;
    case FFSS_MESSAGE_DOMAINS_LISTING_ANSWER :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if(val == 0)
      {
        dprintf("Received a domains listing answer, but master has no domains\n");
        if (FFSS_CB.CCB.OnDomainListingAnswer != NULL)
          FFSS_CB.CCB.OnDomainListingAnswer(NULL,0);
        break;
      }
      dprintf("Received a domains listing answer (%d domains)\n",val);
      Names = (char **) malloc(val*sizeof(char *));
      for(i=0;i<val;i++)
      {
        str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
        if(str == NULL)
        {
          free (Names);
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          break;
        }
        Names[i] = str;
      }
      if(FFSS_CB.CCB.OnDomainListingAnswer != NULL)
        FFSS_CB.CCB.OnDomainListingAnswer((const char **)Names,val);
      free (Names);
      break;
/*    case FFSS_MESSAGE_SEARCH_MASTER_ANSWER :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
      if((val == 0) || (str == NULL))
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        break;
      }
      if(FFSS_CB.CCB.OnMasterSearchAnswer != NULL)
        FFSS_CB.CCB.OnMasterSearchAnswer(Client,val,str);
      break;*/
    case FFSS_MESSAGE_SEARCH_ANSWER :
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      error = false;
      switch(val2)
      {
        case FFSS_COMPRESSION_NONE:
          u_pos = pos;
          break;
        case FFSS_COMPRESSION_ZLIB:
          u_Buf = FFSS_UncompresseZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SEARCH_ANSWER,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted Z compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#ifdef HAVE_BZLIB
        case FFSS_COMPRESSION_BZLIB:
          u_Buf = FFSS_UncompresseBZlib(Buf+pos,Len-sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SEARCH_ANSWER,&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted BZ compressed buffer ... DoS attack ?\n");
            error = true;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#endif
        default:
          dprintf("Unknown compression type : %ld ... DoS attack ?\n",val2);
          error = true;
          break;
      }
      if(error)
        break;
      str = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
      if(str == NULL)
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        break;
      }
      val = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
      if(val == 0)
      {
        dprintf("Received a search answer message, but master has found nothing\n");
        if(FFSS_CB.CCB.OnSearchAnswer != NULL)
          FFSS_CB.CCB.OnSearchAnswer(str,NULL,NULL,0);
        break;
      }
      dprintf("Received a search answer message (%d domains)\n",val);
      for(i=0;i<val;i++)
      {
        str2 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        if(str2 == NULL)
        {
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          break;
        }
        val2 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        if(val2 == 0)
          continue;
        answers = (char **) malloc(val2*sizeof(char *));
        for(j=0;j<val2;j++)
        {
          str3 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
          if(str3 == NULL)
          {
            free (answers);
            dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
            break;
          }
          answers[j] = str3;
        }
        if(FFSS_CB.CCB.OnSearchAnswer != NULL)
          FFSS_CB.CCB.OnSearchAnswer(str,str2,(const char **)answers,val2);
        free (answers);
      }
      break;
    default:
      dprintf("Unknown Type of message (%d)... DoS attack ?\n",Type);
  }
  if(free_it)
    free(u_Buf);
}

bool FC_AnalyseTCP(FfssTCP *Server,char Buf[],long int Len)
{
  int Type, i;
  long int pos;
  FFSS_Field val,val2,val3,val4;
  char *str,*str2;
  SU_PList Ptr;
  FC_PEntry Ent;
  bool ret_val;
  FFSS_PTransfer FT;
  bool free_it;
  char *u_Buf;
  long int u_pos,u_Len;

  Type = *(FFSS_Field *)(Buf+sizeof(FFSS_Field));
  pos = sizeof (FFSS_Field)*2;
  ret_val = true;
  free_it = false;
  u_Buf = Buf;
  u_Len = Len;
  switch (Type)
  {
    case FFSS_MESSAGE_ERROR :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
      if((val == 0) || (str == NULL))
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      if(FFSS_CB.CCB.OnError != NULL)
        ret_val = FFSS_CB.CCB.OnError(Server,val,str);
      break;
    case FFSS_MESSAGE_DIRECTORY_LISTING_ANSWER :
      str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if(str == NULL)
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      switch (val2)
      {
        case FFSS_COMPRESSION_NONE:
          u_pos = pos;
          break;
        case FFSS_COMPRESSION_ZLIB:
          u_Buf = FFSS_UncompresseZlib(Buf+pos,Len-sizeof(FFSS_Field)*3-(strlen(str)+1),&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted Z compressed buffer ... DoS attack ?\n");
            ret_val = false;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#ifdef HAVE_BZLIB
        case FFSS_COMPRESSION_BZLIB:
          u_Buf = FFSS_UncompresseBZlib(Buf+pos,Len-sizeof(FFSS_Field)*3-(strlen(str)+1),&u_Len);
          if(u_Buf == NULL)
          {
            dprintf("Corrupted BZ compressed buffer ... DoS attack ?\n");
            ret_val = false;
            break;
          }
          free_it = true;
          u_pos = 0;
          break;
#endif
        default:
          dprintf("Unknown compression type : %ld ... DoS attack ?\n",val2);
          ret_val = false;
          break;
      }
      if(!ret_val)
        break;
      val = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
      Ptr = NULL;
      for(i=0;i<val;i++)
      {
        Ent = (FC_PEntry) malloc(sizeof(FC_TEntry));
        memset(Ent,0,sizeof(FC_TEntry));
        str2 = FFSS_UnpackString(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        val2 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        val3 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        val4 = FFSS_UnpackField(u_Buf,u_Buf+u_pos,u_Len,&u_pos);
        if(str2 == NULL)
        {
          dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
          free (Ent);
          SU_FreeListElem(Ptr);
          ret_val = false;
          break;
        }
        Ent->Name = str2;
        Ent->Flags = val2;
        Ent->Size = val3;
        Ent->Stamp = val4;
        Ptr = SU_AddElementTail(Ptr,Ent);
      }
      if(FFSS_CB.CCB.OnDirectoryListingAnswer != NULL)
        ret_val = FFSS_CB.CCB.OnDirectoryListingAnswer(Server,str,val,Ptr);
      SU_FreeListElem(Ptr);
      break;
    case FFSS_MESSAGE_INIT_XFER :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
      if(str == NULL)
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      if(FFSS_CB.CCB.OnInitXFer != NULL)
      {
        FT = FFSS_CB.CCB.OnInitXFer(Server,str);
        if(FT != NULL)
          FFSS_InitXFerDownload(FT,val);
      }
      break;
    case FFSS_MESSAGE_DATA :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if(FFSS_CB.CCB.OnData != NULL)
      {
        FT = FFSS_CB.CCB.OnData(Server,val);
        if(FT != NULL)
          FFSS_OnDataDownload(FT,Buf+pos,Len-FFSS_MESSAGESIZE_DATA*sizeof(FFSS_Field));
      }
      break;
    case FFSS_MESSAGE_STREAMING_OPEN_ANSWER :
      str = FFSS_UnpackString(Buf,Buf+pos,Len,&pos);
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      val3 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if((str == NULL) || (val == 0))
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      if(FFSS_CB.CCB.OnStrmOpenAnswer != NULL)
        FFSS_CB.CCB.OnStrmOpenAnswer(Server,str,val,val2,val3);
      break;
    case FFSS_MESSAGE_STREAMING_READ_ANSWER :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if(val == 0)
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      if(FFSS_CB.CCB.OnStrmReadAnswer != NULL)
        FFSS_CB.CCB.OnStrmReadAnswer(Server,val,Buf+pos,Len-FFSS_MESSAGESIZE_STREAMING_READ_ANSWER*sizeof(FFSS_Field));
      break;
    case FFSS_MESSAGE_STREAMING_WRITE_ANSWER :
      val = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      val2 = FFSS_UnpackField(Buf,Buf+pos,Len,&pos);
      if((val == 0) || (val2 == 0))
      {
        dprintf("One or many fields empty, or out of buffer... DoS attack ?\n");
        ret_val = false;
        break;
      }
      if(FFSS_CB.CCB.OnStrmWriteAnswer != NULL)
        FFSS_CB.CCB.OnStrmWriteAnswer(Server,val,val2);
      break;
    default:
      dprintf("Unknown Type of message (%d)... DoS attack ?\n",Type);
      ret_val = false;
  }
  if(free_it)
    free(u_Buf);
  return ret_val;
}

bool FfssTCP::GetPacket(FfssTCP *Server,uchar *Data,uint Indicated)
{
  FFSS_Field Size;
  bool analyse;
  int retval;

  if(len >= BufSize)
  {
    dprintf("WARNING : Client's buffer too short for this message !!\n");
    len = 0;
  }
  if(Indicated >= (BufSize - len))
  {
    dprintf("WARNING : Client's buffer too short for this message !! Ignoring message...\n");
    len = 0;
    return true;
  }
  memcpy(Buf+len,Data,Indicated);
  dprintf("Data found on TCP port ... analysing\n");
  /* If size of message won't fit in the buffer */
  if((len == 0) && ((*(FFSS_Field *)Buf) > BufSize))
  {
    dprintf("Length of the message won't fit in the UDP buffer !!\n");
  }
  len += Indicated;
  analyse = true;
  while(analyse)
  {
    if(len < 5)
    {
      dprintf("Length of the message is less than 5 (%d)... DoS attack ?\n",len);
      return false;
    }
    Size = *(FFSS_Field *)Buf;
    if(Size > len)
    {
      dprintf("Warning, Size of the message is greater than received data (%d - %d)... Message splitted ?\n",Size,len);
      break;
      /* Keeps waiting for data */
    }
    else
    {
      retval = FC_AnalyseTCP(Server,Buf,Size);
      Sem->SignalTimer();
      if(!retval)
      {
        return false;
      }
      if(len > Size)
      {
        dprintf("Warning, Size of the message is less than received data (%d - %d)... multiple messages ?\n",Size,len);
        memmove(Buf,Buf+Size,len-Size);
        len -= Size;
        /* Keeps analysing the buffer */
      }
      else
      {
        analyse = false;
        len = 0;
      }
    }
  }
  return true;
}

/* FFSS Client : UnInit */
/* Initialisation of the FFSS Client - Must be called before any other FFSS function */
/* Returns true on success, false otherwise */
bool FC_Init(void)
{
  FC_Handles = NULL;
  dprintf("FFSS driver running\n");
  return true;
}

/* FFSS Client : UnInit */
/* Uninitialisation of the FFSS Client - Must be called at the end of the main */
/* Returns true on success, false otherwise */
bool FC_UnInit(void)
{
  SU_PList Ptr;

  Ptr = FC_Handles;
  while(Ptr != NULL)
  {
    FC_FreeHandle((FC_PHandle)Ptr->Data);
  }
  SU_FreeList(FC_Handles);
  dprintf("FFSS driver shut down\n");
  return true;
}

