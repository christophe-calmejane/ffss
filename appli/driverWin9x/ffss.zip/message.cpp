#include "divers.h"
#include "ffss.h"
#include "utils.h"

#ifdef _WIN32
void FC_ClientThreadTCP(void *User);
#else
void *FC_ClientThreadTCP(void *User);
#endif


/* ************************************ */
/*             CLIENT MESSAGES          */
/* ************************************ */

/* FC_SendMessage_ServerSearch Function       */
/* Sends a SERVER SEARCH message to broadcast */
bool FC_SendMessage_ServerSearch(void)
{
  char *msg;
  long int size,pos;
  TDI_STATUS resp;
  TDI_ADDRESS_IP addr = {htons(FFSS_SERVER_PORT),INADDR_BROADCAST};
  CTDI_CONNECTION_INFORMATION server(addr);

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SERVER_SEARCH;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SERVER_SEARCH;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Servers Search message to broadcast\n");
  resp = pUDP->sendto(server,msg,pos,msg);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_SharesListing Function                       */
/* Sends a SHARES LISTING message to a server                  */
/*  Server : The name of the server we want the shares listing */
bool FC_SendMessage_SharesListing(const char Server[])
{
  char *msg;
  long int size,pos;
  TDI_STATUS resp;
  TDI_ADDRESS_IP addr = {htons(FFSS_SERVER_PORT),inet_addr(Server)};
  CTDI_CONNECTION_INFORMATION server(addr);

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SHARES_LISTING;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SHARES_LISTING;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Shares Listing message to %s\n",Server);
  resp = pUDP->sendto(server,msg,pos,msg);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_ServerList Function                      */
/* Sends a SERVER LIST message to a master                 */
/*  Master : The name of my master, or NULL if none        */
/*  OS : The desired OS, or NULL if requesting all         */
/*  Domain : The desired domain, or NULL if requesting all */
bool FC_SendMessage_ServerList(const char Master[],const char OS[],const char Domain[])
{
  char *msg;
  long int len,size,pos;
  long int Comps;
  TDI_STATUS resp;
  TDI_ADDRESS_IP addr = {htons(FFSS_MASTER_PORT),inet_addr(Master)};
  CTDI_CONNECTION_INFORMATION server(addr);

  if(Master == NULL)
    return true;
  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SERVER_LISTING + FFSS_MAX_SERVEROS_LENGTH+1 + FFSS_MAX_DOMAIN_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SERVER_LISTING;
  pos += sizeof(FFSS_Field);

  Comps = FFSS_COMPRESSION_NONE | FFSS_COMPRESSION_ZLIB;
#ifdef HAVE_BZLIB
  Comps |= FFSS_COMPRESSION_BZLIB;
#endif
  *(FFSS_Field *)(msg+pos) = Comps;
  pos += sizeof(FFSS_Field);

  if(OS != NULL)
  {
    len = strlen(OS)+1;
    if(len > FFSS_MAX_SERVEROS_LENGTH)
      len = FFSS_MAX_SERVEROS_LENGTH;
    SU_strcpy(msg+pos,OS,len);
    pos += len;
  }
  else
    msg[pos++] = 0;
  if(Domain != NULL)
  {
    len = strlen(Domain)+1;
    if(len > FFSS_MAX_DOMAIN_LENGTH)
      len = FFSS_MAX_DOMAIN_LENGTH;
    SU_strcpy(msg+pos,Domain,len);
    pos += len;
  }
  else
    msg[pos++] = 0;
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Server listing message to %s\n",Master);
  resp = pUDP->sendto(server,msg,pos,msg);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_ShareConnect Function                  */
/* Sends a SHARE CONNECTION message to a server          */
/*  Server : The name of Server we wish to connect to    */
/*  ShareName : The Share Name we wish to connect to     */
/*  Login : The Login we may use (or NULL if none)       */
/*  Password : The Password we may use (or NULL if none) */
FfssTCP * FC_SendMessage_ShareConnect(const char Server[],const char ShareName[],const char Login[],const char Password[])
{
  char *msg;
  long int len,size,pos;
  FfssTCP *TCP;
  TDI_STATUS resp;
  TDI_ADDRESS_IP addr = {htons(FFSS_SERVER_PORT),inet_addr(Server)};
  CTDI_CONNECTION_INFORMATION server(addr);
  int retval;
  long int Comps;
#ifndef DRIVER
#ifdef _WIN32
  unsigned long Thread;
#else
  pthread_t Thread;
#endif
#endif

  TCP = new FfssTCP;
  if(TCP == NULL)
    return NULL;
   if(!TCP->IsCreated())
     return NULL;
  TCP->SetEvents(TRUE);
  TCP->connect(server);
  if(!TCP->IsConnected())
  {
    dprintf("FC_SendMessage_ShareConnect : Cannot connect to %s\n",Server);
    delete TCP;
    return NULL;
  }
  dprintf("FC_SendMessage_ShareConnect : Connected to %s\n",Server);
  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SHARE_CONNECTION + FFSS_MAX_LOGIN_LENGTH+1 + FFSS_MAX_PASSWORD_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SHARE_CONNECTION;
  pos += sizeof(FFSS_Field);

  Comps = FFSS_COMPRESSION_NONE | FFSS_COMPRESSION_ZLIB;
#ifdef HAVE_BZLIB
  Comps |= FFSS_COMPRESSION_BZLIB;
#endif
  *(FFSS_Field *)(msg+pos) = Comps;
  pos += sizeof(FFSS_Field);

  len = strlen(ShareName)+1;
  if(len > FFSS_MAX_SHARENAME_LENGTH)
    len = FFSS_MAX_SHARENAME_LENGTH;
  SU_strcpy(msg+pos,ShareName,len);
  pos += len;
  if(Login != NULL)
  {
    len = strlen(Login)+1;
    if(len > FFSS_MAX_LOGIN_LENGTH)
      len = FFSS_MAX_LOGIN_LENGTH;
    SU_strcpy(msg+pos,Login,len);
    pos += len;
  }
  else
    msg[pos++] = 0;
  if(Password != NULL)
  {
    len = strlen(Password)+1;
    if(len > FFSS_MAX_PASSWORD_LENGTH)
      len = FFSS_MAX_PASSWORD_LENGTH;
    SU_strcpy(msg+pos,Password,len);
    pos += len;
  }
  else
    msg[pos++] = 0;
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Share connection message to %s\n",Server);
  resp = TCP->send(msg,pos);
  if (resp != TDI_PENDING && resp != TDI_SUCCESS)
  {
    TCP->disconnect(true);
    delete TCP;
    return NULL;
  }
  return TCP;
}

/* FC_SendMessage_DirectoryListing Function             */
/* Sends a DIRECTORY LISTING message to a server        */
/*  Server : The Server's structure we are connected to */
/*  Path : The path we request a listing                */
bool FC_SendMessage_DirectoryListing(FfssTCP * Server,const char Path[])
{
  char *msg;
  long int size,pos;
  int len;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_DIRECTORY_LISTING + FFSS_MAX_PATH_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_DIRECTORY_LISTING;
  pos += sizeof(FFSS_Field);
  len = strlen(Path)+1;
  if(len > FFSS_MAX_PATH_LENGTH)
    len = FFSS_MAX_PATH_LENGTH;
  SU_strcpy(msg+pos,Path,len);
  pos += len;
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Directory Listing message to server for %s\n",Path);
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_Download Function                                 */
/* Sends a DOWNLOAD message to a server                             */
/*  Server : The Server's structure we are connected to             */
/*  Path : The path of requested file (in the share)                */
/*  StartingPos : The pos we want to download the file starting at  */
/*  UseConnSock : Use a separate socket/thread, or use the existing */
KStreamServer<FfssTCPXfer> *FC_SendMessage_Download(FfssTCP * Server,const char Path[],long int StartingPos,bool UseConnSock)
{
  char *msg;
  long int size,pos;
  int len;
  TDI_STATUS resp;
  KStreamServer<FfssTCPXfer>* TCP;
  CIPTRANSPORT_ADDRESS server(0);
  int retval;

  if(!UseConnSock)
  {
	  TCP = new KStreamServer<FfssTCPXfer>(server);
    if(TCP == NULL)
      return NULL;
     if(!TCP->IsCreated())
       return NULL;
    TCP->SetEvents(TRUE);
    dprintf("Listening server created.... waiting on port %d (or %d?)\n",TCP->QueryPort(),ntohs(TCP->QueryPort()));
  }
  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_DOWNLOAD + FFSS_MAX_FILEPATH_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_DOWNLOAD;
  pos += sizeof(FFSS_Field);
  len = strlen(Path)+1;
  if(len > FFSS_MAX_FILEPATH_LENGTH)
    len = FFSS_MAX_FILEPATH_LENGTH;
  SU_strcpy(msg+pos,Path,len);
  pos += len;
  *(FFSS_Field *)(msg+pos) = StartingPos;
  pos += sizeof(FFSS_Field);
  if(UseConnSock)
    *(FFSS_Field *)(msg+pos) = -1;
  else
    *(FFSS_Field *)(msg+pos) = ntohs(TCP->QueryPort());
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Download message to server for %s starting at %ld\n",Path,StartingPos);
  resp = Server->send(msg,pos);
  if(resp != TDI_PENDING && resp != TDI_SUCCESS);
  {
    if(!UseConnSock)
    {
      delete TCP;
    }
    return NULL;
  }
  if(UseConnSock)
    return NULL;
  else
    return TCP;
}

/* FC_SendMessage_Disconnect Function                   */
/* Sends an DISCONNECT message to a server              */
/*  Server : The Server's structure we are connected to */
void FC_SendMessage_Disconnect(FfssTCP * Server)
{
  char *msg;
  long int size,pos;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_DISCONNECT;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_DISCONNECT;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Disconnect message to server\n");
  Server->send(msg,pos);
  return;
}

/* FC_SendMessage_CancelXFer Function                   */
/* Sends an CANCEL XFER message to a server             */
/*  Server : The Server's structure we are connected to */
/*  XFerTag : The tag of the xfer we want to cancel     */
void FC_SendMessage_CancelXFer(FfssTCP * Server,FFSS_Field XFerTag)
{
/*  char *msg;
  int size,pos;
  int retval;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_CANCEL_XFER;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_CANCEL_XFER;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = XFerTag;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending cancel xfer message to server\n");
    send(Server->sock,msg,pos,SU_MSG_NOSIGNAL);
  free(msg);
#ifdef __unix__
  close(Server->sock);
#else
  closesocket(Server->sock);
#endif
  free(Server);
  return;*/
}

/* FC_SendMessage_DomainListing Function   */
/* Sends a DOMAIN LIST message to a master */
/*  Master : The name of my master         */
bool FC_SendMessage_DomainListing(const char Master[])
{
  char *msg;
  long int size,pos;
  TDI_STATUS resp;
  TDI_ADDRESS_IP addr = {htons(FFSS_MASTER_PORT),inet_addr(Master)};
  CTDI_CONNECTION_INFORMATION server(addr);

  if(Master == NULL)
    return true;
  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_DOMAINS_LISTING;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_DOMAINS_LISTING;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Domains listing message to %s\n",Master);
  resp = pUDP->sendto(server,msg,pos,msg);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_Search Function                          */
/* Sends a SEARCH message to a master                      */
/*  Master : The name of my master                         */
/*  Domain : The desired domain, or NULL if requesting all */
/*  Keys   : A String of keywords                          */
bool FC_SendMessage_Search(const char Master[],const char Domain[],const char Key[])
{
/*  char *msg;
  int len,size,pos;
  int resp;
  long int Comps;

  if(Master == NULL)
    return true;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SEARCH + FFSS_MAX_DOMAIN_LENGTH+1 + FFSS_MAX_KEYWORDS_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SEARCH;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = ntohs(FC_SI_OUT_UDP->SAddr.sin_port);
  pos += sizeof(FFSS_Field);

  Comps = FFSS_COMPRESSION_NONE | FFSS_COMPRESSION_ZLIB;
#ifdef HAVE_BZLIB
  Comps |= FFSS_COMPRESSION_BZLIB;
#endif
  *(FFSS_Field *)(msg+pos) = Comps;
  pos += sizeof(FFSS_Field);

  if(Domain != NULL)
  {
    len = strlen(Domain)+1;
    if(len > FFSS_MAX_DOMAIN_LENGTH)
      len = FFSS_MAX_DOMAIN_LENGTH;
    SU_strcpy(msg+pos,Domain,len);
    pos += len;
  }
  else
    msg[pos++] = 0;
  len = strlen(Key)+1;
  if(len > FFSS_MAX_KEYWORDS_LENGTH)
    len = FFSS_MAX_KEYWORDS_LENGTH;
  SU_strcpy(msg+pos,Key,len);
  pos += len;
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Search message to %s - Reply to port %d\n",Master,ntohs(FC_SI_OUT_UDP->SAddr.sin_port));
  resp = SU_UDPSendToAddr(FC_SI_OUT_UDP,msg,pos,(char *)Master,FFSS_MASTER_PORT_S);
  if(resp == SOCKET_ERROR)
    resp = SU_UDPSendToAddr(FC_SI_OUT_UDP,msg,pos,(char *)Master,FFSS_MASTER_PORT_S);
  free(msg);
  return (resp != SOCKET_ERROR);*/return true;
}

/* FC_SendMessage_MasterSearch Function       */
/* Sends a MASTER SEARCH message to broadcast */
bool FC_SendMessage_MasterSearch()
{
/*  char *msg;
  int size,pos;
  int resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_SEARCH_MASTER;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_SEARCH_MASTER;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_THREAD_CLIENT;
  pos += sizeof(FFSS_Field);
  *(FFSS_Field *)(msg) = pos;
  dprintf("Sending Master Search message to broadcast\n");
  resp = SU_UDPSendBroadcast(FC_SI_OUT_UDP,msg,pos,FFSS_MASTER_PORT_S);
  if(resp == SOCKET_ERROR)
    resp = SU_UDPSendBroadcast(FC_SI_OUT_UDP,msg,pos,FFSS_MASTER_PORT_S);
  free(msg);
  return (resp != SOCKET_ERROR);*/return true;
}


/* FC_SendMessage_StrmOpen Function                     */
/* Sends an STREAMING OPEN message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Path : The path of the requested file               */
/*  Flags : The opening mode flags                      */
bool FC_SendMessage_StrmOpen(FfssTCP * Server,const char Path[],int Flags)
{
  char *msg;
  long int len,size,pos;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_STREAMING_OPEN + FFSS_MAX_FILEPATH_LENGTH+1;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_STREAMING_OPEN;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Flags;
  pos += sizeof(FFSS_Field);

  if(Path != NULL)
  {
    len = strlen(Path)+1;
    if(len > FFSS_MAX_FILEPATH_LENGTH)
      len = FFSS_MAX_FILEPATH_LENGTH;
    SU_strcpy(msg+pos,Path,len);
    pos += len;
  }
  else
    msg[pos++] = 0;

  *(FFSS_Field *)(msg) = pos;
  FFSS_PrintDebug(3,"Sending Streaming OPEN message to client\n");
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_StrmClose Function                     */
/* Sends an STREAMING CLOSE message to a server          */
/*  Server : The Server's structure we are connected to  */
/*  Handle : The handle of the file to close             */
bool FC_SendMessage_StrmClose(FfssTCP * Server,long int Handle)
{
  char *msg;
  long int size,pos;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_STREAMING_CLOSE;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_STREAMING_CLOSE;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Handle;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  FFSS_PrintDebug(3,"Sending Streaming CLOSE message to client\n");
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_StrmRead Function                     */
/* Sends an STREAMING READ message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  StartPos : The start position of the requested bloc */
bool FC_SendMessage_StrmRead(FfssTCP * Server,long int Handle,long int StartPos,long int Length)
{
  char *msg;
  long int size,pos;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_STREAMING_READ;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_STREAMING_READ;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Handle;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = StartPos;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Length;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  FFSS_PrintDebug(3,"Sending Streaming READ message to client\n");
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_StrmWrite Function                    */
/* Sends an STREAMING WRITE message to a server         */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  StartPos : The start position of the requested bloc */
/*  Buf : The buffer of datas                           */
/*  BlocLen : The length of the datas                   */
bool FC_SendMessage_StrmWrite(FfssTCP * Server,long int Handle,long int StartPos,char *Buf,long int BlocLen)
{
  char *msg;
  long int size,pos;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_STREAMING_WRITE + BlocLen;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_STREAMING_WRITE;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Handle;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = StartPos;
  pos += sizeof(FFSS_Field);

  memcpy(msg+pos,Buf,BlocLen);
  pos += BlocLen;

  *(FFSS_Field *)(msg) = pos;
  FFSS_PrintDebug(3,"Sending Streaming WRITE message to client\n");
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

/* FC_SendMessage_StrmSeek Function                     */
/* Sends an STREAMING SEEK message to a server          */
/*  Server : The Server's structure we are connected to */
/*  Handle : The handle of the file to close            */
/*  Flags : The flags for the seek operation            */
/*  StartPos : The position of the seek                 */
bool FC_SendMessage_StrmSeek(FfssTCP * Server,long int Handle,int Flags,long int StartPos)
{
  char *msg;
  long int size,pos;
  int retval;
  TDI_STATUS resp;

  size = sizeof(FFSS_Field)*FFSS_MESSAGESIZE_STREAMING_SEEK;
  msg = (char *) malloc(size);
  pos = sizeof(FFSS_Field);
  *(FFSS_Field *)(msg+pos) = FFSS_MESSAGE_STREAMING_SEEK;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Handle;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = Flags;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg+pos) = StartPos;
  pos += sizeof(FFSS_Field);

  *(FFSS_Field *)(msg) = pos;
  FFSS_PrintDebug(3,"Sending Streaming SEEK message to client\n");
  resp = Server->send(msg,pos);
  return (resp == TDI_PENDING || resp == TDI_SUCCESS);
}

