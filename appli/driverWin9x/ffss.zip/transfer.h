#ifndef __FFSS_TRANSFER_H__
#define __FFSS_TRANSFER_H__

#ifdef _WIN32
void FFSS_UploadFileFunc(void *Info);
void FFSS_DownloadFileFunc(void *Info);
#else
void *FFSS_UploadFileFunc(void *Info);
void *FFSS_DownloadFileFunc(void *Info);
#endif

#endif
