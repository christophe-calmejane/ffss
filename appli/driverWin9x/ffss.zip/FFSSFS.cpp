// FFSS.cpp - main module for VxD FFSS

#define DEVICE_MAIN
#include "divers.h"
#include "ffss.h"
Declare_Port_Driver(FFSS,DRP_MISC_PD,FFSS_NAME,FFSS_REV,FFSS_FEATURE,FFSS_IFR,DRP_BT_ESDI,0)
#undef DEVICE_MAIN

/////////////////////////////////////////////////////////////////////
// FFSS callbacks
/* UDP callbacks */
void OnDomainListingAnswer(const char **Domains,int NbDomains);
void OnServerListingAnswer(const char Domain[],int NbHost,SU_PList HostList);
//  void (*OnNewState)(FFSS_Field State,const char IP[],const char Domain[],const char Name[],const char OS[],const char Comment[],const char MasterIP[]);
void OnSharesListing(const char IP[],const char **Names,const char **Comments,int NbShares);
//  void (*OnMasterSearchAnswer)(struct sockaddr_in Master,FFSS_Field MasterVersion,const char Domain[]);
//  void (*OnSearchAnswer)(const char Query[],const char Domain[],const char **Answers,int NbAnswers);
//  void (*OnUDPError)(int ErrNum);
/* TCP callbacks */
bool OnError(FfssTCP * Server,int Code,const char Descr[]);
bool OnDirectoryListingAnswer(FfssTCP * Server,const char Path[],int NbEntries,SU_PList Entries);
/* Streaming callbacks */
void OnStrmOpenAnswer(FfssTCP * Client,const char Path[],int Code,long int Handle,long int FileSize);
void OnStrmReadAnswer(FfssTCP * Client,long int Handle,const char Bloc[],long int BlocSize);
void OnStrmWriteAnswer(FfssTCP * Client,long int Handle,int Code);

ppIFSFileHookFunc PrevHook;

FfssVM::FfssVM(VMHANDLE hVM) : VVirtualMachine(hVM) {}

FfssThread::FfssThread(THREADHANDLE hThread) : VThread(hThread) {}

FfssUDP *pUDP;


BOOL FfssDevice::OnSysDynamicDeviceInit()
{
  DWORD ret;
  FC_PDomain Dom;
  /* First initialize TDI */
  if(!KTDInterface::Initialize())
  {
    ASSERT(0);
    return false;
  }
  /* Create an UDP socket */
  pUDP = new FfssUDP;
  if(pUDP && pUDP->IsCreated())
  {
    pUDP->SetEvents(true);
    dprintf("FFSS : UDP Socket created at port %d",pUDP->QueryPort());
  }
  else
  {
    dprintf("FFSS : Socket creation failed");
    return false;
  }
  FFSS_Domains = NULL;
  Sem_UDP = new VSemaphore(1);
  FFSS_Conns = NULL;
  Sem_TCP = new VSemaphore(1);
  FFSS_Handles = NULL;
  Sem_Handles = new VSemaphore(1);
  if(FFSS_MASTER_IP == NULL)
  {
    Dom = (FC_PDomain) malloc(sizeof(FC_TDomain));
    if(Dom != NULL)
    {
      memset(Dom,0,sizeof(FC_TDomain));
      Dom->Name = strdup("None");
      FFSS_Domains = SU_AddElementHead(FFSS_Domains,Dom);
    }
  }

  /* Install FSD */
	if (IFSMgr_RegisterMount(FfssMountVolume,IFSMGRVERSION,0) == -1)
	{
		dprintf("FFSS : Call to IFSMgr_RegisterMount failed");
		return false;
	}

  /* Now register with the IOS, passing a pointer to the Device 
     Registration Packet that is declared above using macro
     Declare_Port_Driver. No error returns are defined for this call.
  */
	IOS_Register(&FFSS_Drp);

/*  Sem_Debug = new FfssSem;
  Timer_Debug = new FfssTimer(Sem_Debug,FFSS_TIMEOUT_UDP_MESSAGE*1000);
  if(Timer_Debug == NULL)
    ASSERT(0);
  Sem_Debug->SetTimer(Timer_Debug);*/

	return TRUE;
}

BOOL FfssDevice::OnSysDynamicDeviceExit()
{
  /* Destroy our socket */
  delete pUDP;
	return TRUE;
}


VDevice* __cdecl _CreateDevice(void)
{							      
	return (VDevice*)new DEVICE_CLASS;		      
} 							       

VOID __cdecl _DestroyDevice(void)	
{									
}

void FfssSem::SignalTimer(void)
{
//  dprintf("SEM : SIGNAL TIMER\n");
  pTimer->Cancel();
  if(Locked)
    VSemaphore::signal();
  Locked = false;
}

void FfssSem::WaitTimer(void)
{
//  dprintf("SEM : WAIT TIMER\n");
  pTimer->Set();
  VSemaphore::wait();
  Locked = true;
}

void FfssSem::Signal(void)
{
//  dprintf("SEM : SIGNAL...\n");
  if(Locked)
    VSemaphore::signal();
  Locked = false;
//  dprintf("SEM : SIGNALED\n");
}

void FfssSem::Wait(void)
{
//  dprintf("SEM : WAIT...\n");
  VSemaphore::wait();
  Locked = true;
//  dprintf("SEM : WAITED\n");
}

void FfssSem::SetTimeout(DWORD msec)
{
  pTimer->SetTimeout(msec);
}

FfssUDP::FfssUDP() : KDatagramSocket()
{
  BufSize = FFSS_UDP_BUFFER_SIZE;
  Buf = (char *) malloc(BufSize);
  len = 0;
  Sem = new FfssSem;
  if(Sem == NULL)
    ASSERT(0);
  Timer = new FfssTimer(Sem,FFSS_TIMEOUT_UDP_MESSAGE*1000);
  if(Timer == NULL)
    ASSERT(0);
  Sem->SetTimer(Timer);
  /* UDP callbacks */
  FFSS_CB.CCB.OnDomainListingAnswer = OnDomainListingAnswer;
  FFSS_CB.CCB.OnServerListingAnswer = OnServerListingAnswer;
  FFSS_CB.CCB.OnSharesListing = OnSharesListing;
  /* TCP callbacks */
  FFSS_CB.CCB.OnError = OnError;
  FFSS_CB.CCB.OnDirectoryListingAnswer = OnDirectoryListingAnswer;
  /* Streaming callbacks */
  FFSS_CB.CCB.OnStrmOpenAnswer = OnStrmOpenAnswer;
  FFSS_CB.CCB.OnStrmReadAnswer = OnStrmReadAnswer;
  FFSS_CB.CCB.OnStrmWriteAnswer = OnStrmWriteAnswer;
};

FfssUDP::~FfssUDP()
{
  free(Buf);
}

TDI_STATUS FfssUDP::sendto(PTDI_CONNECTION_INFORMATION pConn,void* pBuf,uint Size,PVOID pCxt)
{
  TDI_STATUS ret;
  Sem->WaitTimer();
  ret = KDatagramSocket::sendto(pConn,pBuf,Size,pCxt);
  Sem->Wait();
  Sem->Signal();
  return ret;
}

void FfssUDP::On_sendtoComplete(PVOID pCxt,TDI_STATUS Status,uint ByteCount)
{
  if(pCxt != NULL)
    free(pCxt);
}


uint FfssUDP::OnReceive(uint AddressLength,PTRANSPORT_ADDRESS pTA,uint OptionsLength,PVOID Options,uint Indicated,uchar* Data,uint Available,uchar** RcvBuffer,uint* RcvBufferLen)
{ 
  // Received some data from the client peer.

  GetDatagram(Data,Indicated,pTA);

	// Now, if the transport has more data available than indicated,
	// allocate another buffer to read the rest. When the transport
	// done with it - asynchronously - our OnReceiveComplete() handler
	// is called. Note that failure to submit a buffer supressed further
	// recieve indications - until and if a recv() is issued.

	if (Indicated < Available)
  {
    dprintf("UDP OnReceive : Available > Indicated (%d > %d)",Available,Indicated);
    *RcvBufferLen = BufSize - len;
		*RcvBuffer = (unsigned char *)(Buf + len);
	}
  return Indicated;
}

void FfssUDP::OnReceiveComplete(TDI_STATUS status,uint AddressLength,PTRANSPORT_ADDRESS pTA,uint OptionsLength,PVOID Options,uint Indicated,uchar* Data)
{
	// Buffer for the partially indicated data allocated and submitted during 
	// OnReceive() processing is filled in by the transport. If everything is OK,
	// echo the buffer back to the remote client

  dprintf("UDP OnReceiveComplete : Remaining %d bytes",Indicated);
  GetDatagram(Data,Indicated,pTA);

}

void OnDomainListingAnswer(const char **Domains,int NbDomains)
{
  int i;
  FC_PDomain Dom;

  Sem_UDP->wait();
  for(i=0;i<NbDomains;i++)
  {
    Dom = GetDomainByName(Domains[i],true);
    if(Dom == NULL)
    {
      Dom = (FC_PDomain) malloc(sizeof(FC_TDomain));
      if(Dom != NULL)
      {
        memset(Dom,0,sizeof(FC_TDomain));
        Dom->Name = strdup(Domains[i]);
        FFSS_Domains = SU_AddElementHead(FFSS_Domains,Dom);
      }
      else
        dprintf("OnDomainListingAnswer : Error in malloc()");
    }
  }
  Sem_UDP->signal();
}

/* WARNING !! (char *) of the FM_PHost structure are pointers to STATIC buffer, and must be dupped ! */
/* Except for the FM_PHost->IP that is dupped internaly, and if you don't use it, you MUST free it !! */
void OnServerListingAnswer(const char Domain[],int NbHost,SU_PList HostList)
{
  FM_PHost Hst,Hst2;
  SU_PList Ptr;
  FC_PDomain Dom;
  FC_PServer Ser;

  Sem_UDP->wait();
  Dom = GetDomainByName(Domain,true);
  if(Dom == NULL)
  {
    Dom = (FC_PDomain) malloc(sizeof(FC_TDomain));
    if(Dom != NULL)
    {
      memset(Dom,0,sizeof(FC_TDomain));
      Dom->Name = strdup(Domain);
      //dprintf("OnServerListingAnswer : Adding new domain %s",Domain);
      FFSS_Domains = SU_AddElementHead(FFSS_Domains,Dom);
    }
    else
    {
      dprintf("OnServerListingAnswer : Error in malloc()");
      Sem_UDP->signal();
      return;
    }
  }
  ClearServersMark(Dom->Servers);
  Ptr = HostList;
  while(Ptr != NULL)
  {
    Hst = (FM_PHost) Ptr->Data;
    if(Hst->State != FFSS_STATE_OFF)
    {
      Ser = GetServerByIP(Dom,Hst->IP);
      if(Ser == NULL)
      {
        Ser = (FC_PServer) malloc(sizeof(FC_TServer));
        if(Ser != NULL)
        {
          memset(Ser,0,sizeof(FC_TServer));
          Ser->Name = strdup(Hst->Name);
          Ser->IP = Hst->IP;
          Ser->State = Hst->State;
          Ser->Mark = true;
          Dom->Servers = SU_AddElementHead(Dom->Servers,Ser);
          //dprintf("OnServerListingAnswer : Adding new server %s",Ser->Name);
        }
        else
          dprintf("OnServerListingAnswer : Error in malloc()");
      }
      else
      {
        Ser->Mark = true;
        //dprintf("OnServerListingAnswer : Marking server %s",Ser->Name);
        free(Hst->IP);
      }
    }
    else
      free(Hst->IP);
    Ptr = Ptr->Next;
  }
  Dom->Servers = RemoveServersByMark(Dom->Servers);
  Sem_UDP->signal();
}

void OnSharesListing(const char IP[],const char **Names,const char **Comments,int NbShares)
{
  FC_PShare Shr;
  FC_PServer Ser;
  int i;

  Sem_UDP->wait();
  Ser = GetServerByIP(NULL,IP);
  if(Ser != NULL)
  {
    ClearSharesMark(Ser->Shares);
    for(i=0;i<NbShares;i++)
    {
      Shr = GetShareByName(Ser,Names[i]);
      if(Shr == NULL)
      {
        Shr = (FC_PShare) malloc(sizeof(FC_TShare));
        if(Shr != NULL)
        {
          memset(Shr,0,sizeof(FC_TShare));
          Shr->Name = strdup(Names[i]);
          Shr->Mark = true;
          Ser->Shares = SU_AddElementHead(Ser->Shares,Shr);
          //dprintf("OnSharesListing : Adding new share %s",Shr->Name);
        }
        else
          dprintf("OnSharesListing : Error in malloc()");
      }
      else
      {
        Shr->Mark = true;
        //dprintf("OnSharesListing : Marking server %s",Shr->Name);
      }
    }
    Ser->Shares = RemoveSharesByMark(Ser->Shares);
  }
  else
    dprintf("OnSharesListing : Server %s not found",IP);
  Sem_UDP->signal();
}


FfssTCP::FfssTCP() : KStreamSocket()
{
  BufSize = FFSS_TCP_BUFFER_SIZE;
  Buf = (char *) malloc(BufSize);
  len = 0;
  Entries = NULL;
  Mark = false;
  Used = 0;
  Sem = new FfssSem;
  if(Sem == NULL)
    ASSERT(0);
  Timer = new FfssTimer(Sem,FFSS_TIMEOUT_TCP_MESSAGE*1000);
  if(Timer == NULL)
    ASSERT(0);
  Sem->SetTimer(Timer);
}

FfssTCP::~FfssTCP()
{
  Sem->SignalTimer();
  delete Sem;
  delete Timer;
  free(Buf);
}


TDI_STATUS FfssTCP::connect(PTDI_CONNECTION_INFORMATION RequestAddr)
{
  TDI_STATUS ret;
  Sem->WaitTimer();
  ret = KStreamSocket::connect(RequestAddr,FFSS_TIMEOUT_TCP_MESSAGE*1000);
  Sem->Wait();
  Sem->Signal();
  return ret;

}

void FfssTCP::On_connectComplete(PVOID pCxt,TDI_STATUS Status,uint ByteCount)
{
  if(Status != TDI_SUCCESS)
    dprintf("OnConnectComplete : Cannot connect : %d",Status);
  Sem->SignalTimer();
}

TDI_STATUS FfssTCP::send(void* pBuf,uint Size)
{
  TDI_STATUS ret;

  if(!IsConnected())
  {
    dprintf("FfssTCP::send : Not connected !");
    free(pBuf);
    return TDI_NO_RESOURCES;
  }
  Sem->WaitTimer();
  ret = KStreamSocket::send(pBuf,Size,pBuf,0);
  if((ret != TDI_PENDING) && (ret != TDI_SUCCESS))
  {
    /* Connection has been lost */
    dprintf("FfssTCP::send : Cannot send... connection lost ?");
    free(pBuf);
  }
  Sem->Wait();
  Sem->Signal();
  return ret;
}


void FfssTCP::On_sendComplete(PVOID pCxt,TDI_STATUS Status,uint ByteCount)
{
  if(pCxt != NULL)
    free(pCxt);
}

uint FfssTCP::OnReceive(uint Indicated,uchar* Data,uint Available,uchar** RcvBuffer,uint* RcvBufferLen)
{ 
  if(!GetPacket(this,Data,Indicated))
    disconnect();

	if (Indicated < Available)
  {
    dprintf("TCP OnReceive : Available > Indicated (%d > %d)",Available,Indicated);
    *RcvBufferLen = BufSize - len;
		*RcvBuffer = (unsigned char *)(Buf + len);
	}
  return Indicated;
}

void FfssTCP::OnReceiveComplete(TDI_STATUS status,uint Indicated,uchar* Data)
{
  dprintf("TCP OnReceiveComplete : Remaining %d bytes",Indicated);
  if(!GetPacket(this,Data,Indicated))
    disconnect();

}

void FfssTCP::On_disconnectComplete(PVOID pCxt,TDI_STATUS Status,uint ByteCount)
{
  dprintf("FfssTCP::OnDisconnectComplete : Completed");
  if(pCxt != NULL)
    free(pCxt);
}

void FfssTCP::OnDisconnect(uint OptionsLength,PVOID Options,BOOLEAN bAbort)
{
  dprintf("FfssTCP::OnDisconnect : Remote peer disconnected...");
}

bool OnError(FfssTCP * Server,int Code,const char Descr[])
{
  switch(Code)
  {
  case FFSS_ERROR_RESOURCE_NOT_AVAIL :
  case FFSS_ERROR_NEED_LOGIN_PASS :
  case FFSS_ERROR_TOO_MANY_CONNECTIONS :
  case FFSS_ERROR_IDLE_TIMEOUT :
  case FFSS_ERROR_SHARE_DISABLED :
  case FFSS_ERROR_SHARE_EJECTED :
  case FFSS_ERROR_INTERNAL_ERROR :
    dprintf("OnError : Found fatal error code (%s). Disconnecting",Descr);
    return false;
  case FFSS_ERROR_FILE_NOT_FOUND :
  case FFSS_ERROR_ACCESS_DENIED :
  case FFSS_ERROR_NOT_ENOUGH_SPACE :
  case FFSS_ERROR_CANNOT_CONNECT :
  case FFSS_ERROR_TOO_MANY_TRANSFERS :
  case FFSS_ERROR_DIRECTORY_NOT_EMPTY :
  case FFSS_ERROR_FILE_ALREADY_EXISTS :
  case FFSS_ERROR_SERVER_IS_QUIET :
  case FFSS_ERROR_BUFFER_OVERFLOW :
  case FFSS_ERROR_XFER_MODE_NOT_SUPPORTED :
  case FFSS_ERROR_RESEND_LAST_UDP :
  case FFSS_ERROR_BAD_SEARCH_REQUEST :
  case FFSS_ERROR_NOT_IMPLEMENTED :
    break;
  case FFSS_ERROR_NO_ERROR :
    break;
  }
  return true;
}

FC_PEntry DupEntry(FC_PEntry Ent);
FC_PEntList GetEntryListByPath(FfssTCP *TCP,const char Path[]);
bool OnDirectoryListingAnswer(FfssTCP * Server,const char Path[],int NbEntries,SU_PList Entries)
{
  SU_PList Ptr;
  FC_PEntry Ent;
  FC_PEntList EL;

  Sem_TCP->wait();
  //dprintf("Found a listing of directory %s",Path);
  EL = GetEntryListByPath(Server,Path);
  if(EL != NULL)
  {
    if(EL->Entries == NULL)
    {
      EL->Listed = true;
      Ptr = Entries;
      while(Ptr != NULL)
      {
        Ent = (FC_PEntry) Ptr->Data;
        EL->Entries = SU_AddElementHead(EL->Entries,DupEntry(Ent));
        //dprintf("Entry %s %s",Ent->Name,(Ent->Flags & FFSS_FILE_DIRECTORY)?"Dir":"File");
        Ptr = Ptr->Next;
      }
    }
    else
      dprintf("OnDirectoryListingAnswer : Entries in EntryList are NOT NULL");
  }
  else
  {
    dprintf("OnDirectoryListingAnswer : EntryList not found");
  }
  Sem_TCP->signal();
  return true;
}

void OnStrmOpenAnswer(FfssTCP * Client,const char Path[],int Code,long int Handle,long int FileSize)
{
  PFFSSHANDLE Hdl;

  Sem_Handles->wait();
  Hdl = GetHandleByName(Path);
  if(Hdl == NULL)
  {
    dprintf("OnStrmOpenAnswer : No Handle found for this path : %s",Path);
    Sem_Handles->signal();
    return;
  }
  if(Code == FFSS_ERROR_NO_ERROR)
  {
    //dprintf("OnStrmOpenAnswer : File successfully opened by server with handle %d",Handle);
    Hdl->h_state = FFSS_HANDLE_STATE_OPEN;
    Hdl->h_size = FileSize;
    Hdl->h_handle = Handle;
  }
  Sem_Handles->signal();
}

void OnStrmReadAnswer(FfssTCP * Client,long int Handle,const char Bloc[],long int BlocSize)
{
  PFFSSHANDLE Hdl;

  Sem_Handles->wait();
  Hdl = GetHandleByHandle(Handle);
  if(Hdl == NULL)
  {
    dprintf("OnStrmReadAnswer : No Handle found for this Handle : %d",Handle);
    Sem_Handles->signal();
    return;
  }
  if(BlocSize == 0)
  {
    //dprintf("OnStrmReadAnswer : EOF for file %d",Handle);
    Hdl->h_eof = true;
  }
  else
  {
    if(BlocSize > FFSS_STREAMING_BUFFER_SIZE)
      BlocSize = FFSS_STREAMING_BUFFER_SIZE;
    //dprintf("OnStrmReadAnswer : %ld bytes read from %d",BlocSize,Handle);
    memcpy(Hdl->h_buffer,Bloc,BlocSize);
    Hdl->h_buffer_pos = BlocSize;
  }
  Sem_Handles->signal();
}

void OnStrmWriteAnswer(FfssTCP * Client,long int Handle,int Code)
{
}


/* TO DO : 
  * Lire dans la registry l'ip du master, et la stocker en global dans une var
    Si pas d'ip, faire un MasterSearch, et stocke l'ip trouvee dans la base
  * Ajouter un timer sur les connexions... si elles ne sont pas utilisees souvent, disconnect
    (disable le timer dans le send, et l enable dans le receive)
  * PROPRIETES depuis un share (ou server je c pu) ou encore avant, fait PLANTER

  
  * Ajouter un sendAsync qui n active pas le timer (et dans le recv, detecter que la reponse
    est une reponse de message async, et ne pas desactiver le timer)
    Creer un nouveau type de timer (timerXfer) qui dans son callback IFSMgr_CompleteAsync avec erreur
*/

