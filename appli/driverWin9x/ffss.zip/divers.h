#ifndef _DIVERS_H_
#define _DIVERS_H_

#include "skyutils.h"
class FfssTCP;

typedef struct
{
  char *IP;
  char *Share;
  FfssTCP *TCP;
} FC_TConn, *FC_PConn;

typedef struct
{
  char *Name;
  bool Mark;
} FC_TShare, *FC_PShare;

typedef struct
{
  char *Name;
  char *IP;
  long int State;
  bool Mark;
  SU_PList Shares; /* FC_PShare */
} FC_TServer, *FC_PServer;

typedef struct
{
  char *Name;
  SU_PList Servers; /* FC_PServer */
} FC_TDomain, *FC_PDomain;

#include "ffssfs.h"

#define FFSS_MASTER_IP "172.17.64.3"
//#define FFSS_MASTER_IP NULL

extern SU_PList FFSS_Domains; /* FC_PDomain */
extern SU_PList FFSS_Conns; /* FC_PConn */
extern SU_PList FFSS_Handles; /* PFFSSHANDLE */
extern VSemaphore *Sem_UDP;
extern VSemaphore *Sem_TCP;
extern VSemaphore *Sem_Handles;

void ClearServersMark(SU_PList Servers);
SU_PList RemoveServersByMark(SU_PList Servers);
void ClearSharesMark(SU_PList Shares);
SU_PList RemoveSharesByMark(SU_PList Shares);

FC_PDomain GetDomainByName(const char Domain[],bool UDPLocked);
FC_PServer GetServerByIP(FC_PDomain Domain,const char IP[]); /* MUST CALL Sem_UDP->wait() */
FC_PServer GetServerByName(FC_PDomain Domain,const char Server[],bool UDPLocked);
FC_PShare GetShareByName(FC_PServer Server,const char Share[]); /* MUST CALL Sem_UDP->wait() */
bool IsShareFromServer(FC_PServer Server,const char Share[],bool UDPLocked);
FC_PConn GetConnByIPShare(const char IP[],const char Share[]); /* MUST CALL Sem_TCP->wait() */
FC_PConn CreateConnection(const char IP[],const char Share[]); /* MUST CALL Sem_TCP->wait() */

void FreeShare(FC_PShare Shr);
void FreeSharesList(SU_PList Shares);
void FreeServer(FC_PServer Ser);
/*void FreeServerList(SU_PList Servers);
void FreeDomain(FC_PDomain Dom);
void FreeDomainList();*/
void FreeEntries(SU_PList Entries);

void RemoveConnByConn(FC_PConn Conn); /* MUST CALL Sem_TCP->wait() */
void RemoveConnByIPShare(const char IP[],const char Share[]); /* MUST CALL Sem_TCP->wait() */

FC_PEntList GetEntryListByPath(FfssTCP *TCP,const char Path[]); /* MUST CALL Sem_TCP->wait() */
FC_PEntList GetEntryListByPathOnly(FfssTCP *TCP,const char Path[]); /* MUST CALL Sem_TCP->wait() */
void FreeEntryList(FC_PEntList EL); /* MUST CALL Sem_TCP->wait() */

PFFSSHANDLE GetHandleByName(const char Path[]);
PFFSSHANDLE GetHandleByHandle(long int Handle);

#endif