/****************************************************************/
/* Skyutils functions - Chained list, socket, string, utils     */
/* (c) Christophe CALMEJANE (Ze KiLleR) - 1999-01               */
/****************************************************************/

#ifndef __SKY_UTILS_H__
#define __SKY_UTILS_H__

#define SKYUTILS_VERSION "1.12"

#define strcasecmp stricmp
#define strncasecmp strnicmp

#ifdef MSG_NOSIGNAL
#define SU_MSG_NOSIGNAL MSG_NOSIGNAL
#else
#define SU_MSG_NOSIGNAL 0
#endif

/*#ifndef INADDR_NONE
#define INADDR_NONE -1
#endif*/

#ifndef SOCKET_ERROR
#define SOCKET_ERROR -1
#endif

/* **************************************** */
/*            Chained list functions        */
/* **************************************** */
struct SU_SList;

typedef struct SU_SList
{
  struct SU_SList *Next;
  void *Data;
} SU_TList, *SU_PList;

SU_PList SU_AddElementTail(SU_PList,void *);
SU_PList SU_AddElementHead(SU_PList,void *);
SU_PList SU_DelElementElem(SU_PList,void *); /* THIS FONCTION DOESN'T FREE THE ELEMENT */
SU_PList SU_DelElementTail(SU_PList); /* THIS FONCTION DOESN'T FREE THE ELEMENT */
SU_PList SU_DelElementHead(SU_PList); /* THIS FONCTION DOESN'T FREE THE ELEMENT */
SU_PList SU_DelElementPos(SU_PList,int); /* THIS FONCTION DOESN'T FREE THE ELEMENT */ /* First element is at pos 0 */
void *SU_GetElementTail(SU_PList);
void *SU_GetElementHead(SU_PList);
void *SU_GetElementPos(SU_PList,int); /* First element is at pos 0 */
void SU_FreeList(SU_PList); /* THIS FONCTION DOESN'T FREE THE ELEMENTS */
void SU_FreeListElem(SU_PList); /* THIS FONCTION DOES FREE THE ELEMENTS */
int SU_ListCount(SU_PList);


/* **************************************** */
/*               String functions           */
/* **************************************** */
char *SU_strcat(char *dest,const char *src,int len); /* like strncat, but always NULL terminate dest */
char *SU_strcpy(char *dest,const char *src,int len); /* like strncpy, but doesn't pad with 0, and always NULL terminate dest */
char *SU_nocasestrstr(char *text, char *tofind);  /* like strstr(), but nocase */
bool SU_strwcmp(const char *s,const char *wild); /* True if wild equals s (wild may use '*') */
bool SU_nocasestrwcmp(const char *s,const char *wild); /* Same as strwcmp but without case */
char *SU_TrimLeft(const char *S);
void SU_TrimRight(char *S);
char *SU_strparse(char *s,char delim); /* Like strtok, but if 2 delim are found, an empty string is returned (s[0] = 0) */
void SU_ExtractFileName(const char Path[],char FileName[],const int len); /* Extracts file name (with suffix) from path */
char *SU_strchrl(const char *s,const char *l,char *found); /* Searchs the first occurence of one char of l[i] in s, and returns it in found */
char *SU_strrchrl(const char *s,const char *l,char *found); /* Same as SU_strchrl but starting from the end of the string */
unsigned char SU_toupper(unsigned char c);
unsigned char SU_tolower(unsigned char c);
bool SU_strcasecmp(const char *s,const char *p);



/* Dummy functions used by configure, to check correct version of skyutils */
/* Remove old ones if compatibility has been broken */
void SU_Dummy111(void);
void SU_Dummy112(void);

#endif
