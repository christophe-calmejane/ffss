//=============================================================================
//
// Compuware Corporation
// NuMega Lab
// 9 Townsend West
// Nashua, NH 03060  USA
//
// Copyright (c) 1998 Compuware Corporation. All Rights Reserved.
// Unpublished - rights reserved under the Copyright laws of the
// United States.
//
//=============================================================================

// RFSDIFS.C - File System Interface for Registry File System
// Copyright (c) 1996, Compuware Corporation

// This module contains the functions that are called by the IFSMgr.

#include "divers.h"
#include "ffss.h"
#include PAGEABLE_CODE_SEGMENT
#include PAGEABLE_DATA_SEGMENT

// This is the table of function addresses that RFSD returns to 
// IFSMgr from FfssMountVolume.

volfunc VolumeFunctions = {
	IFS_VERSION,
	IFS_REVISION,
	NUM_VOLFUNC,

	VolDelete, 	    // FS_DeleteFile
	VolDir,		      // FS_Dir
	VolAttrib,	    // FS_FileAttributes
	Vol_Flush,	    // FS_FlushVolume
	VolInfo,	      // FS_GetDiskInfo
	VolOpen,	      // FS_OpenFile
	VolRename,	    // FS_RenameFile
	VolSearch,	    // FS_SearchFile
	VolQuery,	      // FS_QueryResourceInfo
	VolDisconnect,	// FS_DisconnectResource
	ErrorFunc,	    // Function not defined for volume mounts, FSD must return pointer to error function
	VolIoctl16,	    // FS_Ioctl16Drive
	VolParams, 	    // FS_GetDiskParms
	VolFindOpen,	  // FS_FindFirstFile
	VolDasdio	      // FS_DirectDiskIO
};

// This is the table of function addresses that RFSD returns to 
// IFSMgr when a file is opened (VolOpen) or when a FindFirst/FindNext
// operation is initiated (VolFindOpen).

hndlmisc HandleFunctions = {
	IFS_VERSION,
	IFS_REVISION,
	NUM_HNDLMISC,

	HandleSeek,         // FS_SeekFile 
	HandleClose,        // FS_CloseFile
	HandleCommit,	      // FS_CommitFile
	HandleFilelocks,    // FS_LockFile
	HandleFiletimes,    // FS_FileTime
	HandlePiperequest,  // FS_NamedPipeUNCRequest
	HandleHandleinfo,   // FS_NamedPipeHandleInfo
	HandleEnumhandle    // FS_EnumerateHandle
};

// Declare storage for the VolumeHandle. The VolumeHandle is supplied
// by the IFSMgr when the volume is mounted.

VRP* VolumeHandle=0;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	FfssMountVolume
//
// Purpose
//	Provides an entry point for the IFSMgr to notify RFSD of
//	volume events
//
// Parameters
//	pir		pointer to io_req 
//	  ir_flags	subfunction code
//	 For Mount call:
//	  ir_volh	VRP pointer
//	  ir_mntdrv	drive letter code
//	  
// Return Value
//	Returns zero on success.
//
// Remarks
//	There are several subfunctions; ir_flags specifies which
//	subfunction is requested. RFSD supports only the MOUNT
//	function. 
//
//	If RFSD determines that the volume being mounted is on the
//	virtual drive that it created, it sets the fields in the
//	request structure as follows:
//
//		ir_error = 0
//		ir_vfunc = address of volume function table
//
//	In addition, this routine sets field VRP_fsd_entry of the 
//	supplied VRP to point back to the mount function.
//
INT FfssMountVolume(pioreq pir)
{
// Branch on subfunction:

	switch (pir->ir_flags)
	{
	case IR_FSD_MOUNT:
// If the drive being mounted is found to be the virtual drive 
// created by the port driver component of RFSD, then set the
// fields of the request structure to indicate success. 
		if (IsThisOurDrive(pir))
		{
			VolumeHandle = (VRP*)pir->ir_volh;
			VolumeHandle->VRP_fsd_entry = (ULONG)FfssMountVolume;
			Drive = pir->ir_mntdrv;
			pir->ir_vfunc = &VolumeFunctions;
			return (pir->ir_error = 0);
		}	
		break;

// Subfunctions other than IF_FSD_MOUNT are not implemented
	case IR_FSD_VERIFY:
		//dprintf("FFSS FSD : IR_FSD_VERIFY");
		break;
	case IR_FSD_UNLOAD:
		//dprintf("FFSS FSD : IR_FSD_UNLOAD");
		break;
	case IR_FSD_MOUNT_CHILD:
		//dprintf("FFSS FSD : IR_FSD_MOUNT_CHILD");
		break;
	case IR_FSD_MAP_DRIVE:
		//dprintf("FFSS FSD : IR_FSD_MAP_DRIVE");
		break;
	case IR_FSD_UNMAP_DRIVE:
		//dprintf("FFSS FSD : IR_FSD_UNMAP_DRIVE");
		break;
	}

	return (pir->ir_error = -1);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolAttrib
//
// Purpose
//	Several subfunctions related to file attributes. RFSD
//	implements only GET_ATTRIBUTES.
//
// Parameters
//	pir		pointer to io_req 
//	  ir_flags	subfunction code
//	  ir_ppath	unicode path 
//	  ir_attr	return attribute flags
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	Only the GET_ATTRIBUTES subfunction is implemented. The 
//	function calls utility routines that access the Registry
//	to determine if the given path corresponds to a key
//	(directory),  a value (file), or is not found.
//
INT VolAttrib(pioreq pir)
{
  FC_PEntry Ent;

	switch (pir->ir_flags)
	{
	case GET_ATTRIBUTES:
		pir->ir_error = 0;
    dprintf("FS_FileAttributes : Get Attributes");
    Ent = (FC_PEntry)CheckFileExists(pir->ir_ppath);
		if(Ent != NULL)
    {
      //dprintf("FS_FileAttributes : File exists !");
			pir->ir_attr = FILE_ATTRIBUTE_READONLY;
      pir->ir_size = Ent->Size;
      pir->ir_error = 0;
    }
		else if(CheckDirectoryExists(pir->ir_ppath))
    {
      //dprintf("FS_FileAttributes : Directory exists !");
			pir->ir_attr = FILE_ATTRIBUTE_DIRECTORY;
      pir->ir_size = 1024;
      pir->ir_error = 0;
    }
		else
		{
			pir->ir_error = ERROR_FILE_NOT_FOUND;
			pir->ir_attr = 0;
		}
		break;

// Other subfunctions are not implemented.

	case SET_ATTRIBUTES:
	case GET_ATTRIB_COMP_FILESIZE:
	case SET_ATTRIB_MODIFY_DATETIME:
	case GET_ATTRIB_MODIFY_DATETIME:
	case SET_ATTRIB_LAST_ACCESS_DATETIME:
	case GET_ATTRIB_LAST_ACCESS_DATETIME: 
	case SET_ATTRIB_CREATION_DATETIME:
	case GET_ATTRIB_CREATION_DATETIME:
	default:
		pir->ir_error = ERROR_BAD_COMMAND;
		dprintf("Unsupported attribute command");
		break;
	}

	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolDir
//
// Purpose
//	Several subfunctions related to directories. 
//
// Parameters
//	pir		pointer to io_req 
//	  ir_flags	subfunction code
//	  ir_ppath	unicode path 
//	  ir_attr	parsing flags
//
// Return Value
//	Returns zero on success.
//
//
INT VolDir(pioreq pir)
{
// Branch on subfunction

	switch (pir->ir_flags)
	{

	case CHECK_DIR:
// Set ir_error to zero if the specified directory exists, otherwise
// set it to error code.
		//dprintf("VolDir: CHECK_DIR");
		pir->ir_error = CheckDirectoryExists(pir->ir_ppath) ?	0 : ERROR_FILE_NOT_FOUND;
		break;
	case CREATE_DIR:
		pir->ir_error = ERROR_ACCESS_DENIED; // read-only
		//dprintf("VolDir: CREATE_DIR");	
		break;
	case DELETE_DIR:
		pir->ir_error = ERROR_ACCESS_DENIED; // read-only
		//dprintf("VolDir: DELETE_DIR");
		break;
	case QUERY83_DIR:
		//dprintf("VolDir: QUERY83_DIR"); 
		pir->ir_error = -1;	// not implemented		
		break;
	case QUERYLONG_DIR:
		//dprintf("VolDir: QUERYLONG_DIR");
// This function is supposed to "canonicalize" the path. We simply
// copy the supplied path to the output if the key exists.
		if (CheckDirectoryExists(pir->ir_ppath))
    {
			CopyParsedPath(pir->ir_ppath2, pir->ir_ppath);
      pir->ir_error = 0;
    }
		else
			pir->ir_error = ERROR_FILE_NOT_FOUND;
		break;
	default:
		DEBUGERROR("unknown directory function request");
		pir->ir_error = ERROR_BAD_COMMAND;
	}
	return pir->ir_error;
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolInfo
//
// Purpose
//	Retrieves volume parameters
//
// Parameters
//	pir		pointer to io_req 
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	See the code for the fields of the request structure
//	that are set by this service.
//
//	For the virtual drive provided by RFSD, the numbers should
//	make sense, but have no real meaning.
//
INT VolInfo(pioreq pir)
{
	dprintf("Volume Info");
	pir->ir_length = 0x200;		// bytes per sector
	pir->ir_size = 1;		// number of clusters
	pir->ir_data = 0;		// pointer to FAT ID byte
	pir->ir_sectors = 2;		// sectors per cluster
	pir->ir_numfree = 1;		// number of free clusters
	return (pir->ir_error = 0);
}


char *VolOpenGetAccess(unsigned char f)
{
  if(f & ACCESS_READONLY)
    return "ACCESS_READONLY";
  else if(f & ACCESS_WRITEONLY)
    return "ACCESS_WRITEONLY";
  else if(f & ACCESS_READWRITE)
    return "ACCESS_READWRITE";
  else if(f & ACCESS_EXECUTE)
    return "ACCESS_EXECUTE";
  else
    return "ACCESS_UNKNOWN";
}

char *VolOpenGetShare(unsigned char f)
{
 if(f & SHARE_COMPATIBILITY)
   return "SHARE_COMPATIBILITY";
 else if(f & SHARE_DENYREADWRITE)
   return "SHARE_DENYREADWRITE";
 else if(f & SHARE_DENYWRITE)
   return "SHARE_DENYWRITE";
 else if(f & SHARE_DENYREAD)
   return "SHARE_DENYREAD";
 else if(f & SHARE_DENYNONE)
   return "SHARE_DENYNONE";
 else if(f & SHARE_FCB)
   return "SHARE_FCB";
 else
   return "SHARE_UNKNOWN";
}

char *VolOpenGetAction(unsigned short f)
{
  if(f & ACTION_CREATENEW)
   return "ACTION_CREATENEW";
  else if(f & ACTION_CREATEALWAYS)
   return "ACTION_CREATEALWAYS";
  else if(f & ACTION_OPENEXISTING)
   return "ACTION_OPENEXISTING";
  else if(f & ACTION_OPENALWAYS)
   return "ACTION_OPENALWAYS";
  else if(f & ACTION_REPLACEEXISTING)
   return "ACTION_REPLACEEXISTING";
  else
   return "ACTION_UNKNOWN";
}

char *VolOpenGetSpecialAction(unsigned short f)
{
  if(f & OPEN_FLAGS_COMMIT)
    return "OPEN_FLAGS_COMMIT";
  else if(f & OPEN_FLAGS_NO_CACHE)
    return "OPEN_FLAGS_NO_CACHE";
  else if(f & OPEN_FLAGS_NO_COMPRESS)
    return "OPEN_FLAGS_NO_COMPRESS";
  else if(f & OPEN_FLAGS_ALIAS_HINT)
    return "OPEN_FLAGS_ALIAS_HINT";
  else if(f & OPEN_FLAGS_REOPEN)
    return "OPEN_FLAGS_REOPEN";
  else if(f & R0_SWAPPER_CALL)
    return "R0_SWAPPER_CALL";
  else
    return "OPEN_FLAGS_UNKNOWN";
}

char *VolOpenGetAttr(unsigned int f)
{
  if(f & FILE_ATTRIBUTE_READONLY)
    return "FILE_ATTRIBUTE_READONLY";
  else if(f & FILE_ATTRIBUTE_HIDDEN)
    return "FILE_ATTRIBUTE_HIDDEN";
  else if(f & FILE_ATTRIBUTE_SYSTEM)
    return "FILE_ATTRIBUTE_SYSTEM";
  else if(f & FILE_ATTRIBUTE_DIRECTORY)
    return "FILE_ATTRIBUTE_DIRECTORY";
  else
    return "FILE_ATTRIBUTE_UNKNOWN";
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolOpen
//
// Purpose
//	Open a file
//
// Parameters
//	pir		pointer to io_req 
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	This routine calls Registry services to see if the supplied
//	filename maps to a value in the Registry. If so, it creates
//	a handle structure and initializes it. It then sets ir_fh to
//	to point to the handle structure, and sets up ir_hfunc to 
//	point to the handle functions.
//
INT VolOpen(pioreq pir)
{
  long int Ffss_Flags;
  int PathType;
  char FullPath[1024];
	PathElement* pLast;
  FC_PDomain Dom;
  FC_PServer Ser;
  char ShareName[FFSS_MAX_SHARENAME_LENGTH];
  FC_PConn Conn;
  long str_len;
	_QWORD qResult;

	PFFSSHANDLE pHndl;

// Uncomment this code display the path being opened to debug console
   memset(FullPath, 0, 256);
   UniToBCSPath((unsigned char *)FullPath, pir->ir_ppath->pp_elements, 256, BCS_WANSI, &qResult);
   dprintf("Open File: path=|%s| - %s %s %s %s %s",FullPath,VolOpenGetAccess(pir->ir_flags),VolOpenGetShare(pir->ir_flags),VolOpenGetAction(pir->ir_options),VolOpenGetSpecialAction(pir->ir_options),VolOpenGetAttr(pir->ir_attr));

	pir->ir_error = ERROR_FILE_NOT_FOUND;	// assume error

/* Values for ir_options for VFN_OPEN: 
ACTION_MASK				0xff	// Open Actions Mask 
ACTION_OPENEXISTING		0x01	// open an existing file 
ACTION_REPLACEEXISTING	0x02	// open existing file and set length 
ACTION_CREATENEW		0x10	// create a new file, fail if exists 
ACTION_OPENALWAYS		0x11	// open file, create if does not exist 
ACTION_CREATEALWAYS		0x12	// create a new file, even if it exists */
  if(pir->ir_options & ACTION_OPENEXISTING)
  {
    Ffss_Flags = FFSS_STRM_OPEN_READ;
    //dprintf("Open for reading");
  }
  else
  {
    //dprintf("Open for writing");
    Ffss_Flags = FFSS_STRM_OPEN_WRITE;
  }

  Ffss_Flags = Ffss_Flags | FFSS_STRM_OPEN_BINARY; // Defaults to binary mode

// Parse the supplied unicode path
  if(ParseFindPath(pir->ir_ppath, &PathType, FullPath, sizeof(FullPath), &pLast, &Dom, &Ser, ShareName,&Conn, false))
  {
    if(PathType != PATH_TYPE_DIRECTORY)
    {
      dprintf("Open File : PATH_TYPE is NOT a directory.... WARNING !!!");
     	return pir->ir_error;
    }
    if((pir->ir_attr & FILE_FLAG_WILDCARDS) == 0) /* Add last path component */
    {
      if(FullPath[1] != 0)
        strcat(FullPath,"/");
      str_len = strlen(FullPath);
		  UniToBCS((unsigned char *)(FullPath+str_len),pir->ir_aux2.aux_str,ustrlen(pir->ir_aux2.aux_str)*2,sizeof(FullPath)-str_len,BCS_WANSI,&qResult);
		  FullPath[qResult.ddLower+str_len] = '\0';
    }
// If the value exists, alloc and init a handle structure
		pHndl = (PFFSSHANDLE)malloc(sizeof(*pHndl));
    memset(pHndl,0,sizeof(FFSSHANDLE));
		pHndl->h_sig = SIGFILE;
		pHndl->h_name = strdup(FullPath);
    pHndl->h_state = FFSS_HANDLE_STATE_WAITING;

    // Add pHndl to list of opened handles
    Sem_Handles->wait();
    FFSS_Handles = SU_AddElementHead(FFSS_Handles,pHndl);
    Sem_Handles->signal();

    //dprintf("Open File: Sending STREAMING OPEN for %s with %d",FullPath,Ffss_Flags);
    // Synchronized function
    FC_SendMessage_StrmOpen(Conn->TCP,FullPath,Ffss_Flags);

    if(pHndl->h_state == FFSS_HANDLE_STATE_OPEN)
    {
      Sem_TCP->wait();
      pHndl->h_TCP = Conn->TCP;
      Conn->TCP->Used++;
      Sem_TCP->signal();
// If successful, return a pointer to the handle struct in ir_fh, and set
// up the handle function pointers.
  		pir->ir_error = 0;
	  	pir->ir_fh = pHndl;
		  pir->ir_hfunc->hf_read = HandleRead;
		  pir->ir_hfunc->hf_write = HandleWrite;	
		  pir->ir_hfunc->hf_misc = &HandleFunctions;
      pir->ir_size = pHndl->h_size;
      pir->ir_attr = 0;
      if(Ffss_Flags & FFSS_STRM_OPEN_READ)
      {
        dprintf("VolOpen : Successfully opened file %s (size=%ld)",pHndl->h_name,pir->ir_size);
        pir->ir_size = pHndl->h_size;
        pir->ir_options = ACTION_OPENED;
      }
      else
      {
        dprintf("VolOpen : Successfully created file %s",pHndl->h_name);
        pir->ir_size = 0;
        pir->ir_options = ACTION_CREATED;// new file has been created
//        pir->ir_options = ACTION_REPLACED;// existing file has been replaced
      }
    }
    else
    {
      // Remove pHndl to list of opened handles
      Sem_Handles->wait();
      FFSS_Handles = SU_DelElementElem(FFSS_Handles,pHndl);
      Sem_Handles->signal();
      dprintf("VolOpen : Couldn't open file %s",pHndl->h_name);
      free(pHndl->h_name);
      free(pHndl);
    }
	}
	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolQuery
//
// Purpose
//	Returns information about the file system
//
// Parameters
//	pir		pointer to io_req 
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	Refer to the code for meanings of returned fields in the
//	request structure.
//
INT VolQuery(pioreq pir)
{
	//dprintf("Volume Query");

// Local FSDs (as opposed to network) need respond only when ir_options
// is equal to two.
	if (pir->ir_options == 2)
	{
	// the low word of ir_length is set to the max size of a single path component.
	// the high word of ir_length is set to the max size of an cntire path.
		pir->ir_length = 64 | (260 << 16);	
		pir->ir_options = FS_VOL_SUPPORTS_LONG_NAMES | FS_CASE_IS_PRESERVED;
		pir->ir_pos = 0;
		pir->ir_error = 0;
	}
	else
		pir->ir_error = ERROR_INVALID_FUNCTION;

	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolIoctl16
//
// Purpose
//	Process IOCTL requests
//
// Parameters
//	pir		pointer to io_req 
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	The IOCTLs correspond to INT 21h AH=44h. It's not known which of
//	these are critical to the operation of RFSD, but this minimum
//	set seems to be sufficient.
//
INT VolIoctl16(pioreq pir)
{
	PDEVICEPARAMS pDP;
	PCLIENT_STRUCT pRegs;
	static MEDIAID Mid = {
		0, 		// info level
		1, 		// serial number
		{'F','F','S','S',' ','F','S','D',' ',' ',' '},	// volume label
		{'F','A','T','1','6',' ',' ',' '}
	};
	PMEDIAID pMid;

// name "pRegs" enables us to use register abbreviation macros, e.g. _clientCL
	pRegs = (PCLIENT_STRUCT)pir->ir_cregptr;
		

// The buffer is either in ir_data or in client ds:dx. An options bit is
// queried to make this determination (IOCTL_PKT_LINEAR_ADDRESS).

	pir->ir_error = -1;		// assume error

	switch (pir->ir_flags)	
	{
	case 0:				// AX=4400h File or device
		_clientDX = Drive;	// say we are a device
		_clientFlags &= ~1;	// clear carry
		pir->ir_error = 0;	// success
		break;
	case 8:				// AX=4408h Check removable
		_clientAX = 1;		// not removable
		_clientFlags &= ~1;	// clear carry
		pir->ir_error = 0;	// success
		break;
	case 0xd:			// AX=440Dh

		switch ( _clientCL )	// branch on subfunction
		{
		case 0x60: // get device params
			pDP = (pir->ir_options & IOCTL_PKT_LINEAR_ADDRESS) ?
				(PDEVICEPARAMS)pir->ir_data :
				(PDEVICEPARAMS)Map_Flat(CLIENT_DS, CLIENT_DX);
			IoctlGetDeviceParams(pDP);
			_clientFlags &= ~1;
			pir->ir_error = 0;
			break;

		case 0x66: // get media id
			pMid = (pir->ir_options & IOCTL_PKT_LINEAR_ADDRESS) ?
				(PMEDIAID)pir->ir_data :
				(PMEDIAID)Map_Flat(CLIENT_DS, CLIENT_DX);
				
			memcpy(pMid, &Mid, sizeof(Mid));
			_clientFlags &= ~1;
			pir->ir_error = 0;
			break;	

		default:	
			DEBUGWARN("Unhandled 440d ioctl16 subfunction");
		}
		break;

	default:
			DEBUGWARN("Unhandled ioctl16 function");
	}

	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	VolFindOpen
//
// Purpose
//	Initiates a find first/ find next operation
//
// Parameters
//	pir		pointer to io_req 
//	  ir_ppath	path name
//	  ir_attr	parsing flags, match attributes
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	The IFSMgr calls this routine to retrieve file/directory information
//	for a particular path. The supplied path may include wild cards. It
//	is strongly recommended to rely on the IFSMgr's wild card matching
//	routines so that all FSDs behave the same.
//	
//	The first call in returns the first file or directory found, and also
//	returns a find handle in ir_fh. The IFSMgr passes this back to the
//	FindNext routine. When this call succeeds, it must supply the address
//	of the FindNext procedure in the ir_hfunc structure.
//
//	Match attributes are not fully implemented in RFSD.
//
INT VolFindOpen(pioreq pir)
{
  FC_PDomain Dom=NULL;
  FC_PServer Ser=NULL;
  char ShareName[FFSS_MAX_SHARENAME_LENGTH];
  FC_PConn Conn=NULL;
	char FullPath[1024];
	PFINDCONTEXT pCtx = NULL;
	int PathType;
	PCHAR p;
	INT MatchElem, i;
	PathElement* pMatch=NULL;
	_QWORD qResult;
	struct _WIN32_FIND_DATA* pFile;
	short e;
  FC_PEntList EL=NULL;
  SU_PList Ptr;
  char str[1024];

// Uncomment this code to dump the path and other params to the debug console
    memset(FullPath, 0, sizeof(FullPath));
    UniToBCSPath((unsigned char *)FullPath, pir->ir_ppath->pp_elements, 256, BCS_WANSI, &qResult);
    dprintf("Find Open: flags=%x, path=|%s|", pir->ir_attr, FullPath);

	pir->ir_error = 0;		// assume success
	pir->ir_fh = 0;

// pFile points to the structure that  receives the file information
	pFile = (struct _WIN32_FIND_DATA*)pir->ir_data;

// Special case: IFSMgr wants the volume label
	if (pir->ir_attr & FILE_ATTRIBUTE_LABEL)
	{
		BCSToUni(pFile->cFileName,(unsigned char *)"FFSS NET", 9,BCS_WANSI, &qResult);
		pir->ir_fh = 0;
		pFile->dwFileAttributes = FILE_ATTRIBUTE_LABEL; 
		ZeroTime(&pFile->ftCreationTime);
		ZeroTime(&pFile->ftLastAccessTime);
		ZeroTime(&pFile->ftLastWriteTime);
		PutShortName(pFile->cAlternateFileName, 0, 0);
		pir->ir_hfunc->hf_read = FindNext;
		pir->ir_hfunc->hf_write = ErrorFunc;	
		pir->ir_hfunc->hf_misc = &HandleFunctions;
    //dprintf("FIND OPEN : FILE_ATTRIBUTE_LABEL");

		return 0;
	}

// Parse the supplied path. There must be a valid Domain/Server/ShareName
  Sem_UDP->wait();
	if(ParseFindPath(pir->ir_ppath, &PathType, FullPath, sizeof(FullPath), &pMatch, &Dom, &Ser, ShareName, &Conn, true))
	{
    if(pir->ir_attr & FILE_FLAG_WILDCARDS)
    {
      switch(PathType)
      {
      case PATH_TYPE_DOMAINS :
        Sem_UDP->signal();
        if(FFSS_MASTER_IP != NULL)
        {
          //dprintf("##FIND OPEN : Requesting domains to master %s",FFSS_MASTER_IP);
          FC_SendMessage_DomainListing(FFSS_MASTER_IP);
        }
        break;
      case PATH_TYPE_SERVERS :
        Sem_UDP->signal();
        if(FFSS_MASTER_IP == NULL)
          FC_SendMessage_ServerSearch();
        else
        {
          //dprintf("##FIND OPEN : Requesting servers of domain %s",Dom->Name);
          FC_SendMessage_ServerList(FFSS_MASTER_IP,NULL,Dom->Name);
        }
        break;
      case PATH_TYPE_SHARES :
        Sem_UDP->signal();
        //dprintf("##FIND OPEN : Requesting shares of server %s",Ser->IP);
        FC_SendMessage_SharesListing(Ser->IP);
        break;
      case PATH_TYPE_DIRECTORY :
        Sem_UDP->signal();
        //dprintf("##FIND OPEN : Requesting files of %s in share %s of server %s",FullPath,ShareName,Ser->IP);
        Sem_TCP->wait();
        EL = (FC_PEntList) malloc(sizeof(FC_TEntList));
        if(EL != NULL)
        {
          memset(EL,0,sizeof(FC_TEntList));
          EL->Name = strdup(FullPath);
          EL->Used = true;
          Conn->TCP->Entries = SU_AddElementTail(Conn->TCP->Entries,EL);
        }
        Sem_TCP->signal();
        FC_SendMessage_DirectoryListing(Conn->TCP,FullPath);
        break;
      default :
        Sem_UDP->signal();
        dprintf("??? FIND OPEN ASSERT : PATH_TYPE UNKNOWN !!");
        ASSERT(0);
      }
    }
    else
      Sem_UDP->signal();
// If parse is successful, allocate memory for a find handle
		pCtx = (PFINDCONTEXT)malloc(sizeof(FINDCONTEXT));
    memset(pCtx,0,sizeof(FINDCONTEXT));
		if (pCtx != 0)
    {
      pCtx->fc_PathType = PathType;
    }
    else
			pir->ir_error = ERROR_FILE_NOT_FOUND;
	}
	else
  {
    Sem_UDP->signal();
    dprintf("FIND OPEN : File not Found");
		pir->ir_error = ERROR_FILE_NOT_FOUND;	// parse failed
  }

// If ir_error is still OK, we have a valid key. Now we can begin the 
// matching proces.

	if (pir->ir_error == 0)
	{

// initialize the find handle

		pCtx->fc_sig = SIGFIND;	
    if(Dom != NULL)
		  pCtx->fc_Domain = strdup(Dom->Name);
    if(Ser != NULL)
		  pCtx->fc_Server = strdup(Ser->Name);

    if(PathType != PATH_TYPE_ROOT)
    {
// copy the metamatch info to the find handle
		  if (pMatch->pe_length != 0)
		  {
			  pCtx->fc_match = (unsigned short *)malloc(pMatch->pe_length);
			  memcpy(pCtx->fc_match, pMatch->pe_unichars, pMatch->pe_length);
			  pCtx->fc_match[pMatch->pe_length/sizeof(WORD)-1] = 0;	
		  }
    }

// set ir_fh to the find handle and point to the handle functions

		pir->ir_fh = pCtx;
		pir->ir_hfunc->hf_read = FindNext; // this is the key one now
		pir->ir_hfunc->hf_write = ErrorFunc;	
		pir->ir_hfunc->hf_misc = &HandleFunctions;

// The NO FILE_FLAG_WILDCARDS seems to be a hint that the IFSMgr just wants to
// verify that the supplied path is a directory. We return the supplied
// name as the first find.
		if((pir->ir_attr & FILE_FLAG_WILDCARDS) == 0)
		{
      pFile->cFileName[0] = 0;
      pFile->cAlternateFileName[0] = 0;
      if(PathType != PATH_TYPE_ROOT)
      {
			  //if (pMatch->pe_length != 0)
				  memcpy(pFile->cFileName, pMatch->pe_unichars, pMatch->pe_length);
			  //else
				  //memcpy(pFile->cFileName,pir->ir_ppath->pp_elements[0].pe_unichars,pir->ir_ppath->pp_elements[0].pe_length);
      }
      else
        pFile->cFileName[0] = 0;

      pFile->dwFileAttributes = 0;
      if(Conn == NULL)
			  pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
      else
      {
        Sem_TCP->wait();
        EL = GetEntryListByPathOnly(Conn->TCP,FullPath);
        if(EL == NULL)
        {
          //dprintf("FIND OPEN : EntryList not found for %s - Creating a new one",FullPath);
          EL = (FC_PEntList) malloc(sizeof(FC_TEntList));
          if(EL != NULL)
          {
            memset(EL,0,sizeof(FC_TEntList));
            EL->Name = strdup(FullPath);
            EL->Used = true;
            Conn->TCP->Entries = SU_AddElementTail(Conn->TCP->Entries,EL);
          }
          else
            pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
          Sem_TCP->signal();
          if(pFile->dwFileAttributes == 0)
            FC_SendMessage_DirectoryListing(Conn->TCP,FullPath);
        }
        else
          Sem_TCP->signal();
        if(pFile->dwFileAttributes == 0)
        {
          if(!EL->Listed)
          {
            //dprintf("FIND OPEN : Not listed");
            pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
          }
          else
          {
		        UniToBCS((unsigned char *)str,pMatch->pe_unichars,pMatch->pe_length-2,sizeof(str)-1,BCS_WANSI,&qResult);
		        str[qResult.ddLower] = '\0';
            //dprintf("FindOpen : Searching %s to be dir or file",str);
            Ptr = EL->Entries;
            while(Ptr != NULL)
            {
              if(SU_strcasecmp(str,((FC_PEntry)Ptr->Data)->Name))
              {
                if(((FC_PEntry)Ptr->Data)->Flags & FFSS_FILE_DIRECTORY)
                {
                  //dprintf("entry %s found to be DIR !",str);
			            pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
                }
                else
                {
                  //dprintf("entry %s found to be FILE !",str);
			            pFile->dwFileAttributes = FILE_ATTRIBUTE_READONLY;
      				    pFile->nFileSizeLow = ((FC_PEntry)Ptr->Data)->Size;
					        pFile->nFileSizeHigh = 0;
					        ZeroTime(&pFile->ftCreationTime);
					        ZeroTime(&pFile->ftLastAccessTime);
					        ZeroTime(&pFile->ftLastWriteTime);
                }
                break;
              }
              Ptr = Ptr->Next;
            }
            if(Ptr == NULL)
            {
              //dprintf("##FIND OPEN : WARNING !! %s not found in listed directory",str);
			        pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
            }
          }
          EL->Used = false;
        }
      }

			PutShortName(pFile->cAlternateFileName, (PCHAR)pFile->cFileName, pCtx->fc_index);
		}
		else // Normal case: get first file by calling find next routine
    {
      if(PathType & PATH_TYPE_DIRECTORY)
        pCtx->fc_EntryList = EL;
			FindNext(pir);
    }

		if (pir->ir_error != 0)
		{
		// save error code because HandleClose clears it
			e = pir->ir_error; 
			HandleClose(pir);
			pir->ir_error = e;
			pir->ir_fh = 0;
		}
	}
	else if (pCtx)
		free(pCtx);

	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	FindNext
//
// Purpose
//	Continues a find first/ find next operation
//
// Parameters
//	pir		pointer to io_req 
//	  ir_ppath	path name
//	  ir_attr	parsing flags, match attributes
//	  ir_fh		find handle (context)
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	This call is always preceded by a call to VolOpen which sets up
// 	ir_fh to point to a find handle (FINDCONTEXT). This data structure
//	is a private data structure for RFSD, not a standard IFSMgr struct.
//	Each FSD implements whatever it deems necessary to find the next
//	file. The Registry calls make this very easy, because they are
//	accessed by index. The FINDCONTEXT tracks whether the keys have
//	all been enumerated. After the keys are enumerated, it then
//	begin enumerating the values.
//
int __cdecl FindNext(pioreq pir)
{
	PFINDCONTEXT pCtx;
	struct _WIN32_FIND_DATA* pFile;
	_QWORD qResult;
	CHAR KeyName[128];
	DWORD ValueLength, ValueType;
	DWORD DataLength;
  FC_PDomain Dom=NULL;
  FC_PServer Ser=NULL;
  FC_PShare Shr=NULL;
  FC_PEntList EL;
  FC_PEntry Ent;

	pir->ir_error = ERROR_FILE_NOT_FOUND;	// assume no more files

// Get the context from the previous call and validate it
	pCtx = (PFINDCONTEXT)pir->ir_fh;
	if (pCtx == 0)	
		return pir->ir_error;

// get a pointer to the structure to hold the retured file information
	pFile= (struct _WIN32_FIND_DATA*)pir->ir_data;

	switch(pCtx->fc_PathType)
	{
    case PATH_TYPE_DOMAINS :
      Sem_UDP->wait();
      Dom = (FC_PDomain)SU_GetElementPos(FFSS_Domains,pCtx->fc_index);
      while(Dom != NULL)
      {
			  BCSToUni(pFile->cFileName, (unsigned char *)Dom->Name,strlen(Dom->Name)+1,BCS_WANSI, &qResult);
        pCtx->fc_index++;
			  if((pCtx->fc_match == NULL) || IFSMgr_MetaMatch(pCtx->fc_match,pFile->cFileName,UFLG_NT_DOS|UFLG_META))
        {
				  pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
				  PutShortName(pFile->cAlternateFileName,(PCHAR)pFile->cFileName,pCtx->fc_index);
          //dprintf("##FIND NEXT : %d -%U- (%U)",pCtx->fc_index,pFile->cFileName,pFile->cAlternateFileName);
				  pir->ir_error = 0;
				  break;
        }
        Dom = (FC_PDomain)SU_GetElementPos(FFSS_Domains,pCtx->fc_index);
      }
      Sem_UDP->signal();
      break;
    case PATH_TYPE_SERVERS :
      Sem_UDP->wait();
      Dom = GetDomainByName(pCtx->fc_Domain,true);
      if(Dom != NULL)
      {
        Ser = (FC_PServer)SU_GetElementPos(Dom->Servers,pCtx->fc_index);
        while(Ser != NULL)
        {
			    BCSToUni(pFile->cFileName, (unsigned char *)Ser->Name,strlen(Ser->Name)+1,BCS_WANSI, &qResult);
          pCtx->fc_index++;
			    if((pCtx->fc_match == NULL) || IFSMgr_MetaMatch(pCtx->fc_match,pFile->cFileName,UFLG_NT_DOS|UFLG_META))
          {
				    pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
				    PutShortName(pFile->cAlternateFileName,(PCHAR)pFile->cFileName,pCtx->fc_index);
            //dprintf("##FIND NEXT : %d - %U (%U)",pCtx->fc_index,pFile->cFileName,pFile->cAlternateFileName);
				    pir->ir_error = 0;
				    break;
          }
          Ser = (FC_PServer)SU_GetElementPos(Dom->Servers,pCtx->fc_index);
        }
      }
      Sem_UDP->signal();
      break;
    case PATH_TYPE_SHARES :
      Sem_UDP->wait();
      Dom = GetDomainByName(pCtx->fc_Domain,true);
      if(Dom != NULL)
      {
        Ser = GetServerByName(Dom,pCtx->fc_Server,true);
        if(Ser != NULL)
        {
          Shr = (FC_PShare)SU_GetElementPos(Ser->Shares,pCtx->fc_index);
          while(Shr != NULL)
          {
			      BCSToUni(pFile->cFileName, (unsigned char *)Shr->Name,strlen(Shr->Name)+1,BCS_WANSI, &qResult);
            pCtx->fc_index++;
			      if((pCtx->fc_match == NULL) || IFSMgr_MetaMatch(pCtx->fc_match,pFile->cFileName,UFLG_NT_DOS|UFLG_META))
            {
				      pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
				      PutShortName(pFile->cAlternateFileName,(PCHAR)pFile->cFileName,pCtx->fc_index);
              //dprintf("##FIND NEXT : %d - %U (%U)",pCtx->fc_index,pFile->cFileName,pFile->cAlternateFileName);
				      pir->ir_error = 0;
				      break;
            }
          }
        }
      }
      Sem_UDP->signal();
      break;
    case PATH_TYPE_DIRECTORY :
      Sem_TCP->wait();
      EL = pCtx->fc_EntryList;
      if(EL != NULL)
      {
        while(pCtx->fc_index < SU_ListCount(EL->Entries))
        {
          Ent = (FC_PEntry) SU_GetElementPos(EL->Entries,pCtx->fc_index);
          if(Ent == NULL)
	          BCSToUni(pFile->cFileName, (unsigned char *)"",1,BCS_WANSI, &qResult);
          else
			      BCSToUni(pFile->cFileName, (unsigned char *)Ent->Name,strlen(Ent->Name)+1,BCS_WANSI, &qResult);
			    if((pCtx->fc_match == NULL) || IFSMgr_MetaMatch(pCtx->fc_match,pFile->cFileName,UFLG_NT_DOS|UFLG_META))
          {
            if(Ent->Flags & FFSS_FILE_DIRECTORY)
				      pFile->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
            else
            {
					    pFile->dwFileAttributes = FILE_ATTRIBUTE_READONLY;
					    pFile->nFileSizeLow = Ent->Size;
					    pFile->nFileSizeHigh = 0;
					    ZeroTime(&pFile->ftCreationTime);
					    ZeroTime(&pFile->ftLastAccessTime);
					    ZeroTime(&pFile->ftLastWriteTime);
					    pir->ir_pos = (ULONG)pCtx;
            }
				    PutShortName(pFile->cAlternateFileName,(PCHAR)pFile->cFileName,pCtx->fc_index);
            //dprintf("##FIND NEXT : %d - %U (%U)",pCtx->fc_index,pFile->cFileName,pFile->cAlternateFileName);
				    pir->ir_error = 0;
            pCtx->fc_index++;
				    break;
          }
          pCtx->fc_index++;
        }
      }
      Sem_TCP->signal();
      break;
  }
	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	HandleRead
//
// Purpose
//	Handles read requests to a previously opened file
//
// Parameters
//	pir		pointer to io_req 
//	  ir_fh		file handle
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	Although we could just call the Registry services, we act more like
// 	a real FSD and call the IOS to do the read.
//
int __cdecl HandleRead(pioreq pir)
{
	PFFSSHANDLE h = (PFFSSHANDLE)pir->ir_fh;
	WORD result;
	IOP* pIop; 
	IOR* pIor;
	VRP* pVrp;
  long int StartPos;
  long int data_pos;

  dprintf("Handle Read : Begin");
	pir->ir_error = -1;		// assume error
	if (h->h_sig != SIGFILE)
		return (pir->ir_error = ERROR_INVALID_HANDLE);

  StartPos = pir->ir_pos;
  data_pos = 0;
  /* Check if some data are available in handle's buffer */
  if(h->h_buffer_pos != 0)
  {
    dprintf("Handle Read : Some data in buffer");
    if(h->h_buffer_pos > pir->ir_length) /* If more data than requested *in stock* */
    {
      memcpy((char *)pir->ir_data,h->h_buffer,pir->ir_length); /* Copy to user's buffer */
      data_pos = pir->ir_length;
      memmove(h->h_buffer,h->h_buffer+data_pos,h->h_buffer_pos-pir->ir_length); /* Copy the remaining bytes to handle's buffer */
      h->h_buffer_pos -= pir->ir_length;
      pir->ir_length = 0;
    }
    else
    {
      memcpy((char *)pir->ir_data,h->h_buffer,h->h_buffer_pos); /* Copy to user's buffer */
      data_pos = h->h_buffer_pos;
      pir->ir_length -= h->h_buffer_pos;
      h->h_buffer_pos = 0;
    }
  }
  dprintf("Handle Read : Requesting %d bytes of data",pir->ir_length);
  while(pir->ir_length > 0)
  {
    dprintf("Handle Read : Sending STREAMING READ for %d starting at %ld",h->h_handle,StartPos+data_pos);
    h->h_buffer_pos = 0;
    h->h_eof = false;
    // Synchronized function
    h->h_TCP->Sem->SetTimeout(FFSS_TIMEOUT_TRANSFER*1000);
    if(!FC_SendMessage_StrmRead(h->h_TCP,h->h_handle,StartPos+data_pos,pir->ir_length))
    {
      h->h_TCP->Sem->SetTimeout(FFSS_TIMEOUT_TCP_MESSAGE*1000);
      dprintf("Read File : Error sending Streaming Read message !");
      pir->ir_length = data_pos;
      pir->ir_pos += pir->ir_length;
      return pir->ir_error;
    }
    h->h_TCP->Sem->SetTimeout(FFSS_TIMEOUT_TCP_MESSAGE*1000);
    if(h->h_eof)
    {
      dprintf("Read File : EOF");
      pir->ir_length = data_pos;
      pir->ir_pos += pir->ir_length;
      pir->ir_error = 0;
      return pir->ir_error;
    }
    if(h->h_buffer_pos == 0)
    {
      dprintf("Read File : Timed out reading file");
      pir->ir_length = data_pos;
      pir->ir_pos += pir->ir_length;
      return (pir->ir_error=ERROR_SECTOR_NOT_FOUND);
    }
    if(h->h_buffer_pos > pir->ir_length) /* If more data than requested returned */
    {
      //dprintf("More than requested : %ld %ld",h->h_buffer_pos,pir->ir_length);
      memcpy((char *)pir->ir_data+data_pos,h->h_buffer,pir->ir_length); /* Copy to user's buffer */
      data_pos += pir->ir_length;
      //dprintf("Copying %d remaining bytes to handle's buffer",h->h_buffer_pos-pir->ir_length);
      memmove(h->h_buffer,h->h_buffer+pir->ir_length,h->h_buffer_pos-pir->ir_length); /* Copy the remaining bytes to handle's buffer */
      h->h_buffer_pos -= pir->ir_length;
      pir->ir_length = 0;
    }
    else
    {
      //dprintf("Copy whole block : %ld %ld",data_pos,h->h_buffer_pos);
      memcpy((char *)pir->ir_data+data_pos,h->h_buffer,h->h_buffer_pos); /* Copy to user's buffer */
      data_pos += h->h_buffer_pos;
      pir->ir_length -= h->h_buffer_pos;
      h->h_buffer_pos = 0;
    }

  }
  dprintf("Read File : Read complete. Returning");
  pir->ir_length = data_pos;
  pir->ir_pos += pir->ir_length;
  pir->ir_error = 0;
	return pir->ir_error;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	HandleSeek
//
// Purpose
//	Handles seek requests to a previously opened file
//
// Parameters
//	pir		pointer to io_req 
//	  ir_fh		file handle  
//	  ir_flags	indicates seek from start or end
//	  ir_pos	signed offset
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	This function only affects the h_pos field of the file
// 	handle.
//
int __cdecl HandleSeek(pioreq pir)
{
	PFFSSHANDLE h = (PFFSSHANDLE)pir->ir_fh;
  long Seek_Flags;

	if (h->h_sig != SIGFILE)
		return (pir->ir_error = ERROR_INVALID_HANDLE);

	switch (pir->ir_flags)
	{
	case FILE_BEGIN:	// seek from start
		pir->ir_pos = min(pir->ir_pos, h->h_size);
    Seek_Flags = FFSS_SEEK_SET;
		break;

	case FILE_END:		// seek from end
		if (pir->ir_pos > 0)	
			pir->ir_pos = h->h_size;
		else
			pir->ir_pos = h->h_size + pir->ir_pos;
    Seek_Flags = FFSS_SEEK_END;
	}

	h->h_pos = pir->ir_pos;
		
	return (pir->ir_error=0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// Function
//	HandleClose
//
// Purpose
//	Closes a previously opened file
//
// Parameters
//	pir		pointer to io_req 
//	  ir_fh		file handle  
//
// Return Value
//	Returns zero on success.
//
// Remarks
//	This function closes both FindFirst handles and OpenFile handles
//
int __cdecl HandleClose(pioreq pir)
{
// Close a find first handle
	if ( ((PFINDCONTEXT)pir->ir_fh)->fc_sig == SIGFIND)
	{
    dprintf("HandleClose : Closing Find Handle");
		((PFINDCONTEXT)pir->ir_fh)->fc_sig = 0;
		if (((PFINDCONTEXT)pir->ir_fh)->fc_match != NULL)
			free( ((PFINDCONTEXT)pir->ir_fh)->fc_match);
		if (((PFINDCONTEXT)pir->ir_fh)->fc_Domain != NULL)
			free( ((PFINDCONTEXT)pir->ir_fh)->fc_Domain);
		if (((PFINDCONTEXT)pir->ir_fh)->fc_Server != NULL)
			free( ((PFINDCONTEXT)pir->ir_fh)->fc_Server);
		if (((PFINDCONTEXT)pir->ir_fh)->fc_EntryList != NULL)
    {
      dprintf("HandleClose : Marking EntryList for removal");
      ((PFINDCONTEXT)pir->ir_fh)->fc_EntryList->Used = false;
    }
		free(pir->ir_fh);
	}	
// Close an open file handle
	else if ( ((PFFSSHANDLE)pir->ir_fh)->h_sig == SIGFILE)
	{
    dprintf("HandleClose : Closing File Handle (%ld)",((PFFSSHANDLE)pir->ir_fh)->h_handle);
    Sem_Handles->wait();
    FFSS_Handles = SU_DelElementElem(FFSS_Handles,((PFINDCONTEXT)pir->ir_fh));
    Sem_Handles->signal();
		((PFINDCONTEXT)pir->ir_fh)->fc_sig = 0;
		if ( ((PFFSSHANDLE)pir->ir_fh)->h_name )
			free( ((PFFSSHANDLE)pir->ir_fh)->h_name);
    if(((PFFSSHANDLE)pir->ir_fh)->h_TCP != NULL)
    {
      if( ((PFFSSHANDLE)pir->ir_fh)->h_handle != 0 )
        FC_SendMessage_StrmClose(((PFFSSHANDLE)pir->ir_fh)->h_TCP,((PFFSSHANDLE)pir->ir_fh)->h_handle);
      Sem_TCP->wait();
      ((PFFSSHANDLE)pir->ir_fh)->h_TCP->Used--;
      if((((PFFSSHANDLE)pir->ir_fh)->h_TCP->Used == 0) && (((PFFSSHANDLE)pir->ir_fh)->h_TCP->Mark))
      {
        dprintf("HandleClose : This handle was the last using this TCP, freeing");
        delete ((PFFSSHANDLE)pir->ir_fh)->h_TCP;
      }
      Sem_TCP->signal();
    }
		free(pir->ir_fh);
	}
	else
		DEBUGWARN("HandleClose: bad handle or already closed");

	return (pir->ir_error=0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
//
// The remaining functions in this module have no effect or are 
// unimplemented in the Registry File System:

INT VolRename(pioreq pir)
{
  //dprintf("Volume Rename");
	return (pir->ir_error = ERROR_ACCESS_DENIED);
}

INT VolSearch(pioreq pir)
{
  //dprintf("Volume Search");
	return (pir->ir_error = ERROR_BAD_COMMAND);
}

INT VolDelete(pioreq pir)
{
	//dprintf("Volume Delete");
	return (pir->ir_error = 0);
}

INT Vol_Flush(pioreq pir)
{
	//dprintf("Volume Flush");
	return 0;
}

INT VolDisconnect(pioreq pir)
{
	//dprintf("Volume Disconnect");
	return (pir->ir_error = 0);
}

INT VolUNCPipe(pioreq pir)
{
	//dprintf("Volume UNC Pipe");
	return (pir->ir_error = 0);
}

INT VolParams(pioreq pir)
{
	//dprintf("Volume Params");
	return (pir->ir_error = 0);
}

INT VolDasdio(pioreq pir)
{
	//dprintf("Volume dasdio");
	return (pir->ir_error = 0);
}

INT HandleWrite(pioreq pir)
{
	//dprintf("Handle Write");
	return (pir->ir_error = ERROR_ACCESS_DENIED);
}

INT HandleCommit(pioreq pir)
{
	//dprintf("Handle Commit");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT HandleFilelocks(pioreq pir)
{
	//dprintf("Handle Filelocks");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT HandleFiletimes(pioreq pir)
{
	//dprintf("Handle Filetimes");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT HandlePiperequest(pioreq pir)
{
	//dprintf("Handle Piperequest");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT HandleHandleinfo(pioreq pir)
{
	//dprintf("Handle info");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT HandleEnumhandle(pioreq pir)
{
	//dprintf("Handle Enumhandle");
	return (pir->ir_error=ERROR_ACCESS_DENIED);
}

INT ErrorFunc(pioreq pir)
{
	return (pir->ir_error = ERROR_ACCESS_DENIED);
}
