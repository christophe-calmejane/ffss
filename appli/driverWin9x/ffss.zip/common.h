#ifndef __FFSS_COMMON_H__
#define __FFSS_COMMON_H__

int F_ThreadUDP(void *User,void *Ctx);

#endif
